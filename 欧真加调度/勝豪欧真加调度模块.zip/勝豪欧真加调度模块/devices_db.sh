#!/system/bin/sh
# =====================================================
#         勝豪 欧真加全系列设备数据库 v1.0
#         作者：勝豪  Q群：1022873156
# =====================================================

detect_device_profile() {
    case "$1" in

        # ====================================================
        #                OPPO Find 旗舰系列
        # ====================================================
        *Find X9 Ultra*)                                    echo "oppo_find_x9_ultra" ;;
        *Find X9 Pro*)                                      echo "oppo_find_x9_pro" ;;
        *Find X9*)                                          echo "oppo_find_x9" ;;
        *Find X8 Ultra*|*PKJ110*)                           echo "oppo_find_x8_ultra" ;;
        *Find X8 Pro*|*PKC110*)                             echo "oppo_find_x8_pro" ;;
        *Find X8s*|*PKT110*)                                echo "oppo_find_x8s" ;;
        *Find X8*|*PKD110*)                                 echo "oppo_find_x8" ;;
        *Find X7 Ultra*|*PHY110*)                           echo "oppo_find_x7_ultra" ;;
        *Find X7*|*PHZ110*)                                 echo "oppo_find_x7" ;;
        *Find X6 Pro*|*PGEM10*)                             echo "oppo_find_x6_pro" ;;
        *Find X6*|*PGFM10*)                                 echo "oppo_find_x6" ;;
        *Find X5 Pro*|*PFEM10*)                             echo "oppo_find_x5_pro" ;;
        *Find X5*|*PFFM10*)                                 echo "oppo_find_x5" ;;
        *Find X3 Pro*|*PEEM00*)                             echo "oppo_find_x3_pro" ;;
        *Find X3*|*PEDM00*)                                 echo "oppo_find_x3" ;;
        *Find X2 Pro*|*PDEM10*)                             echo "oppo_find_x2_pro" ;;
        *Find X2*|*PDEM30*)                                 echo "oppo_find_x2" ;;
        *Find X*|*PAFM00*)                                  echo "oppo_find_x" ;;
        *Find 7*|*X9007*)                                   echo "oppo_find_7" ;;
        *Find 5*|*X909*)                                    echo "oppo_find_5" ;;

        # ====================================================
        #                OPPO Find N 折叠屏
        # ====================================================
        *Find N5*|*PHN110*)                                 echo "oppo_find_n5" ;;
        *Find N3 Flip*|*PHT110*)                            echo "oppo_find_n3_flip" ;;
        *Find N3*|*PHN110_N3*)                              echo "oppo_find_n3" ;;
        *Find N2 Flip*|*PGT110*)                            echo "oppo_find_n2_flip" ;;
        *Find N2*|*PGU110*)                                 echo "oppo_find_n2" ;;
        *Find N*|*PEGM10_N*)                                echo "oppo_find_n" ;;

        # ====================================================
        #                OPPO Reno 系列
        # ====================================================
        *Reno15 Pro*)                                       echo "oppo_reno15_pro" ;;
        *Reno15*)                                           echo "oppo_reno15" ;;
        *Reno14 Pro*)                                       echo "oppo_reno14_pro" ;;
        *Reno14*)                                           echo "oppo_reno14" ;;
        *Reno13 Pro*)                                       echo "oppo_reno13_pro" ;;
        *Reno13*)                                           echo "oppo_reno13" ;;
        *Reno12 Pro*)                                       echo "oppo_reno12_pro" ;;
        *Reno12*)                                           echo "oppo_reno12" ;;
        *Reno11 Pro*)                                       echo "oppo_reno11_pro" ;;
        *Reno11*)                                           echo "oppo_reno11" ;;
        *Reno10 Pro+*)                                      echo "oppo_reno10_pro_plus" ;;
        *Reno10 Pro*)                                       echo "oppo_reno10_pro" ;;
        *Reno10*)                                           echo "oppo_reno10" ;;
        *Reno9 Pro+*)                                       echo "oppo_reno9_pro_plus" ;;
        *Reno9 Pro*)                                        echo "oppo_reno9_pro" ;;
        *Reno9*)                                            echo "oppo_reno9" ;;
        *Reno8 Pro+*)                                       echo "oppo_reno8_pro_plus" ;;
        *Reno8 Pro*)                                        echo "oppo_reno8_pro" ;;
        *Reno8*)                                            echo "oppo_reno8" ;;
        *Reno7 Pro*)                                        echo "oppo_reno7_pro" ;;
        *Reno7 SE*)                                         echo "oppo_reno7_se" ;;
        *Reno7*)                                            echo "oppo_reno7" ;;
        *Reno6 Pro+*)                                       echo "oppo_reno6_pro_plus" ;;
        *Reno6 Pro*)                                        echo "oppo_reno6_pro" ;;
        *Reno6*)                                            echo "oppo_reno6" ;;
        *Reno5 Pro+*)                                       echo "oppo_reno5_pro_plus" ;;
        *Reno5 Pro*)                                        echo "oppo_reno5_pro" ;;
        *Reno5 K*)                                          echo "oppo_reno5_k" ;;
        *Reno5*)                                            echo "oppo_reno5" ;;
        *Reno4 Pro*)                                        echo "oppo_reno4_pro" ;;
        *Reno4 SE*)                                         echo "oppo_reno4_se" ;;
        *Reno4*)                                            echo "oppo_reno4" ;;
        *Reno3 Pro*)                                        echo "oppo_reno3_pro" ;;
        *Reno3 元气版*)                                     echo "oppo_reno3_yuanqi" ;;
        *Reno3*)                                            echo "oppo_reno3" ;;
        *Reno2 Z*)                                          echo "oppo_reno2_z" ;;
        *Reno2*)                                            echo "oppo_reno2" ;;
        *Reno 10倍变焦版*)                                  echo "oppo_reno_10x" ;;
        *Reno*|*PCAM00*)                                    echo "oppo_reno" ;;

        # ====================================================
        #                OPPO K 系列
        # ====================================================
        *OPPO K13 Turbo Pro*)                               echo "oppo_k13_turbo_pro" ;;
        *OPPO K13 Turbo*)                                   echo "oppo_k13_turbo" ;;
        *OPPO K13x*)                                        echo "oppo_k13x" ;;
        *OPPO K13*)                                         echo "oppo_k13" ;;
        *OPPO K12x*)                                        echo "oppo_k12x" ;;
        *OPPO K12 Plus*)                                    echo "oppo_k12_plus" ;;
        *OPPO K12*)                                         echo "oppo_k12" ;;
        *OPPO K11x*)                                        echo "oppo_k11x" ;;
        *OPPO K11*)                                         echo "oppo_k11" ;;
        *OPPO K10x*)                                        echo "oppo_k10x" ;;
        *OPPO K10 Pro*)                                     echo "oppo_k10_pro" ;;
        *OPPO K10*)                                         echo "oppo_k10" ;;
        *OPPO K9x*)                                         echo "oppo_k9x" ;;
        *OPPO K9 Pro*)                                      echo "oppo_k9_pro" ;;
        *OPPO K9s*)                                         echo "oppo_k9s" ;;
        *OPPO K9*)                                          echo "oppo_k9" ;;
        *OPPO K7x*)                                         echo "oppo_k7x" ;;
        *OPPO K7*)                                          echo "oppo_k7" ;;
        *OPPO K5*)                                          echo "oppo_k5" ;;
        *OPPO K3*)                                          echo "oppo_k3" ;;
        *OPPO K1*)                                          echo "oppo_k1" ;;

        # ====================================================
        #                OPPO A 系列
        # ====================================================
        *OPPO A5 Pro*)                                      echo "oppo_a5_pro" ;;
        *OPPO A5 活力版*)                                   echo "oppo_a5_yuanqi" ;;
        *OPPO A5*)                                          echo "oppo_a5" ;;
        *OPPO A3 Pro*)                                      echo "oppo_a3_pro" ;;
        *OPPO A3x*)                                         echo "oppo_a3x" ;;
        *OPPO A3*)                                          echo "oppo_a3" ;;
        *OPPO A2 Pro*)                                      echo "oppo_a2_pro" ;;
        *OPPO A2x*)                                         echo "oppo_a2x" ;;
        *OPPO A2m*)                                         echo "oppo_a2m" ;;
        *OPPO A2*)                                          echo "oppo_a2" ;;
        *OPPO A1 Pro*)                                      echo "oppo_a1_pro" ;;
        *OPPO A1x*)                                         echo "oppo_a1x" ;;
        *OPPO A1i*)                                         echo "oppo_a1i" ;;
        *OPPO A1*)                                          echo "oppo_a1" ;;
        *OPPO A98*)                                         echo "oppo_a98" ;;
        *OPPO A97*)                                         echo "oppo_a97" ;;
        *OPPO A96*)                                         echo "oppo_a96" ;;
        *OPPO A95*)                                         echo "oppo_a95" ;;
        *OPPO A94*)                                         echo "oppo_a94" ;;
        *OPPO A93s*)                                        echo "oppo_a93s" ;;
        *OPPO A93*)                                         echo "oppo_a93" ;;
        *OPPO A92s*)                                        echo "oppo_a92s" ;;
        *OPPO A91*)                                         echo "oppo_a91" ;;
        *OPPO A83*)                                         echo "oppo_a83" ;;
        *OPPO A79*)                                         echo "oppo_a79" ;;
        *OPPO A77*)                                         echo "oppo_a77" ;;
        *OPPO A72*)                                         echo "oppo_a72" ;;
        *OPPO A59*)                                         echo "oppo_a59" ;;
        *OPPO A57*)                                         echo "oppo_a57" ;;
        *OPPO A55*)                                         echo "oppo_a55" ;;
        *OPPO A53*)                                         echo "oppo_a53" ;;
        *OPPO A52*)                                         echo "oppo_a52" ;;
        *OPPO A37*)                                         echo "oppo_a37" ;;
        *OPPO A35*)                                         echo "oppo_a35" ;;
        *OPPO A33*)                                         echo "oppo_a33" ;;
        *OPPO A32*)                                         echo "oppo_a32" ;;
        *OPPO A31*)                                         echo "oppo_a31" ;;
        *OPPO A15*)                                         echo "oppo_a15" ;;
        *OPPO A11*)                                         echo "oppo_a11" ;;
        *OPPO A9*)                                          echo "oppo_a9" ;;
        *OPPO A7*)                                          echo "oppo_a7" ;;
        *OPPO A5s*)                                         echo "oppo_a5s" ;;
        *OPPO A5*)                                          echo "oppo_a5_old" ;;
        *OPPO A3s*)                                         echo "oppo_a3s" ;;
        *OPPO A3*)                                          echo "oppo_a3_old" ;;
        *OPPO A1*)                                          echo "oppo_a1_old" ;;

        # ====================================================
        #                OPPO R 系列（早期）
        # ====================================================
        *OPPO R17*)                                         echo "oppo_r17" ;;
        *OPPO R15*)                                         echo "oppo_r15" ;;
        *OPPO R13*)                                         echo "oppo_r13" ;;
        *OPPO R11s*)                                        echo "oppo_r11s" ;;
        *OPPO R11*)                                         echo "oppo_r11" ;;
        *OPPO R9s*)                                         echo "oppo_r9s" ;;
        *OPPO R9*)                                          echo "oppo_r9" ;;
        *OPPO R7s*)                                         echo "oppo_r7s" ;;
        *OPPO R7*)                                          echo "oppo_r7" ;;
        *OPPO R5*)                                          echo "oppo_r5" ;;

        # ====================================================
        #                OPPO N 系列（旋转摄像头）
        # ====================================================
        *OPPO N3*)                                          echo "oppo_n3" ;;
        *OPPO N1 mini*)                                     echo "oppo_n1_mini" ;;
        *OPPO N1*)                                          echo "oppo_n1" ;;

        # ====================================================
        #                OPPO F 系列（海外）
        # ====================================================
        *OPPO F27*)                                         echo "oppo_f27" ;;
        *OPPO F25 Pro*)                                     echo "oppo_f25_pro" ;;
        *OPPO F25*)                                         echo "oppo_f25" ;;
        *OPPO F23*)                                         echo "oppo_f23" ;;
        *OPPO F21 Pro*)                                     echo "oppo_f21_pro" ;;
        *OPPO F21s Pro*)                                    echo "oppo_f21s_pro" ;;
        *OPPO F21*)                                         echo "oppo_f21" ;;
        *OPPO F19 Pro*)                                     echo "oppo_f19_pro" ;;
        *OPPO F19*)                                         echo "oppo_f19" ;;
        *OPPO F17 Pro*)                                     echo "oppo_f17_pro" ;;
        *OPPO F17*)                                         echo "oppo_f17" ;;
        *OPPO F15*)                                         echo "oppo_f15" ;;
        *OPPO F11 Pro*)                                     echo "oppo_f11_pro" ;;
        *OPPO F11*)                                         echo "oppo_f11" ;;
        *OPPO F9 Pro*)                                      echo "oppo_f9_pro" ;;
        *OPPO F9*)                                          echo "oppo_f9" ;;
        *OPPO F7*)                                          echo "oppo_f7" ;;
        *OPPO F5*)                                          echo "oppo_f5" ;;
        *OPPO F3*)                                          echo "oppo_f3" ;;
        *OPPO F1s*)                                         echo "oppo_f1s" ;;
        *OPPO F1*)                                          echo "oppo_f1" ;;

        # ====================================================
        #                OPPO Pad 平板
        # ====================================================
        *OPPO Pad 4 Pro*)                                   echo "oppo_pad_4_pro" ;;
        *OPPO Pad 4*)                                       echo "oppo_pad_4" ;;
        *OPPO Pad 3 Pro*)                                   echo "oppo_pad_3_pro" ;;
        *OPPO Pad 3*)                                       echo "oppo_pad_3" ;;
        *OPPO Pad 2*)                                       echo "oppo_pad_2" ;;
        *OPPO Pad Air2*)                                    echo "oppo_pad_air2" ;;
        *OPPO Pad Air*)                                     echo "oppo_pad_air" ;;
        *OPPO Pad SE*)                                      echo "oppo_pad_se" ;;
        *OPPO Pad*)                                         echo "oppo_pad" ;;

        # ====================================================
        #                一加 数字旗舰
        # ====================================================
        *OnePlus 15 Ultra*)                                 echo "oneplus_15_ultra" ;;
        *OnePlus 15T*)                                      echo "oneplus_15t" ;;
        *OnePlus 15*)                                       echo "oneplus_15" ;;
        *OnePlus 13T*)                                      echo "oneplus_13t" ;;
        *OnePlus 13*)                                       echo "oneplus_13" ;;
        *OnePlus 12R*)                                      echo "oneplus_12r" ;;
        *OnePlus 12*)                                       echo "oneplus_12" ;;
        *OnePlus 11*)                                       echo "oneplus_11" ;;
        *OnePlus 10T*)                                      echo "oneplus_10t" ;;
        *OnePlus 10 Pro*)                                   echo "oneplus_10_pro" ;;
        *OnePlus 9RT*)                                      echo "oneplus_9rt" ;;
        *OnePlus 9R*)                                       echo "oneplus_9r" ;;
        *OnePlus 9 Pro*)                                    echo "oneplus_9_pro" ;;
        *OnePlus 9*)                                        echo "oneplus_9" ;;
        *OnePlus 8T*)                                       echo "oneplus_8t" ;;
        *OnePlus 8 Pro*)                                    echo "oneplus_8_pro" ;;
        *OnePlus 8*)                                        echo "oneplus_8" ;;
        *OnePlus 7T Pro*)                                   echo "oneplus_7t_pro" ;;
        *OnePlus 7T*)                                       echo "oneplus_7t" ;;
        *OnePlus 7 Pro*)                                    echo "oneplus_7_pro" ;;
        *OnePlus 7*)                                        echo "oneplus_7" ;;
        *OnePlus 6T*)                                       echo "oneplus_6t" ;;
        *OnePlus 6*)                                        echo "oneplus_6" ;;
        *OnePlus 5T*)                                       echo "oneplus_5t" ;;
        *OnePlus 5*)                                        echo "oneplus_5" ;;
        *OnePlus 3T*)                                       echo "oneplus_3t" ;;
        *OnePlus 3*)                                        echo "oneplus_3" ;;
        *OnePlus 2*)                                        echo "oneplus_2" ;;
        *OnePlus One*|*OnePlus 1*)                          echo "oneplus_1" ;;
        *OnePlus X*)                                        echo "oneplus_x" ;;

        # ====================================================
        #                一加 Ace 系列
        # ====================================================
        *OnePlus Ace 6 Pro*)                                echo "oneplus_ace_6_pro" ;;
        *OnePlus Ace 6*)                                    echo "oneplus_ace_6" ;;
        *OnePlus Ace 5 Pro*)                                echo "oneplus_ace_5_pro" ;;
        *OnePlus Ace 5*)                                    echo "oneplus_ace_5" ;;
        *OnePlus Ace 3 Pro*)                                echo "oneplus_ace_3_pro" ;;
        *OnePlus Ace 3V*)                                   echo "oneplus_ace_3v" ;;
        *OnePlus Ace 3*)                                    echo "oneplus_ace_3" ;;
        *OnePlus Ace 2 Pro*)                                echo "oneplus_ace_2_pro" ;;
        *OnePlus Ace 2V*)                                   echo "oneplus_ace_2v" ;;
        *OnePlus Ace 2*)                                    echo "oneplus_ace_2" ;;
        *OnePlus Ace Racing*)                               echo "oneplus_ace_racing" ;;
        *OnePlus Ace*)                                      echo "oneplus_ace" ;;

        # ====================================================
        #                一加 Nord 系列（海外）
        # ====================================================
        *OnePlus Nord 5*)                                   echo "oneplus_nord_5" ;;
        *OnePlus Nord 4*)                                   echo "oneplus_nord_4" ;;
        *OnePlus Nord 3*)                                   echo "oneplus_nord_3" ;;
        *OnePlus Nord 2T*)                                  echo "oneplus_nord_2t" ;;
        *OnePlus Nord 2*)                                   echo "oneplus_nord_2" ;;
        *OnePlus Nord CE4*)                                 echo "oneplus_nord_ce4" ;;
        *OnePlus Nord CE3*)                                 echo "oneplus_nord_ce3" ;;
        *OnePlus Nord CE2*)                                 echo "oneplus_nord_ce2" ;;
        *OnePlus Nord CE*)                                  echo "oneplus_nord_ce" ;;
        *OnePlus Nord N30*)                                 echo "oneplus_nord_n30" ;;
        *OnePlus Nord N20*)                                 echo "oneplus_nord_n20" ;;
        *OnePlus Nord N10*)                                 echo "oneplus_nord_n10" ;;
        *OnePlus Nord N100*)                                echo "oneplus_nord_n100" ;;
        *OnePlus Nord*)                                     echo "oneplus_nord" ;;

        # ====================================================
        #                一加 Pad 平板
        # ====================================================
        *OnePlus Pad 2 Pro*)                                echo "oneplus_pad_2_pro" ;;
        *OnePlus Pad 2*)                                    echo "oneplus_pad_2" ;;
        *OnePlus Pad Go*)                                   echo "oneplus_pad_go" ;;
        *OnePlus Pad*)                                      echo "oneplus_pad" ;;

        # ====================================================
        #                realme GT 系列
        # ====================================================
        *realme GT7 Pro*|*RMX5010*)                         echo "realme_gt7_pro" ;;
        *realme GT7*|*RMX6688*)                             echo "realme_gt7" ;;
        *realme GT6*|*RMX3852*)                             echo "realme_gt6" ;;
        *realme GT5 Pro*|*RMX3888*)                         echo "realme_gt5_pro" ;;
        *realme GT5*|*RMX3820*)                             echo "realme_gt5" ;;
        *realme GT3*|*RMX3708*)                             echo "realme_gt3" ;;
        *realme GT2 大师探索版*)                            echo "realme_gt2_explorer" ;;
        *realme GT2 Pro*|*RMX3301*)                         echo "realme_gt2_pro" ;;
        *realme GT2*|*RMX3311*)                             echo "realme_gt2" ;;
        *realme GT 大师探索版*)                             echo "realme_gt_explorer" ;;
        *realme GT Neo 闪速版*)                             echo "realme_gt_neo_flash" ;;
        *realme GT*|*RMX2202*)                              echo "realme_gt" ;;

        # ====================================================
        #                realme GT Neo 系列
        # ====================================================
        *realme GT Neo6 SE*|*RMX3850*)                      echo "realme_gt_neo_6_se" ;;
        *realme GT Neo6*|*RMX3852_N6*)                      echo "realme_gt_neo_6" ;;
        *realme GT Neo5 SE*|*RMX3700*)                      echo "realme_gt_neo_5_se" ;;
        *realme GT Neo5*|*RMX3706*)                         echo "realme_gt_neo_5" ;;
        *realme GT Neo3*|*RMX3562*)                         echo "realme_gt_neo_3" ;;
        *realme GT Neo2T*|*RMX3357*)                        echo "realme_gt_neo_2t" ;;
        *realme GT Neo2*|*RMX3370*)                         echo "realme_gt_neo_2" ;;
        *realme GT Neo*|*RMX3031*)                          echo "realme_gt_neo" ;;

        # ====================================================
        #                realme 数字系列
        # ====================================================
        *realme 15 Pro*|*RMX5070*)                          echo "realme_15_pro" ;;
        *realme 15*|*RMX5060*)                              echo "realme_15" ;;
        *realme 14 Pro+*|*RMX5051*)                         echo "realme_14_pro_plus" ;;
        *realme 14 Pro*|*RMX5050*)                          echo "realme_14_pro" ;;
        *realme 14*|*RMX5040*)                              echo "realme_14" ;;
        *realme 13 Pro+*|*RMX3921*)                         echo "realme_13_pro_plus" ;;
        *realme 13 Pro*|*RMX3920*)                          echo "realme_13_pro" ;;
        *realme 13*|*RMX3910*)                              echo "realme_13" ;;
        *realme 12 Pro+*|*RMX3840*)                         echo "realme_12_pro_plus" ;;
        *realme 12 Pro*|*RMX3823*)                          echo "realme_12_pro" ;;
        *realme 12*|*RMX3850_R12*)                          echo "realme_12" ;;
        *realme 11 Pro+*|*RMX3740*)                         echo "realme_11_pro_plus" ;;
        *realme 11 Pro*|*RMX3771*)                          echo "realme_11_pro" ;;
        *realme 11*|*RMX3630*)                              echo "realme_11" ;;
        *realme 10 Pro+*|*RMX3686*)                         echo "realme_10_pro_plus" ;;
        *realme 10 Pro*|*RMX3661*)                          echo "realme_10_pro" ;;
        *realme 10*|*RMX3630_R10*)                          echo "realme_10" ;;
        *realme 9 Pro+*|*RMX3393*)                          echo "realme_9_pro_plus" ;;
        *realme 9 Pro*|*RMX3471*)                           echo "realme_9_pro" ;;
        *realme 9i*|*RMX3491*)                              echo "realme_9i" ;;
        *realme 9*|*RMX3521*)                               echo "realme_9" ;;
        *realme 8 Pro*|*RMX3081*)                           echo "realme_8_pro" ;;
        *realme 8i*|*RMX3151*)                              echo "realme_8i" ;;
        *realme 8*|*RMX3085*)                               echo "realme_8" ;;
        *realme 7 Pro*|*RMX2170*)                           echo "realme_7_pro" ;;
        *realme 7i*|*RMX2103*)                              echo "realme_7i" ;;
        *realme 7*|*RMX2151*)                               echo "realme_7" ;;
        *realme 6 Pro*|*RMX2061*)                           echo "realme_6_pro" ;;
        *realme 6i*|*RMX2040*)                              echo "realme_6i" ;;
        *realme 6*|*RMX2001*)                               echo "realme_6" ;;
        *realme 5 Pro*|*RMX1971*)                           echo "realme_5_pro" ;;
        *realme 5i*|*RMX2030*)                              echo "realme_5i" ;;
        *realme 5*|*RMX1911*)                               echo "realme_5" ;;
        *realme 3 Pro*|*RMX1851*)                           echo "realme_3_pro" ;;
        *realme 3i*)                                        echo "realme_3i" ;;
        *realme 3*)                                         echo "realme_3" ;;
        *realme 2 Pro*)                                     echo "realme_2_pro" ;;
        *realme 2*)                                         echo "realme_2" ;;
        *realme 1*)                                         echo "realme_1" ;;

        # ====================================================
        #                realme Narzo 系列
        # ====================================================
        *realme Narzo 70 Pro*)                              echo "realme_narzo_70_pro" ;;
        *realme Narzo 70x*)                                 echo "realme_narzo_70x" ;;
        *realme Narzo 70*)                                  echo "realme_narzo_70" ;;
        *realme Narzo 60 Pro*)                              echo "realme_narzo_60_pro" ;;
        *realme Narzo 60x*)                                 echo "realme_narzo_60x" ;;
        *realme Narzo 60*)                                  echo "realme_narzo_60" ;;
        *realme Narzo 50 Pro*)                              echo "realme_narzo_50_pro" ;;
        *realme Narzo 50i*)                                 echo "realme_narzo_50i" ;;
        *realme Narzo 50*)                                  echo "realme_narzo_50" ;;
        *realme Narzo 30 Pro*)                              echo "realme_narzo_30_pro" ;;
        *realme Narzo 30*)                                  echo "realme_narzo_30" ;;
        *realme Narzo 20 Pro*)                              echo "realme_narzo_20_pro" ;;
        *realme Narzo 20*)                                  echo "realme_narzo_20" ;;
        *realme Narzo 10*)                                  echo "realme_narzo_10" ;;

        # ====================================================
        #                realme C / V / Q 系列
        # ====================================================
        *realme C75*)                                       echo "realme_c75" ;;
        *realme C67*|*RMX3890*)                             echo "realme_c67" ;;
        *realme C65*)                                       echo "realme_c65" ;;
        *realme C61*)                                       echo "realme_c61" ;;
        *realme C55*)                                       echo "realme_c55" ;;
        *realme C53*)                                       echo "realme_c53" ;;
        *realme C51*)                                       echo "realme_c51" ;;
        *realme C35*)                                       echo "realme_c35" ;;
        *realme C33*)                                       echo "realme_c33" ;;
        *realme C31*)                                       echo "realme_c31" ;;
        *realme C30*)                                       echo "realme_c30" ;;
        *realme C25*)                                       echo "realme_c25" ;;
        *realme C21*)                                       echo "realme_c21" ;;
        *realme C20*)                                       echo "realme_c20" ;;
        *realme C17*)                                       echo "realme_c17" ;;
        *realme C15*)                                       echo "realme_c15" ;;
        *realme C12*)                                       echo "realme_c12" ;;
        *realme C11*)                                       echo "realme_c11" ;;
        *realme C3*)                                        echo "realme_c3" ;;
        *realme C2*)                                        echo "realme_c2" ;;
        *realme C1*)                                        echo "realme_c1" ;;
        *realme V50*)                                       echo "realme_v50" ;;
        *realme V30*)                                       echo "realme_v30" ;;
        *realme V25*)                                       echo "realme_v25" ;;
        *realme V23*)                                       echo "realme_v23" ;;
        *realme V15*)                                       echo "realme_v15" ;;
        *realme V13*)                                       echo "realme_v13" ;;
        *realme V11*)                                       echo "realme_v11" ;;
        *realme V5*)                                        echo "realme_v5" ;;
        *realme V3*)                                        echo "realme_v3" ;;
        *realme Q5*)                                        echo "realme_q5" ;;
        *realme Q3*)                                        echo "realme_q3" ;;
        *realme Q2*)                                        echo "realme_q2" ;;

        # ====================================================
        #                realme X / U / Pad 系列
        # ====================================================
        *realme X50 Pro*)                                   echo "realme_x50_pro" ;;
        *realme X50*)                                       echo "realme_x50" ;;
        *realme X7 Pro*)                                    echo "realme_x7_pro" ;;
        *realme X7*)                                        echo "realme_x7" ;;
        *realme X3*)                                        echo "realme_x3" ;;
        *realme X2 Pro*)                                    echo "realme_x2_pro" ;;
        *realme X2*)                                        echo "realme_x2" ;;
        *realme X*)                                         echo "realme_x" ;;
        *realme U1*)                                        echo "realme_u1" ;;
        *realme Pad X*)                                     echo "realme_pad_x" ;;
        *realme Pad Mini*)                                  echo "realme_pad_mini" ;;
        *realme Pad*)                                       echo "realme_pad" ;;

        # ====================================================
        #                  默认兜底
        # ====================================================
        *)                                                  echo "generic" ;;
    esac
}

# ==================== 设备专属参数 ====================
apply_device_profile() {
    TEMP_LIMIT="45"
    ENABLE_BYPASS_CHARGE=0

    case "$1" in

        # ==================== OPPO Find ====================
        oppo_find_x9_ultra)   DEVICE_TIP="OPPO Find X9Ultra(骁龙8Elite Gen5)"; BIG_MIN="2200000"; BIG_MAX="4400000"; TEMP_LIMIT="47" ;;
        oppo_find_x9_pro)     DEVICE_TIP="OPPO Find X9Pro(天玑9500)"; BIG_MIN="1800000"; BIG_MAX="3800000"; TEMP_LIMIT="47" ;;
        oppo_find_x9)         DEVICE_TIP="OPPO Find X9(天玑9500)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        oppo_find_x8_ultra)   DEVICE_TIP="OPPO Find X8Ultra(骁龙8Elite)"; BIG_MIN="2000000"; BIG_MAX="4200000"; TEMP_LIMIT="47" ;;
        oppo_find_x8_pro)     DEVICE_TIP="OPPO Find X8Pro(天玑9400)"; BIG_MIN="1800000"; BIG_MAX="3620000"; TEMP_LIMIT="46" ;;
        oppo_find_x8s)        DEVICE_TIP="OPPO Find X8s(天玑9400+)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        oppo_find_x8)         DEVICE_TIP="OPPO Find X8(天玑9400)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        oppo_find_x7_ultra)   DEVICE_TIP="OPPO Find X7Ultra(骁龙8Gen3)"; BIG_MIN="1800000"; TEMP_LIMIT="47" ;;
        oppo_find_x7)         DEVICE_TIP="OPPO Find X7(天玑9300)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        oppo_find_x6_pro)     DEVICE_TIP="OPPO Find X6Pro(骁龙8Gen2)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        oppo_find_x6)         DEVICE_TIP="OPPO Find X6(天玑9200)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        oppo_find_x5_pro)     DEVICE_TIP="OPPO Find X5Pro(骁龙8Gen1)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        oppo_find_x5)         DEVICE_TIP="OPPO Find X5(骁龙888)"; BIG_MIN="1800000"; TEMP_LIMIT="44" ;;
        oppo_find_x3_pro)     DEVICE_TIP="OPPO Find X3Pro(骁龙888)"; BIG_MIN="1800000"; TEMP_LIMIT="44" ;;
        oppo_find_x3)         DEVICE_TIP="OPPO Find X3(骁龙870)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        oppo_find_x2_pro)     DEVICE_TIP="OPPO Find X2Pro(骁龙865)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        oppo_find_x2)         DEVICE_TIP="OPPO Find X2(骁龙865)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        oppo_find_x)          DEVICE_TIP="OPPO Find X(骁龙845)"; BIG_MIN="1766400"; TEMP_LIMIT="44" ;;
        oppo_find_7)          DEVICE_TIP="OPPO Find 7(骁龙801)"; TEMP_LIMIT="43" ;;
        oppo_find_5)          DEVICE_TIP="OPPO Find 5(骁龙APQ8064)"; TEMP_LIMIT="43" ;;

        # ==================== OPPO Find N ====================
        oppo_find_n5)         DEVICE_TIP="OPPO Find N5(骁龙8Elite)"; BIG_MIN="2000000"; TEMP_LIMIT="46" ;;
        oppo_find_n3_flip)    DEVICE_TIP="OPPO Find N3Flip(天玑9200)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        oppo_find_n3)         DEVICE_TIP="OPPO Find N3(骁龙8Gen2)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        oppo_find_n2_flip)    DEVICE_TIP="OPPO Find N2Flip(天玑9000+)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        oppo_find_n2)         DEVICE_TIP="OPPO Find N2(骁龙8+Gen1)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        oppo_find_n)          DEVICE_TIP="OPPO Find N(骁龙888)"; BIG_MIN="1800000"; TEMP_LIMIT="44" ;;

        # ==================== OPPO Reno ====================
        oppo_reno15_pro)      DEVICE_TIP="OPPO Reno15Pro(天玑8450)"; BIG_MIN="1500000"; TEMP_LIMIT="45" ;;
        oppo_reno15)          DEVICE_TIP="OPPO Reno15(骁龙7Gen4)"; TEMP_LIMIT="45" ;;
        oppo_reno14_pro)      DEVICE_TIP="OPPO Reno14Pro(天玑8400)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        oppo_reno14)          DEVICE_TIP="OPPO Reno14(天玑8350)"; BIG_MIN="1500000"; TEMP_LIMIT="45" ;;
        oppo_reno13_pro)      DEVICE_TIP="OPPO Reno13Pro(天玑8350)"; BIG_MIN="1500000"; TEMP_LIMIT="45" ;;
        oppo_reno13)          DEVICE_TIP="OPPO Reno13(天玑8350)"; BIG_MIN="1500000"; TEMP_LIMIT="45" ;;
        oppo_reno12_pro)      DEVICE_TIP="OPPO Reno12Pro(天玑9200+)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        oppo_reno12)          DEVICE_TIP="OPPO Reno12(天玑8250)"; TEMP_LIMIT="45" ;;
        oppo_reno11_pro)      DEVICE_TIP="OPPO Reno11Pro(骁龙8+Gen1)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        oppo_reno11)          DEVICE_TIP="OPPO Reno11(天玑8200)"; BIG_MIN="1500000"; TEMP_LIMIT="45" ;;
        oppo_reno10_pro_plus) DEVICE_TIP="OPPO Reno10Pro+(骁龙8+Gen1)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        oppo_reno10_pro)      DEVICE_TIP="OPPO Reno10Pro(天玑8200)"; BIG_MIN="1500000"; TEMP_LIMIT="45" ;;
        oppo_reno10)          DEVICE_TIP="OPPO Reno10(骁龙778G)"; TEMP_LIMIT="45" ;;
        oppo_reno9_pro_plus)  DEVICE_TIP="OPPO Reno9Pro+(骁龙8+Gen1)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        oppo_reno9_pro)       DEVICE_TIP="OPPO Reno9Pro(天玑8100-MAX)"; BIG_MIN="1500000"; TEMP_LIMIT="45" ;;
        oppo_reno9)           DEVICE_TIP="OPPO Reno9(骁龙778G)"; TEMP_LIMIT="45" ;;
        oppo_reno8_pro_plus)  DEVICE_TIP="OPPO Reno8Pro+(骁龙8+Gen1)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        oppo_reno8_pro)       DEVICE_TIP="OPPO Reno8Pro(骁龙7Gen1)"; TEMP_LIMIT="44" ;;
        oppo_reno8)           DEVICE_TIP="OPPO Reno8(天玑1300)"; BIG_MIN="1500000"; TEMP_LIMIT="44" ;;
        oppo_reno7_pro)       DEVICE_TIP="OPPO Reno7Pro(天玑1200-MAX)"; BIG_MIN="1500000"; TEMP_LIMIT="44" ;;
        oppo_reno7_se)        DEVICE_TIP="OPPO Reno7SE(天玑900)"; TEMP_LIMIT="44" ;;
        oppo_reno7)           DEVICE_TIP="OPPO Reno7(骁龙778G)"; TEMP_LIMIT="44" ;;
        oppo_reno6_pro_plus)  DEVICE_TIP="OPPO Reno6Pro+(骁龙870)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        oppo_reno6_pro)       DEVICE_TIP="OPPO Reno6Pro(天玑1200)"; BIG_MIN="1500000"; TEMP_LIMIT="44" ;;
        oppo_reno6)           DEVICE_TIP="OPPO Reno6(天玑900)"; TEMP_LIMIT="44" ;;
        oppo_reno5_pro_plus)  DEVICE_TIP="OPPO Reno5Pro+(骁龙865)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        oppo_reno5_pro)       DEVICE_TIP="OPPO Reno5Pro(天玑1000+)"; BIG_MIN="1500000"; TEMP_LIMIT="44" ;;
        oppo_reno5_k)         DEVICE_TIP="OPPO Reno5K(骁龙750G)"; TEMP_LIMIT="44" ;;
        oppo_reno5)           DEVICE_TIP="OPPO Reno5(骁龙765G)"; TEMP_LIMIT="44" ;;
        oppo_reno4_pro)       DEVICE_TIP="OPPO Reno4Pro(骁龙765G)"; TEMP_LIMIT="44" ;;
        oppo_reno4_se)        DEVICE_TIP="OPPO Reno4SE(天玑720)"; TEMP_LIMIT="44" ;;
        oppo_reno4)           DEVICE_TIP="OPPO Reno4(骁龙765G)"; TEMP_LIMIT="44" ;;
        oppo_reno3_pro)       DEVICE_TIP="OPPO Reno3Pro(骁龙765G)"; TEMP_LIMIT="44" ;;
        oppo_reno3_yuanqi)    DEVICE_TIP="OPPO Reno3元气版(骁龙765G)"; TEMP_LIMIT="44" ;;
        oppo_reno3)           DEVICE_TIP="OPPO Reno3(天玑1000L)"; TEMP_LIMIT="44" ;;
        oppo_reno2_z)         DEVICE_TIP="OPPO Reno2Z(联发科P90)"; TEMP_LIMIT="44" ;;
        oppo_reno2)           DEVICE_TIP="OPPO Reno2(骁龙730G)"; TEMP_LIMIT="44" ;;
        oppo_reno_10x)        DEVICE_TIP="OPPO Reno 10倍变焦版(骁龙855)"; BIG_MIN="1785600"; TEMP_LIMIT="44" ;;
        oppo_reno)            DEVICE_TIP="OPPO Reno(骁龙710)"; TEMP_LIMIT="44" ;;

        # ==================== OPPO K ====================
        oppo_k13_turbo_pro)   DEVICE_TIP="OPPO K13TurboPro(骁龙8sGen4)"; BIG_MIN="1500000"; TEMP_LIMIT="46" ;;
        oppo_k13_turbo)       DEVICE_TIP="OPPO K13Turbo(天玑8400)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        oppo_k13x)            DEVICE_TIP="OPPO K13x(骁龙6Gen4)"; TEMP_LIMIT="44" ;;
        oppo_k13)             DEVICE_TIP="OPPO K13(骁龙6Gen4)"; TEMP_LIMIT="44" ;;
        oppo_k12x)            DEVICE_TIP="OPPO K12x(骁龙695)"; TEMP_LIMIT="44" ;;
        oppo_k12_plus)        DEVICE_TIP="OPPO K12Plus(骁龙7Gen3)"; TEMP_LIMIT="45" ;;
        oppo_k12)             DEVICE_TIP="OPPO K12(骁龙7Gen3)"; TEMP_LIMIT="45" ;;
        oppo_k11x)            DEVICE_TIP="OPPO K11x(骁龙695)"; TEMP_LIMIT="44" ;;
        oppo_k11)             DEVICE_TIP="OPPO K11(骁龙782G)"; TEMP_LIMIT="45" ;;
        oppo_k10x)            DEVICE_TIP="OPPO K10x(骁龙695)"; TEMP_LIMIT="44" ;;
        oppo_k10_pro)         DEVICE_TIP="OPPO K10Pro(骁龙888)"; BIG_MIN="1800000"; TEMP_LIMIT="44" ;;
        oppo_k10)             DEVICE_TIP="OPPO K10(天玑8000-MAX)"; BIG_MIN="1500000"; TEMP_LIMIT="45" ;;
        oppo_k9x)             DEVICE_TIP="OPPO K9x(天玑810)"; TEMP_LIMIT="44" ;;
        oppo_k9_pro)          DEVICE_TIP="OPPO K9Pro(天玑1200)"; BIG_MIN="1500000"; TEMP_LIMIT="44" ;;
        oppo_k9s)             DEVICE_TIP="OPPO K9s(骁龙778G)"; TEMP_LIMIT="44" ;;
        oppo_k9)              DEVICE_TIP="OPPO K9(骁龙768G)"; TEMP_LIMIT="44" ;;
        oppo_k7x)             DEVICE_TIP="OPPO K7x(天玑720)"; TEMP_LIMIT="44" ;;
        oppo_k7)              DEVICE_TIP="OPPO K7(骁龙765G)"; TEMP_LIMIT="44" ;;
        oppo_k5)              DEVICE_TIP="OPPO K5(骁龙730G)"; TEMP_LIMIT="44" ;;
        oppo_k3)              DEVICE_TIP="OPPO K3(骁龙710)"; TEMP_LIMIT="44" ;;
        oppo_k1)              DEVICE_TIP="OPPO K1(骁龙660)"; TEMP_LIMIT="43" ;;

        # ==================== OPPO A ====================
        oppo_a5_pro)          DEVICE_TIP="OPPO A5Pro(天玑7300)"; TEMP_LIMIT="44" ;;
        oppo_a5_yuanqi)       DEVICE_TIP="OPPO A5活力版(骁龙6Gen1)"; TEMP_LIMIT="44" ;;
        oppo_a5)              DEVICE_TIP="OPPO A5(骁龙6Gen1)"; TEMP_LIMIT="44" ;;
        oppo_a3_pro)          DEVICE_TIP="OPPO A3Pro(天玑7050)"; TEMP_LIMIT="44" ;;
        oppo_a3x)             DEVICE_TIP="OPPO A3x(骁龙6Gen1)"; TEMP_LIMIT="44" ;;
        oppo_a3)              DEVICE_TIP="OPPO A3(骁龙695)"; TEMP_LIMIT="44" ;;
        oppo_a2_pro)          DEVICE_TIP="OPPO A2Pro(天玑7050)"; TEMP_LIMIT="44" ;;
        oppo_a2x)             DEVICE_TIP="OPPO A2x(天玑6020)"; TEMP_LIMIT="44" ;;
        oppo_a2m)             DEVICE_TIP="OPPO A2m(天玑6020)"; TEMP_LIMIT="44" ;;
        oppo_a2)              DEVICE_TIP="OPPO A2(天玑6020)"; TEMP_LIMIT="44" ;;
        oppo_a1_pro)          DEVICE_TIP="OPPO A1Pro(骁龙695)"; TEMP_LIMIT="44" ;;
        oppo_a1x)             DEVICE_TIP="OPPO A1x(天玑700)"; TEMP_LIMIT="44" ;;
        oppo_a1i)             DEVICE_TIP="OPPO A1i(天玑6020)"; TEMP_LIMIT="44" ;;
        oppo_a1)              DEVICE_TIP="OPPO A1(骁龙695)"; TEMP_LIMIT="44" ;;
        oppo_a98)             DEVICE_TIP="OPPO A98(骁龙695)"; TEMP_LIMIT="44" ;;
        oppo_a97)             DEVICE_TIP="OPPO A97(天玑810)"; TEMP_LIMIT="44" ;;
        oppo_a96)             DEVICE_TIP="OPPO A96(骁龙695)"; TEMP_LIMIT="44" ;;
        oppo_a95)             DEVICE_TIP="OPPO A95(天玑800U)"; TEMP_LIMIT="44" ;;
        oppo_a94)             DEVICE_TIP="OPPO A94(天玑900)"; TEMP_LIMIT="44" ;;
        oppo_a93s)            DEVICE_TIP="OPPO A93s(天玑700)"; TEMP_LIMIT="44" ;;
        oppo_a93)             DEVICE_TIP="OPPO A93(骁龙480)"; TEMP_LIMIT="44" ;;
        oppo_a92s)            DEVICE_TIP="OPPO A92s(天玑800)"; TEMP_LIMIT="44" ;;
        oppo_a91)             DEVICE_TIP="OPPO A91(联发科P70)"; TEMP_LIMIT="43" ;;
        oppo_a83)             DEVICE_TIP="OPPO A83(联发科P23)"; TEMP_LIMIT="43" ;;
        oppo_a79)             DEVICE_TIP="OPPO A79(联发科P23)"; TEMP_LIMIT="43" ;;
        oppo_a77)             DEVICE_TIP="OPPO A77(骁龙625)"; TEMP_LIMIT="43" ;;
        oppo_a72)             DEVICE_TIP="OPPO A72(天玑720)"; TEMP_LIMIT="44" ;;
        oppo_a59)             DEVICE_TIP="OPPO A59(联发科MT6750)"; TEMP_LIMIT="43" ;;
        oppo_a57)             DEVICE_TIP="OPPO A57(天玑700)"; TEMP_LIMIT="44" ;;
        oppo_a55)             DEVICE_TIP="OPPO A55(天玑700)"; TEMP_LIMIT="44" ;;
        oppo_a53)             DEVICE_TIP="OPPO A53(天玑720)"; TEMP_LIMIT="44" ;;
        oppo_a52)             DEVICE_TIP="OPPO A52(骁龙665)"; TEMP_LIMIT="44" ;;
        oppo_a37)             DEVICE_TIP="OPPO A37(联发科MT6750)"; TEMP_LIMIT="43" ;;
        oppo_a35)             DEVICE_TIP="OPPO A35(联发科P35)"; TEMP_LIMIT="43" ;;
        oppo_a33)             DEVICE_TIP="OPPO A33(骁龙410)"; TEMP_LIMIT="43" ;;
        oppo_a32)             DEVICE_TIP="OPPO A32(骁龙460)"; TEMP_LIMIT="43" ;;
        oppo_a31)             DEVICE_TIP="OPPO A31(联发科P35)"; TEMP_LIMIT="43" ;;
        oppo_a15)             DEVICE_TIP="OPPO A15(联发科P35)"; TEMP_LIMIT="43" ;;
        oppo_a11)             DEVICE_TIP="OPPO A11(骁龙665)"; TEMP_LIMIT="43" ;;
        oppo_a9)              DEVICE_TIP="OPPO A9(联发科P70)"; TEMP_LIMIT="43" ;;
        oppo_a7)              DEVICE_TIP="OPPO A7(骁龙450)"; TEMP_LIMIT="43" ;;
        oppo_a5s)             DEVICE_TIP="OPPO A5s(联发科MT6765)"; TEMP_LIMIT="43" ;;
        oppo_a5_old)          DEVICE_TIP="OPPO A5(骁龙450)"; TEMP_LIMIT="43" ;;
        oppo_a3s)             DEVICE_TIP="OPPO A3s(骁龙450)"; TEMP_LIMIT="43" ;;
        oppo_a3_old)          DEVICE_TIP="OPPO A3(联发科P60)"; TEMP_LIMIT="43" ;;
        oppo_a1_old)          DEVICE_TIP="OPPO A1(联发科P70)"; TEMP_LIMIT="43" ;;

        # ==================== OPPO R / N / F ====================
        oppo_r17)             DEVICE_TIP="OPPO R17(骁龙670)"; TEMP_LIMIT="44" ;;
        oppo_r15)             DEVICE_TIP="OPPO R15(联发科P60)"; TEMP_LIMIT="43" ;;
        oppo_r13)             DEVICE_TIP="OPPO R13(骁龙660)"; TEMP_LIMIT="43" ;;
        oppo_r11s)            DEVICE_TIP="OPPO R11s(骁龙660)"; TEMP_LIMIT="43" ;;
        oppo_r11)             DEVICE_TIP="OPPO R11(骁龙660)"; TEMP_LIMIT="43" ;;
        oppo_r9s)             DEVICE_TIP="OPPO R9s(骁龙625)"; TEMP_LIMIT="43" ;;
        oppo_r9)              DEVICE_TIP="OPPO R9(联发科P10)"; TEMP_LIMIT="43" ;;
        oppo_r7s)             DEVICE_TIP="OPPO R7s(联发科MT6752)"; TEMP_LIMIT="43" ;;
        oppo_r7)              DEVICE_TIP="OPPO R7(联发科MT6752)"; TEMP_LIMIT="43" ;;
        oppo_r5)              DEVICE_TIP="OPPO R5(骁龙615)"; TEMP_LIMIT="43" ;;
        oppo_n3)              DEVICE_TIP="OPPO N3(骁龙801)"; TEMP_LIMIT="43" ;;
        oppo_n1_mini)         DEVICE_TIP="OPPO N1 mini(骁龙400)"; TEMP_LIMIT="43" ;;
        oppo_n1)              DEVICE_TIP="OPPO N1(骁龙600)"; TEMP_LIMIT="43" ;;
        oppo_f27)             DEVICE_TIP="OPPO F27(天玑6300)"; TEMP_LIMIT="44" ;;
        oppo_f25_pro)         DEVICE_TIP="OPPO F25Pro(天玑7050)"; TEMP_LIMIT="44" ;;
        oppo_f25)             DEVICE_TIP="OPPO F25(骁龙6Gen1)"; TEMP_LIMIT="44" ;;
        oppo_f23)             DEVICE_TIP="OPPO F23(骁龙695)"; TEMP_LIMIT="44" ;;
        oppo_f21_pro)         DEVICE_TIP="OPPO F21Pro(骁龙680)"; TEMP_LIMIT="44" ;;
        oppo_f21s_pro)        DEVICE_TIP="OPPO F21sPro(骁龙680)"; TEMP_LIMIT="44" ;;
        oppo_f21)             DEVICE_TIP="OPPO F21(天玑700)"; TEMP_LIMIT="44" ;;
        oppo_f19_pro)         DEVICE_TIP="OPPO F19Pro(联发科P95)"; TEMP_LIMIT="44" ;;
        oppo_f19)             DEVICE_TIP="OPPO F19(骁龙662)"; TEMP_LIMIT="44" ;;
        oppo_f17_pro)         DEVICE_TIP="OPPO F17Pro(联发科P95)"; TEMP_LIMIT="44" ;;
        oppo_f17)             DEVICE_TIP="OPPO F17(骁龙662)"; TEMP_LIMIT="44" ;;
        oppo_f15)             DEVICE_TIP="OPPO F15(联发科P70)"; TEMP_LIMIT="43" ;;
        oppo_f11_pro)         DEVICE_TIP="OPPO F11Pro(联发科P70)"; TEMP_LIMIT="43" ;;
        oppo_f11)             DEVICE_TIP="OPPO F11(联发科P70)"; TEMP_LIMIT="43" ;;
        oppo_f9_pro)          DEVICE_TIP="OPPO F9Pro(联发科P60)"; TEMP_LIMIT="43" ;;
        oppo_f9)              DEVICE_TIP="OPPO F9(联发科P60)"; TEMP_LIMIT="43" ;;
        oppo_f7)              DEVICE_TIP="OPPO F7(联发科P60)"; TEMP_LIMIT="43" ;;
        oppo_f5)              DEVICE_TIP="OPPO F5(联发科P23)"; TEMP_LIMIT="43" ;;
        oppo_f3)              DEVICE_TIP="OPPO F3(联发科MT6750)"; TEMP_LIMIT="43" ;;
        oppo_f1s)             DEVICE_TIP="OPPO F1s(联发科MT6750)"; TEMP_LIMIT="43" ;;
        oppo_f1)              DEVICE_TIP="OPPO F1(骁龙616)"; TEMP_LIMIT="43" ;;

        # ==================== OPPO Pad ====================
        oppo_pad_4_pro)       DEVICE_TIP="OPPO Pad4Pro(骁龙8Elite)"; BIG_MIN="2000000"; TEMP_LIMIT="46"; ENABLE_BYPASS_CHARGE=1 ;;
        oppo_pad_4)           DEVICE_TIP="OPPO Pad4(骁龙8Gen3)"; BIG_MIN="1800000"; TEMP_LIMIT="46"; ENABLE_BYPASS_CHARGE=1 ;;
        oppo_pad_3_pro)       DEVICE_TIP="OPPO Pad3Pro(骁龙8Gen3)"; BIG_MIN="1800000"; TEMP_LIMIT="46"; ENABLE_BYPASS_CHARGE=1 ;;
        oppo_pad_3)           DEVICE_TIP="OPPO Pad3(天玑8350)"; BIG_MIN="1500000"; TEMP_LIMIT="45" ;;
        oppo_pad_2)           DEVICE_TIP="OPPO Pad2(天玑9000)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        oppo_pad_air2)        DEVICE_TIP="OPPO Pad Air2(骁龙6Gen1)"; TEMP_LIMIT="44" ;;
        oppo_pad_air)         DEVICE_TIP="OPPO Pad Air(骁龙680)"; TEMP_LIMIT="44" ;;
        oppo_pad_se)          DEVICE_TIP="OPPO Pad SE(骁龙680)"; TEMP_LIMIT="44" ;;
        oppo_pad)             DEVICE_TIP="OPPO Pad(骁龙870)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;

        # ==================== 一加 ====================
        oneplus_15_ultra)     DEVICE_TIP="一加15Ultra(骁龙8Elite Gen5)"; BIG_MIN="2200000"; BIG_MAX="4400000"; TEMP_LIMIT="48" ;;
        oneplus_15t)          DEVICE_TIP="一加15T(骁龙8Elite Gen5)"; BIG_MIN="2200000"; TEMP_LIMIT="47" ;;
        oneplus_15)           DEVICE_TIP="一加15(骁龙8Elite Gen5)"; BIG_MIN="2200000"; TEMP_LIMIT="48" ;;
        oneplus_13t)          DEVICE_TIP="一加13T(骁龙8Elite)"; BIG_MIN="2000000"; TEMP_LIMIT="46" ;;
        oneplus_13)           DEVICE_TIP="一加13(骁龙8Elite)"; BIG_MIN="2000000"; BIG_MAX="4200000"; TEMP_LIMIT="47" ;;
        oneplus_12r)          DEVICE_TIP="一加12R(骁龙8Gen2)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        oneplus_12)           DEVICE_TIP="一加12(骁龙8Gen3)"; BIG_MIN="1800000"; TEMP_LIMIT="47" ;;
        oneplus_11)           DEVICE_TIP="一加11(骁龙8Gen2)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        oneplus_10t)          DEVICE_TIP="一加10T(骁龙8+Gen1)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        oneplus_10_pro)       DEVICE_TIP="一加10Pro(骁龙8Gen1)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        oneplus_9rt)          DEVICE_TIP="一加9RT(骁龙888)"; BIG_MIN="1800000"; TEMP_LIMIT="44" ;;
        oneplus_9r)           DEVICE_TIP="一加9R(骁龙870)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        oneplus_9_pro)        DEVICE_TIP="一加9Pro(骁龙888)"; BIG_MIN="1800000"; TEMP_LIMIT="44" ;;
        oneplus_9)            DEVICE_TIP="一加9(骁龙888)"; BIG_MIN="1800000"; TEMP_LIMIT="44" ;;
        oneplus_8t)           DEVICE_TIP="一加8T(骁龙865)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        oneplus_8_pro)        DEVICE_TIP="一加8Pro(骁龙865)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        oneplus_8)            DEVICE_TIP="一加8(骁龙865)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        oneplus_7t_pro)       DEVICE_TIP="一加7TPro(骁龙855+)"; BIG_MIN="1785600"; TEMP_LIMIT="44" ;;
        oneplus_7t)           DEVICE_TIP="一加7T(骁龙855+)"; BIG_MIN="1785600"; TEMP_LIMIT="44" ;;
        oneplus_7_pro)        DEVICE_TIP="一加7Pro(骁龙855)"; BIG_MIN="1785600"; TEMP_LIMIT="44" ;;
        oneplus_7)            DEVICE_TIP="一加7(骁龙855)"; BIG_MIN="1785600"; TEMP_LIMIT="44" ;;
        oneplus_6t)           DEVICE_TIP="一加6T(骁龙845)"; BIG_MIN="1766400"; TEMP_LIMIT="44" ;;
        oneplus_6)            DEVICE_TIP="一加6(骁龙845)"; BIG_MIN="1766400"; TEMP_LIMIT="44" ;;
        oneplus_5t)           DEVICE_TIP="一加5T(骁龙835)"; BIG_MIN="1766400"; TEMP_LIMIT="44" ;;
        oneplus_5)            DEVICE_TIP="一加5(骁龙835)"; BIG_MIN="1766400"; TEMP_LIMIT="44" ;;
        oneplus_3t)           DEVICE_TIP="一加3T(骁龙821)"; TEMP_LIMIT="43" ;;
        oneplus_3)            DEVICE_TIP="一加3(骁龙820)"; TEMP_LIMIT="43" ;;
        oneplus_2)            DEVICE_TIP="一加2(骁龙810)"; TEMP_LIMIT="43" ;;
        oneplus_1)            DEVICE_TIP="一加1(骁龙801)"; TEMP_LIMIT="43" ;;
        oneplus_x)            DEVICE_TIP="一加X(骁龙801)"; TEMP_LIMIT="43" ;;

        # ==================== 一加 Ace ====================
        oneplus_ace_6_pro)    DEVICE_TIP="一加Ace6Pro(骁龙8Elite Gen5)"; BIG_MIN="2200000"; TEMP_LIMIT="48" ;;
        oneplus_ace_6)        DEVICE_TIP="一加Ace6(骁龙8Elite Gen5)"; BIG_MIN="2200000"; TEMP_LIMIT="47" ;;
        oneplus_ace_5_pro)    DEVICE_TIP="一加Ace5Pro(骁龙8Elite)"; BIG_MIN="2000000"; TEMP_LIMIT="47" ;;
        oneplus_ace_5)        DEVICE_TIP="一加Ace5(骁龙8Gen3)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        oneplus_ace_3_pro)    DEVICE_TIP="一加Ace3Pro(骁龙8Gen3)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        oneplus_ace_3v)       DEVICE_TIP="一加Ace3V(骁龙7+Gen3)"; TEMP_LIMIT="45" ;;
        oneplus_ace_3)        DEVICE_TIP="一加Ace3(骁龙8Gen2)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        oneplus_ace_2_pro)    DEVICE_TIP="一加Ace2Pro(骁龙8Gen2)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        oneplus_ace_2v)       DEVICE_TIP="一加Ace2V(天玑9000)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        oneplus_ace_2)        DEVICE_TIP="一加Ace2(骁龙8+Gen1)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        oneplus_ace_racing)   DEVICE_TIP="一加Ace竞速版(天玑8100-MAX)"; BIG_MIN="1500000"; TEMP_LIMIT="45" ;;
        oneplus_ace)          DEVICE_TIP="一加Ace(天玑8100-MAX)"; BIG_MIN="1500000"; TEMP_LIMIT="45" ;;

        # ==================== 一加 Nord ====================
        oneplus_nord_5)       DEVICE_TIP="一加Nord5(骁龙8sGen4)"; BIG_MIN="1500000"; TEMP_LIMIT="46" ;;
        oneplus_nord_4)       DEVICE_TIP="一加Nord4(骁龙7+Gen3)"; TEMP_LIMIT="45" ;;
        oneplus_nord_3)       DEVICE_TIP="一加Nord3(天玑9000)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        oneplus_nord_2t)      DEVICE_TIP="一加Nord2T(天玑1300)"; BIG_MIN="1500000"; TEMP_LIMIT="44" ;;
        oneplus_nord_2)       DEVICE_TIP="一加Nord2(天玑1200)"; BIG_MIN="1500000"; TEMP_LIMIT="44" ;;
        oneplus_nord_ce4)     DEVICE_TIP="一加Nord CE4(骁龙7Gen3)"; TEMP_LIMIT="45" ;;
        oneplus_nord_ce3)     DEVICE_TIP="一加Nord CE3(骁龙782G)"; TEMP_LIMIT="45" ;;
        oneplus_nord_ce2)     DEVICE_TIP="一加Nord CE2(天玑900)"; TEMP_LIMIT="44" ;;
        oneplus_nord_ce)      DEVICE_TIP="一加Nord CE(天玑1200)"; BIG_MIN="1500000"; TEMP_LIMIT="44" ;;
        oneplus_nord_n30)     DEVICE_TIP="一加Nord N30(骁龙695)"; TEMP_LIMIT="44" ;;
        oneplus_nord_n20)     DEVICE_TIP="一加Nord N20(骁龙695)"; TEMP_LIMIT="44" ;;
        oneplus_nord_n10)     DEVICE_TIP="一加Nord N10(骁龙690)"; TEMP_LIMIT="44" ;;
        oneplus_nord_n100)    DEVICE_TIP="一加Nord N100(骁龙460)"; TEMP_LIMIT="43" ;;
        oneplus_nord)         DEVICE_TIP="一加Nord(骁龙765G)"; TEMP_LIMIT="44" ;;

        # ==================== 一加 Pad ====================
        oneplus_pad_2_pro)    DEVICE_TIP="一加平板2Pro(骁龙8Elite)"; BIG_MIN="2000000"; TEMP_LIMIT="46"; ENABLE_BYPASS_CHARGE=1 ;;
        oneplus_pad_2)        DEVICE_TIP="一加平板2(骁龙8Gen3)"; BIG_MIN="1800000"; TEMP_LIMIT="46"; ENABLE_BYPASS_CHARGE=1 ;;
        oneplus_pad_go)       DEVICE_TIP="一加平板Go(骁龙695)"; TEMP_LIMIT="44" ;;
        oneplus_pad)          DEVICE_TIP="一加平板(天玑9000)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;

        # ==================== realme GT ====================
        realme_gt7_pro)       DEVICE_TIP="真我GT7Pro(骁龙8Elite)"; BIG_MIN="2000000"; TEMP_LIMIT="47" ;;
        realme_gt7)           DEVICE_TIP="真我GT7(天玑9400+)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        realme_gt6)           DEVICE_TIP="真我GT6(骁龙8Gen3)"; BIG_MIN="1800000"; TEMP_LIMIT="47" ;;
        realme_gt5_pro)       DEVICE_TIP="真我GT5Pro(骁龙8Gen3)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        realme_gt5)           DEVICE_TIP="真我GT5(骁龙8Gen2)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        realme_gt3)           DEVICE_TIP="真我GT3(骁龙8+Gen1)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        realme_gt2_explorer)  DEVICE_TIP="真我GT2大师探索版(骁龙8+Gen1)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        realme_gt2_pro)       DEVICE_TIP="真我GT2Pro(骁龙8Gen1)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        realme_gt2)           DEVICE_TIP="真我GT2(骁龙888)"; BIG_MIN="1800000"; TEMP_LIMIT="44" ;;
        realme_gt_explorer)   DEVICE_TIP="真我GT大师探索版(骁龙870)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        realme_gt_neo_flash)  DEVICE_TIP="真我GTNeo闪速版(天玑1200)"; BIG_MIN="1500000"; TEMP_LIMIT="44" ;;
        realme_gt)            DEVICE_TIP="真我GT(骁龙888)"; BIG_MIN="1800000"; TEMP_LIMIT="44" ;;

        # ==================== realme GT Neo ====================
        realme_gt_neo_6_se)   DEVICE_TIP="真我GTNeo6SE(骁龙7+Gen3)"; TEMP_LIMIT="45" ;;
        realme_gt_neo_6)      DEVICE_TIP="真我GTNeo6(骁龙8sGen3)"; BIG_MIN="1500000"; TEMP_LIMIT="46" ;;
        realme_gt_neo_5_se)   DEVICE_TIP="真我GTNeo5SE(骁龙7+Gen2)"; TEMP_LIMIT="45" ;;
        realme_gt_neo_5)      DEVICE_TIP="真我GTNeo5(骁龙8+Gen1)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        realme_gt_neo_3)      DEVICE_TIP="真我GTNeo3(天玑8100)"; BIG_MIN="1500000"; TEMP_LIMIT="45" ;;
        realme_gt_neo_2t)     DEVICE_TIP="真我GTNeo2T(天玑1200-AI)"; BIG_MIN="1500000"; TEMP_LIMIT="44" ;;
        realme_gt_neo_2)      DEVICE_TIP="真我GTNeo2(骁龙870)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        realme_gt_neo)        DEVICE_TIP="真我GTNeo(天玑1200)"; BIG_MIN="1500000"; TEMP_LIMIT="44" ;;

        # ==================== realme 数字 ====================
        realme_15_pro)        DEVICE_TIP="真我15Pro(骁龙7Gen4)"; TEMP_LIMIT="45" ;;
        realme_15)            DEVICE_TIP="真我15(天玑7300)"; TEMP_LIMIT="45" ;;
        realme_14_pro_plus)   DEVICE_TIP="真我14Pro+(骁龙7sGen3)"; TEMP_LIMIT="45" ;;
        realme_14_pro)        DEVICE_TIP="真我14Pro(骁龙7sGen3)"; TEMP_LIMIT="45" ;;
        realme_14)            DEVICE_TIP="真我14(骁龙6Gen4)"; TEMP_LIMIT="44" ;;
        realme_13_pro_plus)   DEVICE_TIP="真我13Pro+(骁龙7sGen2)"; TEMP_LIMIT="45" ;;
        realme_13_pro)        DEVICE_TIP="真我13Pro(天玑7300)"; TEMP_LIMIT="45" ;;
        realme_13)            DEVICE_TIP="真我13(天玑6300)"; TEMP_LIMIT="44" ;;
        realme_12_pro_plus)   DEVICE_TIP="真我12Pro+(骁龙7sGen2)"; TEMP_LIMIT="45" ;;
        realme_12_pro)        DEVICE_TIP="真我12Pro(骁龙6Gen1)"; TEMP_LIMIT="44" ;;
        realme_12)            DEVICE_TIP="真我12(天玑6100+)"; TEMP_LIMIT="44" ;;
        realme_11_pro_plus)   DEVICE_TIP="真我11Pro+(天玑7050)"; TEMP_LIMIT="44" ;;
        realme_11_pro)        DEVICE_TIP="真我11Pro(天玑7050)"; TEMP_LIMIT="44" ;;
        realme_11)            DEVICE_TIP="真我11(天玑6020)"; TEMP_LIMIT="44" ;;
        realme_10_pro_plus)   DEVICE_TIP="真我10Pro+(天玑1080)"; TEMP_LIMIT="44" ;;
        realme_10_pro)        DEVICE_TIP="真我10Pro(骁龙695)"; TEMP_LIMIT="44" ;;
        realme_10)            DEVICE_TIP="真我10(天玑700)"; TEMP_LIMIT="44" ;;
        realme_9_pro_plus)    DEVICE_TIP="真我9Pro+(骁龙870)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        realme_9_pro)         DEVICE_TIP="真我9Pro(骁龙695)"; TEMP_LIMIT="44" ;;
        realme_9i)            DEVICE_TIP="真我9i(骁龙680)"; TEMP_LIMIT="44" ;;
        realme_9)             DEVICE_TIP="真我9(骁龙680)"; TEMP_LIMIT="44" ;;
        realme_8_pro)         DEVICE_TIP="真我8Pro(骁龙720G)"; TEMP_LIMIT="44" ;;
        realme_8i)            DEVICE_TIP="真我8i(联发科G96)"; TEMP_LIMIT="44" ;;
        realme_8)             DEVICE_TIP="真我8(联发科G95)"; TEMP_LIMIT="44" ;;
        realme_7_pro)         DEVICE_TIP="真我7Pro(骁龙720G)"; TEMP_LIMIT="44" ;;
        realme_7i)            DEVICE_TIP="真我7i(骁龙720G)"; TEMP_LIMIT="44" ;;
        realme_7)             DEVICE_TIP="真我7(联发科G95)"; TEMP_LIMIT="44" ;;
        realme_6_pro)         DEVICE_TIP="真我6Pro(骁龙720G)"; TEMP_LIMIT="44" ;;
        realme_6i)            DEVICE_TIP="真我6i(联发科G80)"; TEMP_LIMIT="44" ;;
        realme_6)             DEVICE_TIP="真我6(联发科G90T)"; TEMP_LIMIT="44" ;;
        realme_5_pro)         DEVICE_TIP="真我5Pro(骁龙712)"; TEMP_LIMIT="44" ;;
        realme_5i)            DEVICE_TIP="真我5i(联发科G80)"; TEMP_LIMIT="44" ;;
        realme_5)             DEVICE_TIP="真我5(骁龙665)"; TEMP_LIMIT="43" ;;
        realme_3_pro)         DEVICE_TIP="真我3Pro(骁龙710)"; TEMP_LIMIT="44" ;;
        realme_3i)            DEVICE_TIP="真我3i(联发科P60)"; TEMP_LIMIT="43" ;;
        realme_3)             DEVICE_TIP="真我3(联发科P60)"; TEMP_LIMIT="43" ;;
        realme_2_pro)         DEVICE_TIP="真我2Pro(骁龙660)"; TEMP_LIMIT="43" ;;
        realme_2)             DEVICE_TIP="真我2(骁龙450)"; TEMP_LIMIT="43" ;;
        realme_1)             DEVICE_TIP="真我1(联发科P60)"; TEMP_LIMIT="43" ;;

        # ==================== realme Narzo / C / V / Q / X / U / Pad ====================
        realme_narzo_70_pro)  DEVICE_TIP="真我Narzo70Pro(骁龙685)"; TEMP_LIMIT="44" ;;
        realme_narzo_70x)     DEVICE_TIP="真我Narzo70x(天玑6300)"; TEMP_LIMIT="44" ;;
        realme_narzo_70)      DEVICE_TIP="真我Narzo70(天玑6300)"; TEMP_LIMIT="44" ;;
        realme_narzo_60_pro)  DEVICE_TIP="真我Narzo60Pro(天玑7050)"; TEMP_LIMIT="44" ;;
        realme_narzo_60x)     DEVICE_TIP="真我Narzo60x(天玑6100+)"; TEMP_LIMIT="44" ;;
        realme_narzo_60)      DEVICE_TIP="真我Narzo60(天玑6020)"; TEMP_LIMIT="44" ;;
        realme_narzo_50_pro)  DEVICE_TIP="真我Narzo50Pro(骁龙695)"; TEMP_LIMIT="44" ;;
        realme_narzo_50i)     DEVICE_TIP="真我Narzo50i(联发科G85)"; TEMP_LIMIT="43" ;;
        realme_narzo_50)      DEVICE_TIP="真我Narzo50(天玑810)"; TEMP_LIMIT="44" ;;
        realme_narzo_30_pro)  DEVICE_TIP="真我Narzo30Pro(天玑800U)"; TEMP_LIMIT="44" ;;
        realme_narzo_30)      DEVICE_TIP="真我Narzo30(联发科G95)"; TEMP_LIMIT="44" ;;
        realme_narzo_20_pro)  DEVICE_TIP="真我Narzo20Pro(联发科G95)"; TEMP_LIMIT="44" ;;
        realme_narzo_20)      DEVICE_TIP="真我Narzo20(联发科G85)"; TEMP_LIMIT="43" ;;
        realme_narzo_10)      DEVICE_TIP="真我Narzo10(联发科G80)"; TEMP_LIMIT="43" ;;
        realme_c75)           DEVICE_TIP="真我C75(骁龙685)"; TEMP_LIMIT="44" ;;
        realme_c67)           DEVICE_TIP="真我C67(骁龙685)"; TEMP_LIMIT="44" ;;
        realme_c65)           DEVICE_TIP="真我C65(联发科G85)"; TEMP_LIMIT="43" ;;
        realme_c61)           DEVICE_TIP="真我C61(联发科G36)"; TEMP_LIMIT="43" ;;
        realme_c55)           DEVICE_TIP="真我C55(联发科G88)"; TEMP_LIMIT="43" ;;
        realme_c53)           DEVICE_TIP="真我C53(紫光展锐)"; TEMP_LIMIT="43" ;;
        realme_c51)           DEVICE_TIP="真我C51(紫光展锐)"; TEMP_LIMIT="43" ;;
        realme_c35)           DEVICE_TIP="真我C35(紫光展锐)"; TEMP_LIMIT="43" ;;
        realme_c33)           DEVICE_TIP="真我C33(紫光展锐)"; TEMP_LIMIT="43" ;;
        realme_c31)           DEVICE_TIP="真我C31(紫光展锐)"; TEMP_LIMIT="43" ;;
        realme_c30)           DEVICE_TIP="真我C30(联发科G85)"; TEMP_LIMIT="43" ;;
        realme_c25)           DEVICE_TIP="真我C25(骁龙665)"; TEMP_LIMIT="43" ;;
        realme_c21)           DEVICE_TIP="真我C21(骁龙665)"; TEMP_LIMIT="43" ;;
        realme_c20)           DEVICE_TIP="真我C20(联发科G35)"; TEMP_LIMIT="43" ;;
        realme_c17)           DEVICE_TIP="真我C17(联发科G35)"; TEMP_LIMIT="43" ;;
        realme_c15)           DEVICE_TIP="真我C15(联发科G35)"; TEMP_LIMIT="43" ;;
        realme_c12)           DEVICE_TIP="真我C12(联发科G35)"; TEMP_LIMIT="43" ;;
        realme_c11)           DEVICE_TIP="真我C11(联发科G35)"; TEMP_LIMIT="43" ;;
        realme_c3)            DEVICE_TIP="真我C3(联发科G70)"; TEMP_LIMIT="43" ;;
        realme_c2)            DEVICE_TIP="真我C2(联发科A22)"; TEMP_LIMIT="43" ;;
        realme_c1)            DEVICE_TIP="真我C1(联发科A22)"; TEMP_LIMIT="43" ;;
        realme_v50)           DEVICE_TIP="真我V50(天玑6100+)"; TEMP_LIMIT="44" ;;
        realme_v30)           DEVICE_TIP="真我V30(天玑700)"; TEMP_LIMIT="44" ;;
        realme_v25)           DEVICE_TIP="真我V25(骁龙695)"; TEMP_LIMIT="44" ;;
        realme_v23)           DEVICE_TIP="真我V23(骁龙695)"; TEMP_LIMIT="44" ;;
        realme_v15)           DEVICE_TIP="真我V15(天玑800U)"; TEMP_LIMIT="44" ;;
        realme_v13)           DEVICE_TIP="真我V13(天玑700)"; TEMP_LIMIT="44" ;;
        realme_v11)           DEVICE_TIP="真我V11(天玑700)"; TEMP_LIMIT="44" ;;
        realme_v5)            DEVICE_TIP="真我V5(天玑720)"; TEMP_LIMIT="44" ;;
        realme_v3)            DEVICE_TIP="真我V3(天玑720)"; TEMP_LIMIT="44" ;;
        realme_q5)            DEVICE_TIP="真我Q5(骁龙695)"; TEMP_LIMIT="44" ;;
        realme_q3)            DEVICE_TIP="真我Q3(骁龙750G)"; TEMP_LIMIT="44" ;;
        realme_q2)            DEVICE_TIP="真我Q2(天玑800U)"; TEMP_LIMIT="44" ;;
        realme_x50_pro)       DEVICE_TIP="真我X50Pro(骁龙865)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        realme_x50)           DEVICE_TIP="真我X50(骁龙765G)"; TEMP_LIMIT="44" ;;
        realme_x7_pro)        DEVICE_TIP="真我X7Pro(天玑1000+)"; BIG_MIN="1500000"; TEMP_LIMIT="44" ;;
        realme_x7)            DEVICE_TIP="真我X7(天玑800U)"; TEMP_LIMIT="44" ;;
        realme_x3)            DEVICE_TIP="真我X3(骁龙855+)"; BIG_MIN="1785600"; TEMP_LIMIT="44" ;;
        realme_x2_pro)        DEVICE_TIP="真我X2Pro(骁龙855+)"; BIG_MIN="1785600"; TEMP_LIMIT="44" ;;
        realme_x2)            DEVICE_TIP="真我X2(骁龙730G)"; TEMP_LIMIT="44" ;;
        realme_x)             DEVICE_TIP="真我X(骁龙710)"; TEMP_LIMIT="44" ;;
        realme_u1)            DEVICE_TIP="真我U1(联发科P70)"; TEMP_LIMIT="43" ;;
        realme_pad_x)         DEVICE_TIP="真我PadX(骁龙695)"; TEMP_LIMIT="44" ;;
        realme_pad_mini)      DEVICE_TIP="真我PadMini(紫光展锐)"; TEMP_LIMIT="43" ;;
        realme_pad)           DEVICE_TIP="真我Pad(联发科G80)"; TEMP_LIMIT="44" ;;

        *)                    DEVICE_TIP="通用设备"; TEMP_LIMIT="45" ;;
    esac
}