#!/system/bin/sh
MODDIR=${0%/*}
echo "=============================="
echo "   勝豪米家调度 - 手动控制"
echo "=============================="
echo "1. 性能模式"
echo "2. 均衡模式"
echo "3. 省电模式"
echo "4. 查看设备识别结果"
echo "5. 查看当前状态"
echo "0. 退出"
read -p "选择: " c

case "$c" in
    1) for cpu in /sys/devices/system/cpu/cpu[0-9]*; do echo performance > $cpu/cpufreq/scaling_governor 2>/dev/null; done; echo "✓ 性能模式" ;;
    2) for cpu in /sys/devices/system/cpu/cpu[0-9]*; do echo schedutil > $cpu/cpufreq/scaling_governor 2>/dev/null; done; echo "✓ 均衡模式" ;;
    3) for cpu in /sys/devices/system/cpu/cpu[0-9]*; do echo powersave > $cpu/cpufreq/scaling_governor 2>/dev/null; done; echo "✓ 省电模式" ;;
    4) cat "$MODDIR/webroot/soc_name.txt" 2>/dev/null; cat "$MODDIR/webroot/device_name.txt" 2>/dev/null ;;
    5) echo "调度: $(cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor)"; echo "温度: $(($(cat /sys/class/thermal/thermal_zone0/temp)/1000))°C" ;;
esac