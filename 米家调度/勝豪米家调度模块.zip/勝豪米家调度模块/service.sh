#!/system/bin/sh
# =====================================================
#         勝豪米家调度 - 核心守护脚本
#         作者：勝豪  Q群：1022873156
# =====================================================

MODDIR=${0%/*}
LOG_FILE="/sdcard/勝豪米家调度.log"
STATUS_JSON="$MODDIR/webroot/status.json"
BACKUP_DIR="$MODDIR/backup"
mkdir -p "$BACKUP_DIR"

[ -f "$MODDIR/soc_db.sh" ] && . "$MODDIR/soc_db.sh"
[ -f "$MODDIR/devices_db.sh" ] && . "$MODDIR/devices_db.sh"

log() { echo "[$(date '+%m-%d %H:%M:%S')] $1" >> "$LOG_FILE"; }
wr() { [ -e "$1" ] && echo "$2" > "$1" 2>/dev/null && return 0 || return 1; }

# 等待系统启动
until [ "$(getprop sys.boot_completed)" = "1" ]; do sleep 3; done
sleep 15
log "===== 勝豪米家调度 v1.0 启动 ====="

# 芯片识别
PLATFORM=$(getprop ro.board.platform)
HARDWARE=$(getprop ro.hardware)
SOC_MODEL=$(getprop ro.soc.model)
MEDIATEK=$(getprop ro.vendor.mediatek.platform)
ALL_INFO="${PLATFORM}|${HARDWARE}|${SOC_MODEL}|${MEDIATEK}"

log "芯片信息: $ALL_INFO"

detect_soc_function() {
    case "$ALL_INFO" in
        *sm8750*|*sun*)                    echo "soc_sd8elite" ;;
        *sm8650*|*pineapple*)              echo "soc_sd8gen3" ;;
        *sm8550*|*kalama*)                 echo "soc_sd8gen2" ;;
        *sm8475*|*cape*)                   echo "soc_sd8gen1p" ;;
        *sm8450*|*taro*|*waipio*)          echo "soc_sd8gen1" ;;
        *sm8350*|*lahaina*)                echo "soc_sd888" ;;
        *sm8250*|*kona*)                   echo "soc_sd870_865" ;;
        *sm8150*|*msmnile*)                echo "soc_sd855_855p" ;;
        *sdm845*)                          echo "soc_sd845" ;;
        *msm8998*)                         echo "soc_sd835" ;;
        *sm7675*|*crow*)                   echo "soc_sd7pgen3" ;;
        *sm7475*|*ukee*)                   echo "soc_sd7pgen2" ;;
        *sm7550*)                          echo "soc_sd7gen3" ;;
        *sm7435*|*parrot*)                 echo "soc_sd7sgen2" ;;
        *sm7325*|*holi*)                   echo "soc_sd778g" ;;
        *sm7250*|*lito*)                   echo "soc_sd768g_765g" ;;
        *sm7150*)                          echo "soc_sd732g_730g" ;;
        *sm7125*|*atoll*)                  echo "soc_sd720g" ;;
        *sdm710*)                          echo "soc_sd712_710" ;;
        *sm6375*|*khaje*)                  echo "soc_sd695" ;;
        *sm6350*|*lagoon*)                 echo "soc_sd690" ;;
        *sm6225*)                          echo "soc_sd680_685" ;;
        *sm6115*|*bengal*)                 echo "soc_sd662" ;;
        *sdm660*)                          echo "soc_sd665_660" ;;
        *msm8937*)                         echo "soc_sd439_429" ;;
        *msm8953*)                         echo "soc_sd450_425" ;;
        *mt6991*|*mt6992*)                 echo "soc_d9400" ;;
        *mt6989*)                          echo "soc_d9300" ;;
        *mt6985*)                          echo "soc_d9200" ;;
        *mt6983*)                          echo "soc_d9000" ;;
        *mt6899*)                          echo "soc_d8400" ;;
        *mt6897*)                          echo "soc_d8300" ;;
        *mt6896*)                          echo "soc_d8200" ;;
        *mt6895*)                          echo "soc_d8100" ;;
        *mt6878*)                          echo "soc_d7300" ;;
        *mt6886*)                          echo "soc_d7200" ;;
        *mt6833*|*mt6835*)                 echo "soc_d700" ;;
        *mt6877*|*mt6879*)                 echo "soc_d900" ;;
        *mt6893*)                          echo "soc_d1200" ;;
        *mt6891*)                          echo "soc_d1100" ;;
        *mt6789*)                          echo "soc_helio_g99" ;;
        *mt6785*)                          echo "soc_helio_g90t" ;;
        *mt6769*)                          echo "soc_helio_g85" ;;
        *mt6765*)                          echo "soc_mt6765" ;;
        *ums9230*|*t612*)                  echo "soc_t612" ;;
        *ums9230*|*t606*)                  echo "soc_t606" ;;
        *sc9863a*)                         echo "soc_sc9863a" ;;
        *)                                 echo "soc_generic" ;;
    esac
}

SOC_FUNC=$(detect_soc_function)
log "匹配芯片函数: $SOC_FUNC"
$SOC_FUNC
log "芯片: $SOC_NAME | 大核: $BIG_CORES | 范围: $BIG_MIN ~ $BIG_MAX"

# 设备识别
DEVICE_MODEL=$(getprop ro.product.model)
log "设备型号: $DEVICE_MODEL"

DEVICE_PROFILE=$(detect_device_profile "$DEVICE_MODEL")
log "设备档案: $DEVICE_PROFILE"

TEMP_LIMIT="45"
ENABLE_BYPASS_CHARGE=0
apply_device_profile "$DEVICE_PROFILE"

log "设备: $DEVICE_TIP | 温控阈值: $TEMP_LIMIT°C"

echo "$SOC_NAME" > "$MODDIR/webroot/soc_name.txt"
echo "$DEVICE_TIP" > "$MODDIR/webroot/device_name.txt"
echo "$DEVICE_PROFILE" > "$MODDIR/webroot/device_profile.txt"

# 备份
if [ ! -f "$BACKUP_DIR/default_governor" ]; then
    cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor > "$BACKUP_DIR/default_governor" 2>/dev/null
fi

# 状态输出
update_status() {
    local mode="$1"
    local freq=$(cat /sys/devices/system/cpu/cpu7/cpufreq/scaling_cur_freq 2>/dev/null)
    [ -z "$freq" ] && freq=$(cat /sys/devices/system/cpu/cpu4/cpufreq/scaling_cur_freq 2>/dev/null)
    [ -n "$freq" ] && freq="$((freq / 1000))MHz" || freq="N/A"
    local temp_raw=$(cat /sys/class/thermal/thermal_zone0/temp 2>/dev/null)
    [ -n "$temp_raw" ] && temp="$((temp_raw / 1000))°C" || temp="N/A"

    cat > "$STATUS_JSON" <<EOF
{
  "soc": "$SOC_NAME",
  "device": "$DEVICE_TIP",
  "mode": "$mode",
  "cpu_freq": "$freq",
  "temp": "$temp"
}
EOF
}

# 模式应用
apply_performance() {
    log ">> 性能模式"
    for cpu in /sys/devices/system/cpu/cpu[0-9]*; do
        wr "$cpu/cpufreq/scaling_governor" "performance"
    done
    for i in $BIG_CORES; do
        wr "/sys/devices/system/cpu/cpu$i/cpufreq/scaling_min_freq" "$BIG_MIN"
        wr "/sys/devices/system/cpu/cpu$i/cpufreq/scaling_max_freq" "$BIG_MAX"
    done
    for i in $LITTLE_CORES; do
        wr "/sys/devices/system/cpu/cpu$i/cpufreq/scaling_max_freq" "1804800"
    done
    [ -d /sys/class/kgsl/kgsl-3d0 ] && wr "/sys/class/kgsl/kgsl-3d0/devfreq/governor" "$GPU_GOV"
    for d in /sys/class/devfreq/*gpu*; do [ -d "$d" ] && wr "$d/governor" "$GPU_GOV"; done
    CURRENT_MODE="性能模式"
}

apply_balanced() {
    log ">> 均衡模式"
    for cpu in /sys/devices/system/cpu/cpu[0-9]*; do
        wr "$cpu/cpufreq/scaling_governor" "$GOVERNOR"
    done
    for i in $BIG_CORES; do
        local maxf=$(cat /sys/devices/system/cpu/cpu$i/cpufreq/cpuinfo_max_freq 2>/dev/null)
        [ -n "$maxf" ] && wr "/sys/devices/system/cpu/cpu$i/cpufreq/scaling_max_freq" "$maxf"
        wr "/sys/devices/system/cpu/cpu$i/cpufreq/scaling_min_freq" "300000"
    done
    CURRENT_MODE="均衡模式"
}

apply_powersave() {
    log ">> 省电模式"
    for cpu in /sys/devices/system/cpu/cpu[0-9]*; do
        wr "$cpu/cpufreq/scaling_governor" "powersave"
    done
    CURRENT_MODE="省电模式"
}

# 通用优化
wr /proc/sys/vm/swappiness "60"
wr /proc/sys/vm/vfs_cache_pressure "100"
wr /proc/sys/net/ipv4/tcp_congestion_control "bbr"
wr /proc/sys/net/ipv4/tcp_fastopen "3"

log "通用优化已应用"

# 动态守护循环
LAST_IS_GAME=0
log "进入动态监测"
while true; do
    CURRENT_APP=$(dumpsys window 2>/dev/null | grep mCurrentFocus | head -n 1 | sed -E 's/.*u0 ([^\/]+).*/\1/')
    [ -z "$CURRENT_APP" ] && CURRENT_APP=$(dumpsys activity activities 2>/dev/null | grep mResumedActivity | head -n 1 | sed -E 's/.*u0 ([^\/]+).*/\1/')

    temp_raw=$(cat /sys/class/thermal/thermal_zone0/temp 2>/dev/null)
    temp_int=$((temp_raw / 1000))

    IS_GAME=0
    if [ -f "$MODDIR/games.list" ]; then
        while read game; do
            [ -z "$game" ] && continue
            case "$CURRENT_APP" in
                *"$game"*) IS_GAME=1; break ;;
            esac
        done < "$MODDIR/games.list"
    fi

    if [ "$temp_int" -gt "$TEMP_LIMIT" ]; then
        apply_powersave
        update_status "温控保护 ($temp_int°C)"
    elif [ "$IS_GAME" = "1" ]; then
        [ "$LAST_IS_GAME" = "0" ] && apply_performance
        update_status "游戏模式"
    else
        [ "$LAST_IS_GAME" = "1" ] && apply_balanced
        update_status "均衡模式"
    fi

    LAST_IS_GAME=$IS_GAME
    sleep 5
done