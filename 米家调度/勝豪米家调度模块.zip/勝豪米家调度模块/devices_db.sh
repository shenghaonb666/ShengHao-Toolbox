#!/system/bin/sh
# =====================================================
#         勝豪 小米全系设备数据库
#         作者：勝豪  Q群：1022873156
# =====================================================

detect_device_profile() {
    case "$1" in

        # ==================== 小米数字系列 ====================
        *MI-ONE*|*MI1*|*MI2*|*MI2S*|*MI2A*)                echo "xiaomi_mi2" ;;
        *MI3*)                                              echo "xiaomi_mi3" ;;
        *MI4*|*MI4C*|*MI4S*|*MI4I*)                         echo "xiaomi_mi4" ;;
        *MI5*|*MI5S*|*MI5X*|*MI5C*)                         echo "xiaomi_mi5" ;;
        *MI6*|*MI6X*)                                       echo "xiaomi_mi6" ;;
        *MI8*|*MI8SE*|*MI8UD*|*MI8EE*|*MI8Lite*)           echo "xiaomi_mi8" ;;
        *MI9*|*MI9SE*|*MI9Pro*|*MI9T*|*MI9Lite*)           echo "xiaomi_mi9" ;;
        *M2001J1C*|*M2001J2C*|*小米10*|*MI10*)              echo "xiaomi_mi10" ;;
        *M2007J1SC*|*小米10Ultra*|*MI10Ultra*)              echo "xiaomi_mi10_ultra" ;;
        *小米10S*|*MI10S*)                                  echo "xiaomi_mi10s" ;;
        *小米10青春版*|*MI10Lite*)                          echo "xiaomi_mi10_lite" ;;
        *M2011K2C*|*小米11*|*MI11*)                         echo "xiaomi_mi11" ;;
        *M2102K1C*|*小米11Ultra*|*MI11Ultra*)               echo "xiaomi_mi11_ultra" ;;
        *小米11青春版*|*MI11Lite*)                          echo "xiaomi_mi11_lite" ;;
        *2201123C*|*2201122C*|*小米12S*|*MI12S*)            echo "xiaomi_mi12s" ;;
        *2206123SC*|*2206122SC*|*小米12SPro*)               echo "xiaomi_mi12s_pro" ;;
        *2203121C*|*小米12SUltra*)                          echo "xiaomi_mi12s_ultra" ;;
        *2201123G*|*小米12*|*MI12*)                         echo "xiaomi_mi12" ;;
        *2201122G*|*小米12Pro*)                             echo "xiaomi_mi12_pro" ;;
        *2211133C*|*2211133G*|*小米13*|*MI13*)              echo "xiaomi_mi13" ;;
        *2210132C*|*小米13Pro*)                             echo "xiaomi_mi13_pro" ;;
        *2304FPN6DC*|*小米13Ultra*)                         echo "xiaomi_mi13_ultra" ;;
        *23127PN0CC*|*小米14*|*MI14*)                       echo "xiaomi_mi14" ;;
        *23116PN5BC*|*小米14Pro*)                           echo "xiaomi_mi14_pro" ;;
        *2405CPX3DC*|*小米14Ultra*)                         echo "xiaomi_mi14_ultra" ;;
        *24129PN74C*|*小米15*)                              echo "xiaomi_mi15" ;;
        *2410DPN6CC*|*小米15Pro*)                           echo "xiaomi_mi15_pro" ;;
        *25010PN30C*|*25019PNF3C*|*小米15Ultra*)            echo "xiaomi_mi15_ultra" ;;
        *小米17*)                                           echo "xiaomi_mi17" ;;

        # ==================== 小米 MIX ====================
        *MIXAlpha*)                                         echo "xiaomi_mix_alpha" ;;
        *M2011J18C*|*MIXFold*|*MIXFOLD*)                    echo "xiaomi_mix_fold" ;;
        *22061218C*|*MIXFold2*)                             echo "xiaomi_mix_fold_2" ;;
        *2308CPXD0C*|*MIXFold3*)                            echo "xiaomi_mix_fold_3" ;;
        *24072PX77C*|*MIXFold4*)                            echo "xiaomi_mix_fold_4" ;;
        *2311BPN23C*|*MIXFlip*)                             echo "xiaomi_mix_flip" ;;
        *MIX*)                                              echo "xiaomi_mix" ;;

        # ==================== 小米 Note / CC / Civi ====================
        *M1910F4G*|*Note10Pro*)                             echo "xiaomi_note_10_pro" ;;
        *Note10Lite*)                                       echo "xiaomi_note_10_lite" ;;
        *Note10*|*MINote10*)                                echo "xiaomi_note_10" ;;
        *MI Note3*|*MINote3*)                               echo "xiaomi_note_3" ;;
        *MI Note*|*MINote*)                                 echo "xiaomi_note" ;;
        *CC9Pro*|*M1910F4G*)                                echo "xiaomi_cc9_pro" ;;
        *CC9e*|*M1906F9SC*)                                 echo "xiaomi_cc9e" ;;
        *MI CC9*|*M1904F3BC*)                               echo "xiaomi_cc9" ;;
        *Civi5Pro*|*25067PYE3C*)                            echo "xiaomi_civi_5_pro" ;;
        *Civi4Pro*|*24053PY09C*)                            echo "xiaomi_civi_4_pro" ;;
        *Civi3*|*23046PNC9C*)                               echo "xiaomi_civi_3" ;;
        *Civi2*|*2209129SC*)                                echo "xiaomi_civi_2" ;;
        *Civi1S*|*2201123C*)                                echo "xiaomi_civi_1s" ;;
        *Civi*|*2109119BC*)                                 echo "xiaomi_civi" ;;

        # ==================== 小米 Max / Play ====================
        *MI MAX*|*MIMAX*|*MAX2*|*MAX3*)                     echo "xiaomi_max" ;;
        *MI Play*|*MIPlay*)                                 echo "xiaomi_play" ;;

        # ==================== 小米平板 ====================
        *21051182C*|*小米平板5Pro*)                         echo "xiaomi_pad_5_pro" ;;
        *22081283C*|*小米平板5*)                            echo "xiaomi_pad_5" ;;
        *23043RP34C*|*小米平板6Pro*)                        echo "xiaomi_pad_6_pro" ;;
        *24018RPACC*|*小米平板6SPro*)                       echo "xiaomi_pad_6s_pro" ;;
        *24018RPACG*|*小米平板7Ultra*)                      echo "xiaomi_pad_7_ultra" ;;
        *24091RPADC*|*小米平板7Pro*)                        echo "xiaomi_pad_7_pro" ;;

        # ==================== Redmi K 系列 ====================
        *Redmi K90*|*K90Pro*)                               echo "redmi_k90" ;;
        *Redmi K80*|*K80Pro*|*K80Ultra*|*K80E*)             echo "redmi_k80" ;;
        *Redmi K70Pro*)                                     echo "redmi_k70_pro" ;;
        *Redmi K70*|*K70E*)                                 echo "redmi_k70" ;;
        *Redmi K60Pro*)                                     echo "redmi_k60_pro" ;;
        *Redmi K60Ultra*)                                   echo "redmi_k60_ultra" ;;
        *Redmi K60*|*K60E*)                                 echo "redmi_k60" ;;
        *Redmi K50*|*K50Pro*|*K50Ultra*|*K50G*)             echo "redmi_k50" ;;
        *Redmi K40*|*K40Pro*|*K40S*|*K40G*)                 echo "redmi_k40" ;;
        *Redmi K30*|*K30Pro*|*K30Ultra*)                    echo "redmi_k30" ;;
        *Redmi K20*|*K20Pro*)                               echo "redmi_k20" ;;

        # ==================== Redmi Note 系列 ====================
        *Redmi Note15*|*Note15Pro*)                         echo "redmi_note15" ;;
        *Redmi Note14*|*Note14Pro*)                         echo "redmi_note14" ;;
        *Redmi Note13Pro*)                                  echo "redmi_note13_pro" ;;
        *Redmi Note13*)                                     echo "redmi_note13" ;;
        *Redmi Note12Turbo*)                                echo "redmi_note12_turbo" ;;
        *Redmi Note12*)                                     echo "redmi_note12" ;;
        *Redmi Note11*)                                     echo "redmi_note11" ;;
        *Redmi Note10*)                                     echo "redmi_note10" ;;
        *Redmi Note9*)                                      echo "redmi_note9" ;;
        *Redmi Note8*)                                      echo "redmi_note8" ;;
        *Redmi Note1*)                                      echo "redmi_note1" ;;

        # ==================== Redmi Turbo 系列 ====================
        *Redmi Turbo5Max*)                                  echo "redmi_turbo_5_max" ;;
        *Redmi Turbo5*)                                     echo "redmi_turbo_5" ;;
        *Redmi Turbo4Pro*)                                  echo "redmi_turbo_4_pro" ;;
        *Redmi Turbo4*)                                     echo "redmi_turbo_4" ;;
        *Redmi Turbo3*)                                     echo "redmi_turbo_3" ;;

        # ==================== Redmi 数字/A 系列 ====================
        *Redmi 14C*)                                        echo "redmi_14c" ;;
        *Redmi 13*|*Redmi13*)                               echo "redmi_13" ;;
        *Redmi 12*|*Redmi12*)                               echo "redmi_12" ;;
        *Redmi 10*|*Redmi10*)                               echo "redmi_10" ;;
        *Redmi 9*|*Redmi9*)                                 echo "redmi_9" ;;
        *Redmi A5*)                                         echo "redmi_a5" ;;
        *Redmi A3*)                                         echo "redmi_a3" ;;
        *Redmi A2*)                                         echo "redmi_a2" ;;
        *Redmi A1*)                                         echo "redmi_a1" ;;

        # ==================== Redmi 平板 ====================
        *Redmi Pad Pro*)                                    echo "redmi_pad_pro" ;;
        *Redmi Pad SE*)                                     echo "redmi_pad_se" ;;
        *Redmi Pad*)                                        echo "redmi_pad" ;;

        # ==================== POCO F 系列 ====================
        *POCO F9 Ultra*|*POCOF9Ultra*)                      echo "poco_f9_ultra" ;;
        *POCO F9 Pro*|*POCOF9Pro*)                          echo "poco_f9_pro" ;;
        *POCO F8 Ultra*|*POCOF8Ultra*)                      echo "poco_f8_ultra" ;;
        *POCO F8 Pro*|*POCOF8Pro*)                          echo "poco_f8_pro" ;;
        *POCO F7 Ultra*|*POCOF7Ultra*)                      echo "poco_f7_ultra" ;;
        *POCO F7 Pro*|*POCOF7Pro*)                          echo "poco_f7_pro" ;;
        *POCO F7*|*POCOF7*)                                 echo "poco_f7" ;;
        *POCO F6 Pro*|*POCOF6Pro*)                          echo "poco_f6_pro" ;;
        *POCO F6*|*POCOF6*)                                 echo "poco_f6" ;;
        *POCO F5 Pro*|*POCOF5Pro*)                          echo "poco_f5_pro" ;;
        *POCO F5*|*POCOF5*)                                 echo "poco_f5" ;;
        *POCO F4 GT*|*POCOF4GT*)                            echo "poco_f4_gt" ;;
        *POCO F4*|*POCOF4*)                                 echo "poco_f4" ;;
        *POCO F3*|*POCOF3*)                                 echo "poco_f3" ;;
        *POCO F2 Pro*|*POCOF2Pro*)                          echo "poco_f2_pro" ;;
        *POCO F1*|*POCOF1*)                                 echo "poco_f1" ;;

        # ==================== POCO X 系列 ====================
        *POCO X8 Pro Max*)                                  echo "poco_x8_pro_max" ;;
        *POCO X8 Pro*|*POCOX8Pro*)                          echo "poco_x8_pro" ;;
        *POCO X8*|*POCOX8*)                                 echo "poco_x8" ;;
        *POCO X7 Pro*|*POCOX7Pro*)                          echo "poco_x7_pro" ;;
        *POCO X7*|*POCOX7*)                                 echo "poco_x7" ;;
        *POCO X6 Pro*|*POCOX6Pro*)                          echo "poco_x6_pro" ;;
        *POCO X6*|*POCOX6*)                                 echo "poco_x6" ;;
        *POCO X5 Pro*|*POCOX5Pro*)                          echo "poco_x5_pro" ;;
        *POCO X5*|*POCOX5*)                                 echo "poco_x5" ;;
        *POCO X4 GT*|*POCOX4GT*)                            echo "poco_x4_gt" ;;
        *POCO X4 Pro*|*POCOX4Pro*)                          echo "poco_x4_pro" ;;
        *POCO X3 Pro*|*POCOX3Pro*)                          echo "poco_x3_pro" ;;
        *POCO X3 NFC*|*POCOX3NFC*)                          echo "poco_x3_nfc" ;;
        *POCO X3*|*POCOX3*)                                 echo "poco_x3" ;;
        *POCO X2*|*POCOX2*)                                 echo "poco_x2" ;;

        # ==================== POCO M 系列 ====================
        *POCO M8 Pro*|*POCOM8Pro*)                          echo "poco_m8_pro" ;;
        *POCO M8*|*POCOM8*)                                 echo "poco_m8" ;;
        *POCO M7 Pro*|*POCOM7Pro*)                          echo "poco_m7_pro" ;;
        *POCO M7*|*POCOM7*)                                 echo "poco_m7" ;;
        *POCO M6 Pro*|*POCOM6Pro*)                          echo "poco_m6_pro" ;;
        *POCO M6*|*POCOM6*)                                 echo "poco_m6" ;;
        *POCO M5*|*POCOM5*)                                 echo "poco_m5" ;;
        *POCO M4 Pro*|*POCOM4Pro*)                          echo "poco_m4_pro" ;;
        *POCO M4*|*POCOM4*)                                 echo "poco_m4" ;;
        *POCO M3 Pro*|*POCOM3Pro*)                          echo "poco_m3_pro" ;;
        *POCO M3*|*POCOM3*)                                 echo "poco_m3" ;;
        *POCO M2*|*POCOM2*)                                 echo "poco_m2" ;;

        # ==================== POCO C 系列 ====================
        *POCO C95 Pro*|*POCOC95Pro*)                        echo "poco_c95_pro" ;;
        *POCO C85*|*POCOC85*)                               echo "poco_c85" ;;
        *POCO C81 Pro*|*POCOC81Pro*)                        echo "poco_c81_pro" ;;
        *POCO C75*|*POCOC75*)                               echo "poco_c75" ;;
        *POCO C71*|*POCOC71*)                               echo "poco_c71" ;;
        *POCO C65*|*POCOC65*)                               echo "poco_c65" ;;
        *POCO C61*|*POCOC61*)                               echo "poco_c61" ;;
        *POCO C55*|*POCOC55*)                               echo "poco_c55" ;;
        *POCO C51*|*POCOC51*)                               echo "poco_c51" ;;
        *POCO C50*|*POCOC50*)                               echo "poco_c50" ;;
        *POCO C40*|*POCOC40*)                               echo "poco_c40" ;;
        *POCO C31*|*POCOC31*)                               echo "poco_c31" ;;
        *POCO C3*|*POCOC3*)                                 echo "poco_c3" ;;

        *)                                                  echo "generic" ;;
    esac
}

# ==================== 设备专属参数 ====================
apply_device_profile() {
    TEMP_LIMIT="45"
    ENABLE_BYPASS_CHARGE=0

    case "$1" in

        # ---- 小米数字系列 ----
        xiaomi_mi17)        DEVICE_TIP="小米17系列(骁龙8Elite Gen5)"; BIG_MIN="2200000"; BIG_MAX="4200000"; TEMP_LIMIT="48" ;;
        xiaomi_mi15_ultra)  DEVICE_TIP="小米15Ultra(骁龙8Elite)"; BIG_MIN="2000000"; BIG_MAX="4000000"; TEMP_LIMIT="47" ;;
        xiaomi_mi15_pro)    DEVICE_TIP="小米15Pro(骁龙8Elite)"; BIG_MIN="2000000"; TEMP_LIMIT="47" ;;
        xiaomi_mi15)        DEVICE_TIP="小米15(骁龙8Elite)"; BIG_MIN="2000000"; TEMP_LIMIT="47" ;;
        xiaomi_mi14_ultra)  DEVICE_TIP="小米14Ultra(骁龙8Gen3)"; BIG_MIN="1800000"; TEMP_LIMIT="47" ;;
        xiaomi_mi14_pro)    DEVICE_TIP="小米14Pro(骁龙8Gen3)"; BIG_MIN="1800000"; TEMP_LIMIT="47" ;;
        xiaomi_mi14)        DEVICE_TIP="小米14(骁龙8Gen3)"; BIG_MIN="1800000"; TEMP_LIMIT="47" ;;
        xiaomi_mi13_ultra)  DEVICE_TIP="小米13Ultra(骁龙8Gen2)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        xiaomi_mi13_pro)    DEVICE_TIP="小米13Pro(骁龙8Gen2)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        xiaomi_mi13)        DEVICE_TIP="小米13(骁龙8Gen2)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        xiaomi_mi12s_ultra) DEVICE_TIP="小米12SUltra(骁龙8+Gen1)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        xiaomi_mi12s_pro)   DEVICE_TIP="小米12SPro(骁龙8+Gen1)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        xiaomi_mi12s)       DEVICE_TIP="小米12S(骁龙8+Gen1)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        xiaomi_mi12_pro)    DEVICE_TIP="小米12Pro(骁龙8Gen1)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        xiaomi_mi12)        DEVICE_TIP="小米12(骁龙8Gen1)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        xiaomi_mi11_ultra)  DEVICE_TIP="小米11Ultra(骁龙888)"; BIG_MIN="1800000"; TEMP_LIMIT="44" ;;
        xiaomi_mi11)        DEVICE_TIP="小米11(骁龙888)"; BIG_MIN="1800000"; TEMP_LIMIT="44" ;;
        xiaomi_mi11_lite)   DEVICE_TIP="小米11青春版(骁龙780G)"; TEMP_LIMIT="44" ;;
        xiaomi_mi10_ultra)  DEVICE_TIP="小米10Ultra(骁龙865)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        xiaomi_mi10s)       DEVICE_TIP="小米10S(骁龙870)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        xiaomi_mi10)        DEVICE_TIP="小米10(骁龙865)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        xiaomi_mi10_lite)   DEVICE_TIP="小米10青春版(骁龙765G)"; TEMP_LIMIT="44" ;;
        xiaomi_mi9)         DEVICE_TIP="小米9(骁龙855)"; BIG_MIN="1785600"; TEMP_LIMIT="44" ;;
        xiaomi_mi8)         DEVICE_TIP="小米8(骁龙845)"; BIG_MIN="1766400"; TEMP_LIMIT="44" ;;
        xiaomi_mi6)         DEVICE_TIP="小米6(骁龙835)"; BIG_MIN="1766400"; TEMP_LIMIT="44" ;;
        xiaomi_mi5)         DEVICE_TIP="小米5(骁龙820)"; TEMP_LIMIT="44" ;;
        xiaomi_mi4)         DEVICE_TIP="小米4(骁龙801)"; TEMP_LIMIT="43" ;;
        xiaomi_mi3)         DEVICE_TIP="小米3"; TEMP_LIMIT="43" ;;
        xiaomi_mi2)         DEVICE_TIP="小米2"; TEMP_LIMIT="43" ;;

        # ---- MIX 系列 ----
        xiaomi_mix_fold_4)  DEVICE_TIP="小米MIXFold4(骁龙8Gen3)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        xiaomi_mix_fold_3)  DEVICE_TIP="小米MIXFold3(骁龙8Gen2)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        xiaomi_mix_fold_2)  DEVICE_TIP="小米MIXFold2(骁龙8+Gen1)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        xiaomi_mix_fold)    DEVICE_TIP="小米MIXFold(骁龙888)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        xiaomi_mix_flip)    DEVICE_TIP="小米MIXFlip(骁龙8Gen3)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        xiaomi_mix_alpha)   DEVICE_TIP="小米MIXAlpha(骁龙855+)"; TEMP_LIMIT="44" ;;
        xiaomi_mix)         DEVICE_TIP="小米MIX系列"; TEMP_LIMIT="44" ;;

        # ---- Note/CC/Civi ----
        xiaomi_note_10_pro) DEVICE_TIP="小米Note10Pro(骁龙730G)"; TEMP_LIMIT="44" ;;
        xiaomi_note_10)     DEVICE_TIP="小米Note10(骁龙730G)"; TEMP_LIMIT="44" ;;
        xiaomi_note_10_lite) DEVICE_TIP="小米Note10Lite(骁龙730G)"; TEMP_LIMIT="44" ;;
        xiaomi_note_3)      DEVICE_TIP="小米Note3(骁龙660)"; TEMP_LIMIT="44" ;;
        xiaomi_note)        DEVICE_TIP="小米Note系列"; TEMP_LIMIT="43" ;;
        xiaomi_cc9_pro)     DEVICE_TIP="小米CC9Pro(骁龙730G)"; TEMP_LIMIT="44" ;;
        xiaomi_cc9)         DEVICE_TIP="小米CC9(骁龙710)"; TEMP_LIMIT="44" ;;
        xiaomi_cc9e)        DEVICE_TIP="小米CC9e(骁龙665)"; TEMP_LIMIT="44" ;;
        xiaomi_civi_5_pro)  DEVICE_TIP="小米Civi5Pro(骁龙8sGen4)"; BIG_MIN="1500000"; TEMP_LIMIT="46" ;;
        xiaomi_civi_4_pro)  DEVICE_TIP="小米Civi4Pro(骁龙8sGen3)"; BIG_MIN="1500000"; TEMP_LIMIT="46" ;;
        xiaomi_civi_3)      DEVICE_TIP="小米Civi3(天玑8200)"; BIG_MIN="1500000"; TEMP_LIMIT="45" ;;
        xiaomi_civi_2)      DEVICE_TIP="小米Civi2(骁龙7Gen1)"; TEMP_LIMIT="45" ;;
        xiaomi_civi_1s)     DEVICE_TIP="小米Civi1S(骁龙778G+)"; TEMP_LIMIT="45" ;;
        xiaomi_civi)        DEVICE_TIP="小米Civi(骁龙778G)"; TEMP_LIMIT="45" ;;

        # ---- Max/Play ----
        xiaomi_max)         DEVICE_TIP="小米Max系列"; TEMP_LIMIT="43" ;;
        xiaomi_play)        DEVICE_TIP="小米Play(Helio P35)"; TEMP_LIMIT="43" ;;

        # ---- 小米平板 ----
        xiaomi_pad_7_ultra) DEVICE_TIP="小米平板7Ultra(骁龙8Gen3)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        xiaomi_pad_7_pro)   DEVICE_TIP="小米平板7Pro(骁龙8sGen3)"; BIG_MIN="1500000"; TEMP_LIMIT="45" ;;
        xiaomi_pad_6s_pro)  DEVICE_TIP="小米平板6SPro(骁龙8Gen2)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        xiaomi_pad_6_pro)   DEVICE_TIP="小米平板6Pro(骁龙8+Gen1)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        xiaomi_pad_5_pro)   DEVICE_TIP="小米平板5Pro(骁龙870)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        xiaomi_pad_5)       DEVICE_TIP="小米平板5(骁龙860)"; TEMP_LIMIT="44" ;;

        # ---- Redmi K 系列 ----
        redmi_k90)          DEVICE_TIP="Redmi K90系列(骁龙8Elite Gen5)"; BIG_MIN="2200000"; TEMP_LIMIT="48" ;;
        redmi_k80)          DEVICE_TIP="Redmi K80系列(骁龙8Gen3/Gen4)"; BIG_MIN="1800000"; TEMP_LIMIT="47" ;;
        redmi_k70_pro)      DEVICE_TIP="Redmi K70Pro(骁龙8Gen3)"; BIG_MIN="1800000"; TEMP_LIMIT="47" ;;
        redmi_k70)          DEVICE_TIP="Redmi K70(骁龙8Gen2)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        redmi_k60_pro)      DEVICE_TIP="Redmi K60Pro(骁龙8Gen2)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        redmi_k60_ultra)    DEVICE_TIP="Redmi K60Ultra(天玑9200+)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        redmi_k60)          DEVICE_TIP="Redmi K60(骁龙8+)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        redmi_k50)          DEVICE_TIP="Redmi K50系列(骁龙/天玑)"; TEMP_LIMIT="44" ;;
        redmi_k40)          DEVICE_TIP="Redmi K40系列(骁龙870/888)"; BIG_MIN="1800000"; TEMP_LIMIT="44" ;;
        redmi_k30)          DEVICE_TIP="Redmi K30系列(骁龙730G/865)"; TEMP_LIMIT="44" ;;
        redmi_k20)          DEVICE_TIP="Redmi K20系列(骁龙730/855)"; TEMP_LIMIT="44" ;;

        # ---- Redmi Note ----
        redmi_note15)       DEVICE_TIP="Redmi Note15系列"; TEMP_LIMIT="46" ;;
        redmi_note14)       DEVICE_TIP="Redmi Note14系列"; TEMP_LIMIT="46" ;;
        redmi_note13_pro)   DEVICE_TIP="Redmi Note13Pro(骁龙7sGen2)"; TEMP_LIMIT="45" ;;
        redmi_note13)       DEVICE_TIP="Redmi Note13系列"; TEMP_LIMIT="45" ;;
        redmi_note12_turbo) DEVICE_TIP="Redmi Note12Turbo(骁龙7+Gen2)"; TEMP_LIMIT="45" ;;
        redmi_note12)       DEVICE_TIP="Redmi Note12系列(天玑)"; TEMP_LIMIT="44" ;;
        redmi_note11)       DEVICE_TIP="Redmi Note11系列(天玑920)"; TEMP_LIMIT="44" ;;
        redmi_note10)       DEVICE_TIP="Redmi Note10系列"; TEMP_LIMIT="44" ;;
        redmi_note9)        DEVICE_TIP="Redmi Note9系列(骁龙662)"; TEMP_LIMIT="44" ;;
        redmi_note8)        DEVICE_TIP="Redmi Note8系列(骁龙665)"; TEMP_LIMIT="44" ;;
        redmi_note1)        DEVICE_TIP="Redmi Note1(联发科)"; TEMP_LIMIT="43" ;;

        # ---- Redmi Turbo ----
        redmi_turbo_5_max)  DEVICE_TIP="Redmi Turbo5Max(骁龙8sGen4)"; BIG_MIN="1500000"; TEMP_LIMIT="46" ;;
        redmi_turbo_5)      DEVICE_TIP="Redmi Turbo5(骁龙8sGen4)"; BIG_MIN="1500000"; TEMP_LIMIT="46" ;;
        redmi_turbo_4_pro)  DEVICE_TIP="Redmi Turbo4Pro(骁龙8sGen4)"; BIG_MIN="1500000"; TEMP_LIMIT="46" ;;
        redmi_turbo_4)      DEVICE_TIP="Redmi Turbo4(天玑8400)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        redmi_turbo_3)      DEVICE_TIP="Redmi Turbo3(骁龙8sGen3)"; BIG_MIN="1500000"; TEMP_LIMIT="46" ;;

        # ---- Redmi 数字/A ----
        redmi_14c)          DEVICE_TIP="Redmi 14C(联发科G81)"; TEMP_LIMIT="44" ;;
        redmi_13)           DEVICE_TIP="Redmi 13系列"; TEMP_LIMIT="44" ;;
        redmi_12)           DEVICE_TIP="Redmi 12系列"; TEMP_LIMIT="44" ;;
        redmi_10)           DEVICE_TIP="Redmi 10系列"; TEMP_LIMIT="44" ;;
        redmi_9)            DEVICE_TIP="Redmi 9系列"; TEMP_LIMIT="44" ;;
        redmi_a5)           DEVICE_TIP="Redmi A5(紫光展锐)"; TEMP_LIMIT="43" ;;
        redmi_a3)           DEVICE_TIP="Redmi A3(联发科G36)"; TEMP_LIMIT="43" ;;
        redmi_a2)           DEVICE_TIP="Redmi A2(联发科)"; TEMP_LIMIT="43" ;;
        redmi_a1)           DEVICE_TIP="Redmi A1(联发科)"; TEMP_LIMIT="43" ;;

        # ---- Redmi 平板 ----
        redmi_pad_pro)      DEVICE_TIP="Redmi Pad Pro(骁龙7sGen2)"; TEMP_LIMIT="45" ;;
        redmi_pad_se)       DEVICE_TIP="Redmi Pad SE(骁龙680)"; TEMP_LIMIT="44" ;;
        redmi_pad)          DEVICE_TIP="Redmi Pad(联发科G99)"; TEMP_LIMIT="44" ;;

        # ---- POCO F 系列 ----
        poco_f9_ultra)      DEVICE_TIP="POCO F9Ultra(骁龙8Elite)"; BIG_MIN="2000000"; TEMP_LIMIT="47" ;;
        poco_f9_pro)        DEVICE_TIP="POCO F9Pro(骁龙8Elite)"; BIG_MIN="2000000"; TEMP_LIMIT="47" ;;
        poco_f8_ultra)      DEVICE_TIP="POCO F8Ultra(骁龙8Elite)"; BIG_MIN="2000000"; TEMP_LIMIT="47" ;;
        poco_f8_pro)        DEVICE_TIP="POCO F8Pro(骁龙8Gen4)"; BIG_MIN="1800000"; TEMP_LIMIT="47" ;;
        poco_f7_ultra)      DEVICE_TIP="POCO F7Ultra(骁龙8Elite)"; BIG_MIN="2000000"; TEMP_LIMIT="47" ;;
        poco_f7_pro)        DEVICE_TIP="POCO F7Pro(骁龙8Gen3)"; BIG_MIN="1800000"; TEMP_LIMIT="47" ;;
        poco_f7)            DEVICE_TIP="POCO F7(骁龙8sGen4)"; BIG_MIN="1500000"; TEMP_LIMIT="46" ;;
        poco_f6_pro)        DEVICE_TIP="POCO F6Pro(骁龙8Gen2)"; BIG_MIN="1800000"; TEMP_LIMIT="47" ;;
        poco_f6)            DEVICE_TIP="POCO F6(骁龙8sGen3)"; BIG_MIN="1500000"; TEMP_LIMIT="46" ;;
        poco_f5_pro)        DEVICE_TIP="POCO F5Pro(骁龙8+Gen1)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        poco_f5)            DEVICE_TIP="POCO F5(骁龙7+Gen2)"; TEMP_LIMIT="46" ;;
        poco_f4_gt)         DEVICE_TIP="POCO F4GT(骁龙8Gen1)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        poco_f4)            DEVICE_TIP="POCO F4(骁龙870)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        poco_f3)            DEVICE_TIP="POCO F3(骁龙870)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        poco_f2_pro)        DEVICE_TIP="POCO F2Pro(骁龙865)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        poco_f1)            DEVICE_TIP="POCO F1(骁龙845)"; BIG_MIN="1766400"; TEMP_LIMIT="44" ;;

        # ---- POCO X 系列 ----
        poco_x8_pro_max)    DEVICE_TIP="POCO X8ProMax(天玑9000+)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        poco_x8_pro)        DEVICE_TIP="POCO X8Pro(骁龙8sGen4)"; BIG_MIN="1500000"; TEMP_LIMIT="46" ;;
        poco_x8)            DEVICE_TIP="POCO X8(骁龙7sGen4)"; TEMP_LIMIT="45" ;;
        poco_x7_pro)        DEVICE_TIP="POCO X7Pro(天玑8400)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        poco_x7)            DEVICE_TIP="POCO X7(天玑7300)"; TEMP_LIMIT="45" ;;
        poco_x6_pro)        DEVICE_TIP="POCO X6Pro(天玑8300)"; BIG_MIN="1500000"; TEMP_LIMIT="45" ;;
        poco_x6)            DEVICE_TIP="POCO X6(骁龙7sGen2)"; TEMP_LIMIT="45" ;;
        poco_x5_pro)        DEVICE_TIP="POCO X5Pro(骁龙778G)"; TEMP_LIMIT="45" ;;
        poco_x5)            DEVICE_TIP="POCO X5(骁龙695)"; TEMP_LIMIT="45" ;;
        poco_x4_gt)         DEVICE_TIP="POCO X4GT(天玑8100)"; BIG_MIN="1500000"; TEMP_LIMIT="44" ;;
        poco_x4_pro)        DEVICE_TIP="POCO X4Pro(骁龙695)"; TEMP_LIMIT="45" ;;
        poco_x3_pro)        DEVICE_TIP="POCO X3Pro(骁龙860)"; TEMP_LIMIT="44" ;;
        poco_x3_nfc)        DEVICE_TIP="POCO X3NFC(骁龙732G)"; TEMP_LIMIT="44" ;;
        poco_x3)            DEVICE_TIP="POCO X3(骁龙732G)"; TEMP_LIMIT="44" ;;
        poco_x2)            DEVICE_TIP="POCO X2(骁龙730G)"; TEMP_LIMIT="44" ;;

        # ---- POCO M 系列 ----
        poco_m8_pro)        DEVICE_TIP="POCO M8Pro(骁龙6Gen1)"; TEMP_LIMIT="45" ;;
        poco_m8)            DEVICE_TIP="POCO M8(骁龙4Gen2)"; TEMP_LIMIT="44" ;;
        poco_m7_pro)        DEVICE_TIP="POCO M7Pro(天玑7025)"; TEMP_LIMIT="44" ;;
        poco_m7)            DEVICE_TIP="POCO M7(骁龙685)"; TEMP_LIMIT="44" ;;
        poco_m6_pro)        DEVICE_TIP="POCO M6Pro(骁龙4Gen2)"; TEMP_LIMIT="44" ;;
        poco_m6)            DEVICE_TIP="POCO M6(骁龙680)"; TEMP_LIMIT="44" ;;
        poco_m5)            DEVICE_TIP="POCO M5(联发科G99)"; TEMP_LIMIT="44" ;;
        poco_m4_pro)        DEVICE_TIP="POCO M4Pro(天玑810)"; TEMP_LIMIT="44" ;;
        poco_m4)            DEVICE_TIP="POCO M4(骁龙680)"; TEMP_LIMIT="44" ;;
        poco_m3_pro)        DEVICE_TIP="POCO M3Pro(天玑700)"; TEMP_LIMIT="44" ;;
        poco_m3)            DEVICE_TIP="POCO M3(骁龙662)"; TEMP_LIMIT="44" ;;
        poco_m2)            DEVICE_TIP="POCO M2(联发科G80)"; TEMP_LIMIT="44" ;;

        # ---- POCO C 系列 ----
        poco_c95_pro)       DEVICE_TIP="POCO C95Pro(紫光展锐)"; TEMP_LIMIT="43" ;;
        poco_c85)           DEVICE_TIP="POCO C85(紫光展锐)"; TEMP_LIMIT="43" ;;
        poco_c81_pro)       DEVICE_TIP="POCO C81Pro(紫光展锐)"; TEMP_LIMIT="43" ;;
        poco_c75)           DEVICE_TIP="POCO C75(骁龙4Gen2)"; TEMP_LIMIT="43" ;;
        poco_c71)           DEVICE_TIP="POCO C71(紫光展锐)"; TEMP_LIMIT="43" ;;
        poco_c65)           DEVICE_TIP="POCO C65(联发科G85)"; TEMP_LIMIT="43" ;;
        poco_c61)           DEVICE_TIP="POCO C61(联发科G36)"; TEMP_LIMIT="43" ;;
        poco_c55)           DEVICE_TIP="POCO C55(联发科G85)"; TEMP_LIMIT="43" ;;
        poco_c51)           DEVICE_TIP="POCO C51(联发科)"; TEMP_LIMIT="43" ;;
        poco_c50)           DEVICE_TIP="POCO C50(联发科)"; TEMP_LIMIT="43" ;;
        poco_c40)           DEVICE_TIP="POCO C40(紫光展锐)"; TEMP_LIMIT="43" ;;
        poco_c31)           DEVICE_TIP="POCO C31(联发科)"; TEMP_LIMIT="43" ;;
        poco_c3)            DEVICE_TIP="POCO C3(联发科)"; TEMP_LIMIT="43" ;;

        *)                  DEVICE_TIP="通用设备"; TEMP_LIMIT="45" ;;
    esac
}