#!/system/bin/sh
# =====================================================
#         勝豪 SoC 数据库 - 米家专版
#         作者：勝豪  Q群：1022873156
# =====================================================

# ==================== 高通骁龙 8系 ====================
soc_sd8elite() {
    SOC_NAME="高通 骁龙8 Elite"
    BIG_CORES="6 7"; LITTLE_CORES="0 1 2 3 4 5"
    BIG_MIN="2200000"; BIG_MAX="4320000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd8gen3() {
    SOC_NAME="高通 骁龙8 Gen 3"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1804800"; BIG_MAX="3400000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd8gen2() {
    SOC_NAME="高通 骁龙8 Gen 2"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1804800"; BIG_MAX="3200000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd8gen1p() {
    SOC_NAME="高通 骁龙8+ Gen 1"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1804800"; BIG_MAX="3187200"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd8gen1() {
    SOC_NAME="高通 骁龙8 Gen 1"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1804800"; BIG_MAX="2995200"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd888() {
    SOC_NAME="高通 骁龙888"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1804800"; BIG_MAX="2419200"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd870_865() {
    SOC_NAME="高通 骁龙870/865"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1804800"; BIG_MAX="2841600"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd855_855p() {
    SOC_NAME="高通 骁龙855/855+"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1785600"; BIG_MAX="2841600"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd845() {
    SOC_NAME="高通 骁龙845"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1766400"; BIG_MAX="2803200"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd835() {
    SOC_NAME="高通 骁龙835"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1766400"; BIG_MAX="2457600"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}

# ==================== 高通骁龙 7系 ====================
soc_sd7pgen3() {
    SOC_NAME="高通 骁龙7+ Gen 3"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1800000"; BIG_MAX="2800000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd7pgen2() {
    SOC_NAME="高通 骁龙7+ Gen 2"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1200000"; BIG_MAX="2918400"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd7gen3() {
    SOC_NAME="高通 骁龙7 Gen 3"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1200000"; BIG_MAX="2630000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd7sgen2() {
    SOC_NAME="高通 骁龙7s Gen 2"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1200000"; BIG_MAX="2400000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd778g() {
    SOC_NAME="高通 骁龙778G"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1200000"; BIG_MAX="2400000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd768g_765g() {
    SOC_NAME="高通 骁龙768G/765G"
    BIG_CORES="6 7"; LITTLE_CORES="0 1 2 3 4 5"
    BIG_MIN="1200000"; BIG_MAX="2800000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd750g() {
    SOC_NAME="高通 骁龙750G"
    BIG_CORES="6 7"; LITTLE_CORES="0 1 2 3 4 5"
    BIG_MIN="1200000"; BIG_MAX="2200000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd732g_730g() {
    SOC_NAME="高通 骁龙732G/730G"
    BIG_CORES="6 7"; LITTLE_CORES="0 1 2 3 4 5"
    BIG_MIN="1200000"; BIG_MAX="2200000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd720g() {
    SOC_NAME="高通 骁龙720G"
    BIG_CORES="6 7"; LITTLE_CORES="0 1 2 3 4 5"
    BIG_MIN="1200000"; BIG_MAX="2300000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd712_710() {
    SOC_NAME="高通 骁龙712/710"
    BIG_CORES="6 7"; LITTLE_CORES="0 1 2 3 4 5"
    BIG_MIN="1200000"; BIG_MAX="2200000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}

# ==================== 高通骁龙 6系/4系 ====================
soc_sd695() {
    SOC_NAME="高通 骁龙695"
    BIG_CORES="6 7"; LITTLE_CORES="0 1 2 3 4 5"
    BIG_MIN="1200000"; BIG_MAX="2200000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd690() {
    SOC_NAME="高通 骁龙690"
    BIG_CORES="6 7"; LITTLE_CORES="0 1 2 3 4 5"
    BIG_MIN="1200000"; BIG_MAX="2000000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd680_685() {
    SOC_NAME="高通 骁龙680/685"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1200000"; BIG_MAX="2400000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd662() {
    SOC_NAME="高通 骁龙662"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1100000"; BIG_MAX="2000000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd665_660() {
    SOC_NAME="高通 骁龙665/660"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1100000"; BIG_MAX="2200000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd636() {
    SOC_NAME="高通 骁龙636"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1100000"; BIG_MAX="1800000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd460_480() {
    SOC_NAME="高通 骁龙460/480"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1100000"; BIG_MAX="1800000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd450_425() {
    SOC_NAME="高通 骁龙450/425"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="960000"; BIG_MAX="1800000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd439_429() {
    SOC_NAME="高通 骁龙439/429"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="960000"; BIG_MAX="1401000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}

# ==================== 联发科天玑 ====================
soc_d9400() {
    SOC_NAME="联发科 天玑9400"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1800000"; BIG_MAX="3620000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}
soc_d9300() {
    SOC_NAME="联发科 天玑9300"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1800000"; BIG_MAX="3350000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}
soc_d9200() {
    SOC_NAME="联发科 天玑9200"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1800000"; BIG_MAX="3120000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}
soc_d9000() {
    SOC_NAME="联发科 天玑9000"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1800000"; BIG_MAX="3050000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}
soc_d8400() {
    SOC_NAME="联发科 天玑8400"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1800000"; BIG_MAX="3250000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}
soc_d8300() {
    SOC_NAME="联发科 天玑8300"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1500000"; BIG_MAX="3350000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}
soc_d8200() {
    SOC_NAME="联发科 天玑8200"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1500000"; BIG_MAX="3100000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}
soc_d8100() {
    SOC_NAME="联发科 天玑8100"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1500000"; BIG_MAX="2850000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}
soc_d7300() {
    SOC_NAME="联发科 天玑7300"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1200000"; BIG_MAX="2500000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}
soc_d7200() {
    SOC_NAME="联发科 天玑7200"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1200000"; BIG_MAX="2800000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}
soc_d7020() {
    SOC_NAME="联发科 天玑7020"
    BIG_CORES="6 7"; LITTLE_CORES="0 1 2 3 4 5"
    BIG_MIN="1200000"; BIG_MAX="2200000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}
soc_d700() {
    SOC_NAME="联发科 天玑700"
    BIG_CORES="6 7"; LITTLE_CORES="0 1 2 3 4 5"
    BIG_MIN="1200000"; BIG_MAX="2200000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}
soc_d900() {
    SOC_NAME="联发科 天玑900"
    BIG_CORES="6 7"; LITTLE_CORES="0 1 2 3 4 5"
    BIG_MIN="1200000"; BIG_MAX="2400000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}
soc_d1200() {
    SOC_NAME="联发科 天玑1200"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1500000"; BIG_MAX="3000000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}
soc_d1100() {
    SOC_NAME="联发科 天玑1100"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1500000"; BIG_MAX="2600000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}
soc_helio_g99() {
    SOC_NAME="联发科 Helio G99"
    BIG_CORES="6 7"; LITTLE_CORES="0 1 2 3 4 5"
    BIG_MIN="1200000"; BIG_MAX="2200000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}
soc_helio_g90t() {
    SOC_NAME="联发科 Helio G90T"
    BIG_CORES="6 7"; LITTLE_CORES="0 1 2 3 4 5"
    BIG_MIN="1200000"; BIG_MAX="2050000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}
soc_helio_g88() {
    SOC_NAME="联发科 Helio G88"
    BIG_CORES="6 7"; LITTLE_CORES="0 1 2 3 4 5"
    BIG_MIN="1200000"; BIG_MAX="2000000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}
soc_helio_g85() {
    SOC_NAME="联发科 Helio G85"
    BIG_CORES="6 7"; LITTLE_CORES="0 1 2 3 4 5"
    BIG_MIN="1200000"; BIG_MAX="2000000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}
soc_mt6765() {
    SOC_NAME="联发科 Helio P35/MT6765"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1100000"; BIG_MAX="2300000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}

# ==================== 紫光展锐（小米低端机会用） ====================
soc_t612() {
    SOC_NAME="紫光展锐 T612/T616"
    BIG_CORES="6 7"; LITTLE_CORES="0 1 2 3 4 5"
    BIG_MIN="1200000"; BIG_MAX="1800000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}
soc_t606() {
    SOC_NAME="紫光展锐 T606"
    BIG_CORES="6 7"; LITTLE_CORES="0 1 2 3 4 5"
    BIG_MIN="1200000"; BIG_MAX="1600000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}
soc_sc9863a() {
    SOC_NAME="紫光展锐 SC9863A"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1200000"; BIG_MAX="1600000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}

# ==================== 通用兜底 ====================
soc_generic() {
    SOC_NAME="未知芯片（通用方案）"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1200000"; BIG_MAX="2000000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}