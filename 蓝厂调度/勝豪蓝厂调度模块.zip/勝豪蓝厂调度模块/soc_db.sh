#!/system/bin/sh
# =====================================================
#         勝豪 SoC 数据库 - 蓝厂专版
#         作者：勝豪  Q群：1022873156
# =====================================================

# ==================== 高通骁龙 8系 ====================
soc_sd8elite_gen5() {
    SOC_NAME="高通 骁龙8 Elite Gen 5"
    BIG_CORES="6 7"; LITTLE_CORES="0 1 2 3 4 5"
    BIG_MIN="2200000"; BIG_MAX="4400000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd8elite() {
    SOC_NAME="高通 骁龙8 Elite"
    BIG_CORES="6 7"; LITTLE_CORES="0 1 2 3 4 5"
    BIG_MIN="2200000"; BIG_MAX="4320000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd8gen4() {
    SOC_NAME="高通 骁龙8 Gen 4"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="2000000"; BIG_MAX="4000000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd8gen3() {
    SOC_NAME="高通 骁龙8 Gen 3"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1804800"; BIG_MAX="3400000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd8gen2() {
    SOC_NAME="高通 骁龙8 Gen 2"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1804800"; BIG_MAX="3200000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd8gen1p() {
    SOC_NAME="高通 骁龙8+ Gen 1"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1804800"; BIG_MAX="3187200"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd8gen1() {
    SOC_NAME="高通 骁龙8 Gen 1"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1804800"; BIG_MAX="2995200"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd888() {
    SOC_NAME="高通 骁龙888/888+"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1804800"; BIG_MAX="2419200"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd870_865() {
    SOC_NAME="高通 骁龙870/865/865+"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1804800"; BIG_MAX="2841600"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd855_855p() {
    SOC_NAME="高通 骁龙855/855+"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1785600"; BIG_MAX="2841600"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd845() {
    SOC_NAME="高通 骁龙845"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1766400"; BIG_MAX="2803200"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}

# ==================== 高通骁龙 8s / 7系 ====================
soc_sd8sgen4() {
    SOC_NAME="高通 骁龙8s Gen 4"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1500000"; BIG_MAX="3200000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd8sgen3() {
    SOC_NAME="高通 骁龙8s Gen 3"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1500000"; BIG_MAX="3000000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd7pgen2() {
    SOC_NAME="高通 骁龙7+ Gen 2"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1200000"; BIG_MAX="2918400"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd7gen4() {
    SOC_NAME="高通 骁龙7 Gen 4"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1200000"; BIG_MAX="2600000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd7gen3() {
    SOC_NAME="高通 骁龙7 Gen 3"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1200000"; BIG_MAX="2630000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd7sgen3() {
    SOC_NAME="高通 骁龙7s Gen 3"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1200000"; BIG_MAX="2400000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd782g() {
    SOC_NAME="高通 骁龙782G"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1200000"; BIG_MAX="2400000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd778g() {
    SOC_NAME="高通 骁龙778G/778G+"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1200000"; BIG_MAX="2400000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd768g_765g() {
    SOC_NAME="高通 骁龙768G/765G"
    BIG_CORES="6 7"; LITTLE_CORES="0 1 2 3 4 5"
    BIG_MIN="1200000"; BIG_MAX="2800000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd720g() {
    SOC_NAME="高通 骁龙720G"
    BIG_CORES="6 7"; LITTLE_CORES="0 1 2 3 4 5"
    BIG_MIN="1200000"; BIG_MAX="2300000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}

# ==================== 高通骁龙 6系 ====================
soc_sd6gen4() {
    SOC_NAME="高通 骁龙6 Gen 4"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1200000"; BIG_MAX="2300000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd6gen1() {
    SOC_NAME="高通 骁龙6 Gen 1"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1200000"; BIG_MAX="2200000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd695() {
    SOC_NAME="高通 骁龙695"
    BIG_CORES="6 7"; LITTLE_CORES="0 1 2 3 4 5"
    BIG_MIN="1200000"; BIG_MAX="2200000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd680() {
    SOC_NAME="高通 骁龙680"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1200000"; BIG_MAX="2400000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd662() {
    SOC_NAME="高通 骁龙662"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1100000"; BIG_MAX="2000000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd480() {
    SOC_NAME="高通 骁龙480/480+"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1100000"; BIG_MAX="2000000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd460() {
    SOC_NAME="高通 骁龙460"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1100000"; BIG_MAX="1800000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd439() {
    SOC_NAME="高通 骁龙439"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="960000"; BIG_MAX="1401000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}

# ==================== 联发科天玑 9系 ====================
soc_d9500() {
    SOC_NAME="联发科 天玑9500"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1800000"; BIG_MAX="3800000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}
soc_d9400() {
    SOC_NAME="联发科 天玑9400/9400+"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1800000"; BIG_MAX="3620000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}
soc_d9300() {
    SOC_NAME="联发科 天玑9300/9300+"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1800000"; BIG_MAX="3350000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}
soc_d9200() {
    SOC_NAME="联发科 天玑9200/9200+"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1800000"; BIG_MAX="3120000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}
soc_d9000() {
    SOC_NAME="联发科 天玑9000/9000+"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1800000"; BIG_MAX="3050000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}

# ==================== 联发科天玑 8系 ====================
soc_d8400() {
    SOC_NAME="联发科 天玑8400"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1800000"; BIG_MAX="3250000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}
soc_d8350() {
    SOC_NAME="联发科 天玑8350"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1500000"; BIG_MAX="3200000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}
soc_d8300() {
    SOC_NAME="联发科 天玑8300"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1500000"; BIG_MAX="3350000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}
soc_d8200() {
    SOC_NAME="联发科 天玑8200"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1500000"; BIG_MAX="3100000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}
soc_d8100() {
    SOC_NAME="联发科 天玑8100"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1500000"; BIG_MAX="2850000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}

# ==================== 联发科天玑 7系/6系 ====================
soc_d7300() {
    SOC_NAME="联发科 天玑7300"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1200000"; BIG_MAX="2500000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}
soc_d7200() {
    SOC_NAME="联发科 天玑7200"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1200000"; BIG_MAX="2800000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}
soc_d7020() {
    SOC_NAME="联发科 天玑7020"
    BIG_CORES="6 7"; LITTLE_CORES="0 1 2 3 4 5"
    BIG_MIN="1200000"; BIG_MAX="2200000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}
soc_d700() {
    SOC_NAME="联发科 天玑700"
    BIG_CORES="6 7"; LITTLE_CORES="0 1 2 3 4 5"
    BIG_MIN="1200000"; BIG_MAX="2200000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}
soc_d930() {
    SOC_NAME="联发科 天玑930"
    BIG_CORES="6 7"; LITTLE_CORES="0 1 2 3 4 5"
    BIG_MIN="1200000"; BIG_MAX="2200000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}
soc_d900() {
    SOC_NAME="联发科 天玑900"
    BIG_CORES="6 7"; LITTLE_CORES="0 1 2 3 4 5"
    BIG_MIN="1200000"; BIG_MAX="2400000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}
soc_d1300() {
    SOC_NAME="联发科 天玑1300"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1500000"; BIG_MAX="3000000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}
soc_d1200() {
    SOC_NAME="联发科 天玑1200"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1500000"; BIG_MAX="3000000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}
soc_d1100() {
    SOC_NAME="联发科 天玑1100"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1500000"; BIG_MAX="2600000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}
soc_d1000p() {
    SOC_NAME="联发科 天玑1000+"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1500000"; BIG_MAX="2600000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}
soc_d820() {
    SOC_NAME="联发科 天玑820"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1500000"; BIG_MAX="2600000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}
soc_d810() {
    SOC_NAME="联发科 天玑810"
    BIG_CORES="6 7"; LITTLE_CORES="0 1 2 3 4 5"
    BIG_MIN="1200000"; BIG_MAX="2400000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}
soc_d800u() {
    SOC_NAME="联发科 天玑800U"
    BIG_CORES="6 7"; LITTLE_CORES="0 1 2 3 4 5"
    BIG_MIN="1200000"; BIG_MAX="2400000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}
soc_d720() {
    SOC_NAME="联发科 天玑720"
    BIG_CORES="6 7"; LITTLE_CORES="0 1 2 3 4 5"
    BIG_MIN="1200000"; BIG_MAX="2000000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}
soc_d6300() {
    SOC_NAME="联发科 天玑6300"
    BIG_CORES="6 7"; LITTLE_CORES="0 1 2 3 4 5"
    BIG_MIN="1200000"; BIG_MAX="2400000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}
soc_d6020() {
    SOC_NAME="联发科 天玑6020"
    BIG_CORES="6 7"; LITTLE_CORES="0 1 2 3 4 5"
    BIG_MIN="1200000"; BIG_MAX="2200000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}

# ==================== 联发科 Helio ====================
soc_helio_g99() {
    SOC_NAME="联发科 Helio G99"
    BIG_CORES="6 7"; LITTLE_CORES="0 1 2 3 4 5"
    BIG_MIN="1200000"; BIG_MAX="2200000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}
soc_helio_g85() {
    SOC_NAME="联发科 Helio G85"
    BIG_CORES="6 7"; LITTLE_CORES="0 1 2 3 4 5"
    BIG_MIN="1200000"; BIG_MAX="2000000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}
soc_helio_g80() {
    SOC_NAME="联发科 Helio G80"
    BIG_CORES="6 7"; LITTLE_CORES="0 1 2 3 4 5"
    BIG_MIN="1200000"; BIG_MAX="2000000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}
soc_helio_g70() {
    SOC_NAME="联发科 Helio G70"
    BIG_CORES="6 7"; LITTLE_CORES="0 1 2 3 4 5"
    BIG_MIN="1200000"; BIG_MAX="2000000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}
soc_helio_p35() {
    SOC_NAME="联发科 Helio P35"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1100000"; BIG_MAX="2300000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}
soc_helio_p22() {
    SOC_NAME="联发科 Helio P22"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1100000"; BIG_MAX="2000000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}

# ==================== 三星 Exynos ====================
soc_exynos1080() {
    SOC_NAME="三星 Exynos 1080"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1500000"; BIG_MAX="2800000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}
soc_exynos980() {
    SOC_NAME="三星 Exynos 980"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1500000"; BIG_MAX="2200000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}

# ==================== 通用兜底 ====================
soc_generic() {
    SOC_NAME="未知芯片（通用方案）"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1200000"; BIG_MAX="2000000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}