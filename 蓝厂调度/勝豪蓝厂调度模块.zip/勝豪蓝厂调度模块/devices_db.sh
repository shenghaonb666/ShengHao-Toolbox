#!/system/bin/sh
# =====================================================
#         勝豪 蓝厂全系列设备数据库 v1.0
#         作者：勝豪  Q群：1022873156
# =====================================================

detect_device_profile() {
    case "$1" in

        # ==================== iQOO 数字旗舰 ====================
        *iQOO 16*)                                          echo "iqoo_16" ;;
        *iQOO 15 Ultra*|*V2514A*)                           echo "iqoo_15_ultra" ;;
        *iQOO 15T*)                                         echo "iqoo_15t" ;;
        *iQOO 15 王者荣耀*|*V2502A_KPL*)                    echo "iqoo_15_kpl" ;;
        *iQOO 15*|*V2502A*)                                 echo "iqoo_15" ;;
        *iQOO 13*|*V2408A*)                                 echo "iqoo_13" ;;
        *iQOO 12 Pro*|*V2329A*)                             echo "iqoo_12_pro" ;;
        *iQOO 12*|*V2307A*)                                 echo "iqoo_12" ;;
        *iQOO 11S*|*V2304A*)                                echo "iqoo_11s" ;;
        *iQOO 11 Pro*|*V2254A*)                             echo "iqoo_11_pro" ;;
        *iQOO 11*|*V2243A*)                                 echo "iqoo_11" ;;
        *iQOO 10 Pro*|*V2218A*)                             echo "iqoo_10_pro" ;;
        *iQOO 10*|*V2218A*)                                 echo "iqoo_10" ;;
        *iQOO 9 Pro*|*V2172A*)                              echo "iqoo_9_pro" ;;
        *iQOO 9*|*V2171A*)                                  echo "iqoo_9" ;;
        *iQOO 8 Pro*|*V2141A*)                              echo "iqoo_8_pro" ;;
        *iQOO 8*|*V2136A*)                                  echo "iqoo_8" ;;
        *iQOO 7*|*V2049A*)                                  echo "iqoo_7" ;;
        *iQOO 5 Pro*|*V2024A*)                              echo "iqoo_5_pro" ;;
        *iQOO 5*|*V2024A*)                                  echo "iqoo_5" ;;
        *iQOO 3 变形金刚*|*V1955A_TF*)                      echo "iqoo_3_transformers" ;;
        *iQOO 3*|*V1955A*)                                  echo "iqoo_3" ;;
        *iQOO Pro 5G*|*V1916A*)                             echo "iqoo_pro_5g" ;;
        *iQOO Pro*|*V1916A*)                                echo "iqoo_pro" ;;
        *iQOO 初代*|*V1824A*|*iQOO1*)                       echo "iqoo_1" ;;

        # ==================== iQOO Neo ====================
        *iQOO Neo11 至尊版*|*V2506A*)                       echo "iqoo_neo_11_ultimate" ;;
        *iQOO Neo11*|*V2505A*)                              echo "iqoo_neo_11" ;;
        *iQOO Neo10 Pro+*|*V2427A*)                         echo "iqoo_neo_10_pro_plus" ;;
        *iQOO Neo10 Pro*|*V2426A*)                          echo "iqoo_neo_10_pro" ;;
        *iQOO Neo10R*|*V2441A*)                             echo "iqoo_neo_10r" ;;
        *iQOO Neo10*|*V2422A*)                              echo "iqoo_neo_10" ;;
        *iQOO Neo9S Pro+*|*V2341A*)                         echo "iqoo_neo_9s_pro_plus" ;;
        *iQOO Neo9S Pro*|*V2339A*)                          echo "iqoo_neo_9s_pro" ;;
        *iQOO Neo9 Pro*|*V2339A*)                           echo "iqoo_neo_9_pro" ;;
        *iQOO Neo9*|*V2338A*)                               echo "iqoo_neo_9" ;;
        *iQOO Neo8 Pro*|*V2302A*)                           echo "iqoo_neo_8_pro" ;;
        *iQOO Neo8*|*V2301A*)                               echo "iqoo_neo_8" ;;
        *iQOO Neo7 竞速版*|*V2232A*)                        echo "iqoo_neo_7_racing" ;;
        *iQOO Neo7 SE*|*V2238A*)                            echo "iqoo_neo_7_se" ;;
        *iQOO Neo7*|*V2231A*)                               echo "iqoo_neo_7" ;;
        *iQOO Neo6 SE*|*V2199A*)                            echo "iqoo_neo_6_se" ;;
        *iQOO Neo6*|*V2196A*)                               echo "iqoo_neo_6" ;;
        *iQOO Neo5 活力版*|*V2118A*)                        echo "iqoo_neo_5_active" ;;
        *iQOO Neo5 SE*|*V2157A*)                            echo "iqoo_neo_5_se" ;;
        *iQOO Neo5S*|*V2154A*)                              echo "iqoo_neo_5s" ;;
        *iQOO Neo5*|*V2055A*)                               echo "iqoo_neo_5" ;;
        *iQOO Neo3*|*V1981A*)                               echo "iqoo_neo_3" ;;
        *iQOO Neo 855 竞速版*|*V1936AL*)                    echo "iqoo_neo_855_racing" ;;
        *iQOO Neo 855*|*V1936A*)                            echo "iqoo_neo_855" ;;
        *iQOO Neo 初代*|*iQOONeo*|*V1914A*)                 echo "iqoo_neo_1" ;;

        # ==================== iQOO Z ====================
        *iQOO Z11 Turbo*|*V2517A*)                          echo "iqoo_z11_turbo" ;;
        *iQOO Z11x*|*V2516A*)                               echo "iqoo_z11x" ;;
        *iQOO Z11i*|*V2515A*)                               echo "iqoo_z11i" ;;
        *iQOO Z11S*|*V2514A_Z11S*)                          echo "iqoo_z11s" ;;
        *iQOO Z11*|*V2513A*)                                echo "iqoo_z11" ;;
        *iQOO Z10 Turbo Pro*|*V2453A*)                      echo "iqoo_z10_turbo_pro" ;;
        *iQOO Z10 Turbo+*|*V2453A_PLUS*)                    echo "iqoo_z10_turbo_plus" ;;
        *iQOO Z10 Turbo*|*V2452A*)                          echo "iqoo_z10_turbo" ;;
        *iQOO Z10x*|*V2444A_X*)                             echo "iqoo_z10x" ;;
        *iQOO Z10*|*V2444A*)                                echo "iqoo_z10" ;;
        *iQOO Z9 Turbo+*|*V2417A*)                          echo "iqoo_z9_turbo_plus" ;;
        *iQOO Z9 Turbo 长续航*|*V2352A_LR*)                 echo "iqoo_z9_turbo_lr" ;;
        *iQOO Z9 Turbo*|*V2352A*)                           echo "iqoo_z9_turbo" ;;
        *iQOO Z9x*|*V2353A*)                                echo "iqoo_z9x" ;;
        *iQOO Z9*|*V2361A*)                                 echo "iqoo_z9" ;;
        *iQOO Z8x*|*V2312A*)                                echo "iqoo_z8x" ;;
        *iQOO Z8*|*V2280A*)                                 echo "iqoo_z8" ;;
        *iQOO Z7i*|*V2278A*)                                echo "iqoo_z7i" ;;
        *iQOO Z7x(m)*|*V2271A*)                             echo "iqoo_z7xm" ;;
        *iQOO Z7x*|*V2272A*)                                echo "iqoo_z7x" ;;
        *iQOO Z7*|*V2270A*)                                 echo "iqoo_z7" ;;
        *iQOO Z6x*|*V2164A*)                                echo "iqoo_z6x" ;;
        *iQOO Z6*|*V2227A*)                                 echo "iqoo_z6" ;;
        *iQOO Z5x*|*V2137A*)                                echo "iqoo_z5x" ;;
        *iQOO Z5*|*V2148A*)                                 echo "iqoo_z5" ;;
        *iQOO Z3*|*V2072A*)                                 echo "iqoo_z3" ;;
        *iQOO Z1x*|*V2012A*)                                echo "iqoo_z1x" ;;
        *iQOO Z1*|*V1986A*)                                 echo "iqoo_z1" ;;

        # ==================== iQOO U ====================
        *iQOO U5x*|*V2166A*)                                echo "iqoo_u5x" ;;
        *iQOO U5e*|*V2197A*)                                echo "iqoo_u5e" ;;
        *iQOO U5*|*V2165A*)                                 echo "iqoo_u5" ;;
        *iQOO U3x 标准版*|*V2144A_S*)                       echo "iqoo_u3x_std" ;;
        *iQOO U3x*|*V2144A*)                                echo "iqoo_u3x" ;;
        *iQOO U3*|*V2061A*)                                 echo "iqoo_u3" ;;
        *iQOO U1x*|*V2059A*)                                echo "iqoo_u1x" ;;
        *iQOO U1*|*V2023A*)                                 echo "iqoo_u1" ;;

        # ==================== iQOO Pad ====================
        *iQOO Pad2 Pro*|*PA2453*)                           echo "iqoo_pad_2_pro" ;;
        *iQOO Pad2*|*PA2438*)                               echo "iqoo_pad_2" ;;
        *iQOO Pad*|*PA2272*)                                echo "iqoo_pad" ;;

        # ==================== iQOO 海外版 ====================
        *iQOO Z9 Lite 5G*|*I2306*)                          echo "iqoo_z9_lite_5g" ;;
        *iQOO Z9s Pro*|*I2301*)                             echo "iqoo_z9s_pro" ;;
        *iQOO Z10R*|*I2407*)                                echo "iqoo_z10r" ;;
        *iQOO Z10 Lite*|*I2404*)                            echo "iqoo_z10_lite" ;;
        *iQOO Neo 10R*|*I2403*)                             echo "iqoo_neo_10r_intl" ;;

        # ==================== vivo X 旗舰 ====================
        *vivo X500 Pro Max*|*V2602A*)                       echo "vivo_x500_pro_max" ;;
        *vivo X500 Pro*|*V2603A*)                           echo "vivo_x500_pro" ;;
        *vivo X500*|*V2601A*)                               echo "vivo_x500" ;;
        *vivo X300 Ultra*|*V2524A*)                         echo "vivo_x300_ultra" ;;
        *vivo X300 Pro*|*V2525A*)                           echo "vivo_x300_pro" ;;
        *vivo X300s*|*V2526A*)                              echo "vivo_x300s" ;;
        *vivo X300 E*|*V2527A*)                             echo "vivo_x300_e" ;;
        *vivo X300*|*V2523A*)                               echo "vivo_x300" ;;
        *vivo X200 Ultra*|*V2424A*)                         echo "vivo_x200_ultra" ;;
        *vivo X200 Pro*|*V2413A*)                           echo "vivo_x200_pro" ;;
        *vivo X200s*|*V2416A*)                              echo "vivo_x200s" ;;
        *vivo X200*|*V2409A*)                               echo "vivo_x200" ;;
        *vivo X100 Ultra*|*V2366A*)                         echo "vivo_x100_ultra" ;;
        *vivo X100 Pro*|*V2324A*)                           echo "vivo_x100_pro" ;;
        *vivo X100s Pro*|*V2358A*)                          echo "vivo_x100s_pro" ;;
        *vivo X100s*|*V2361A_X100S*)                        echo "vivo_x100s" ;;
        *vivo X100*|*V2361A*)                               echo "vivo_x100" ;;
        *vivo X90 Pro+*|*V2227A*)                           echo "vivo_x90_pro_plus" ;;
        *vivo X90 Pro*|*V2219A*)                            echo "vivo_x90_pro" ;;
        *vivo X90s*|*V2241A_S*)                             echo "vivo_x90s" ;;
        *vivo X90*|*V2241A*)                                echo "vivo_x90" ;;
        *vivo X80 Pro*|*V2185A*)                            echo "vivo_x80_pro" ;;
        *vivo X80*|*V2183A*)                                echo "vivo_x80" ;;
        *vivo X70 Pro+*|*V2145A*)                           echo "vivo_x70_pro_plus" ;;
        *vivo X70 Pro*|*V2134A*)                            echo "vivo_x70_pro" ;;
        *vivo X70*|*V2133A*)                                echo "vivo_x70" ;;
        *vivo X60 Pro+*|*V2056A*)                           echo "vivo_x60_pro_plus" ;;
        *vivo X60 Pro*|*V2046A*)                            echo "vivo_x60_pro" ;;
        *vivo X60*|*V2046A_X60*)                            echo "vivo_x60" ;;
        *vivo X50 Pro+*|*V2011A*)                           echo "vivo_x50_pro_plus" ;;
        *vivo X50 Pro*|*V2006A*)                            echo "vivo_x50_pro" ;;
        *vivo X50*|*V2001A*)                                echo "vivo_x50" ;;
        *vivo X30 Pro*|*V1938T*)                            echo "vivo_x30_pro" ;;
        *vivo X30*|*V1938A*)                                echo "vivo_x30" ;;
        *vivo X27 Pro*|*V1838A_Pro*)                        echo "vivo_x27_pro" ;;
        *vivo X27*|*V1829A*)                                echo "vivo_x27" ;;
        *vivo X23*|*V1809A*)                                echo "vivo_x23" ;;
        *vivo X21*|*V1735A*)                                echo "vivo_x21" ;;
        *vivo X20 Plus*|*V1735T*)                           echo "vivo_x20_plus" ;;
        *vivo X20*|*V1735*)                                 echo "vivo_x20" ;;
        *vivo X9s Plus*|*V1716*)                            echo "vivo_x9s_plus" ;;
        *vivo X9*|*V1716_X9*)                               echo "vivo_x9" ;;
        *vivo X Fold6*|*V2618A*)                            echo "vivo_x_fold_6" ;;
        *vivo X Fold5*|*V2429A*)                            echo "vivo_x_fold_5" ;;
        *vivo X Fold3 Pro*|*V2337A*)                        echo "vivo_x_fold_3_pro" ;;
        *vivo X Fold3*|*V2303A*)                            echo "vivo_x_fold_3" ;;
        *vivo X Fold2*|*V2266A*)                            echo "vivo_x_fold_2" ;;
        *vivo X Fold+*|*V2229A*)                            echo "vivo_x_fold_plus" ;;
        *vivo X Fold*|*V2178A*)                             echo "vivo_x_fold" ;;
        *vivo X Flip*|*V2283A*)                             echo "vivo_x_flip" ;;

        # ==================== vivo S ====================
        *vivo S60 元气版*|*V2534A*)                         echo "vivo_s60_yuanqi" ;;
        *vivo S60*|*V2533A*)                                echo "vivo_s60" ;;
        *vivo S50 Pro mini*|*V2530A*)                       echo "vivo_s50_pro_mini" ;;
        *vivo S50*|*V2529A*)                                echo "vivo_s50" ;;
        *vivo S30 Pro mini*|*V2507A*)                       echo "vivo_s30_pro_mini" ;;
        *vivo S30*|*V2506A_S30*)                            echo "vivo_s30" ;;
        *vivo S20 Pro*|*V2428A*)                            echo "vivo_s20_pro" ;;
        *vivo S20*|*V2426A_S20*)                            echo "vivo_s20" ;;
        *vivo S19 Pro*|*V2362A*)                            echo "vivo_s19_pro" ;;
        *vivo S19*|*V2364A*)                                echo "vivo_s19" ;;
        *vivo S18 Pro*|*V2324A*)                            echo "vivo_s18_pro" ;;
        *vivo S18e*|*V2323A_E*)                             echo "vivo_s18e" ;;
        *vivo S18*|*V2323A*)                                echo "vivo_s18" ;;
        *vivo S17 Pro*|*V2284A*)                            echo "vivo_s17_pro" ;;
        *vivo S17e*|*V2285A*)                               echo "vivo_s17e" ;;
        *vivo S17*|*V2283A_S17*)                            echo "vivo_s17" ;;
        *vivo S16 Pro*|*V2235A*)                            echo "vivo_s16_pro" ;;
        *vivo S16e*|*V2236A*)                               echo "vivo_s16e" ;;
        *vivo S16*|*V2232A_S16*)                            echo "vivo_s16" ;;
        *vivo S15 Pro*|*V2203A*)                            echo "vivo_s15_pro" ;;
        *vivo S15e*|*V2190A*)                               echo "vivo_s15e" ;;
        *vivo S15*|*V2203A_S15*)                            echo "vivo_s15" ;;
        *vivo S12 Pro*|*V2162A*)                            echo "vivo_s12_pro" ;;
        *vivo S12*|*V2162A_S12*)                            echo "vivo_s12" ;;
        *vivo S10 Pro*|*V2121A*)                            echo "vivo_s10_pro" ;;
        *vivo S10e*|*V2130A*)                               echo "vivo_s10e" ;;
        *vivo S10*|*V2121A_S10*)                            echo "vivo_s10" ;;
        *vivo S9e*|*V2048A*)                                echo "vivo_s9e" ;;
        *vivo S9*|*V2072A_S9*)                              echo "vivo_s9" ;;
        *vivo S7e*|*V2031A*)                                echo "vivo_s7e" ;;
        *vivo S7*|*V2020A*)                                 echo "vivo_s7" ;;

        # ==================== vivo Y ====================
        *vivo Y600i*|*V2548A*)                              echo "vivo_y600i" ;;
        *vivo Y600 Turbo*|*V2549A*)                         echo "vivo_y600_turbo" ;;
        *vivo Y600 Pro*|*V2547A*)                           echo "vivo_y600_pro" ;;
        *vivo Y600*|*V2546A*)                               echo "vivo_y600" ;;
        *vivo Y60*|*V2442A*)                                echo "vivo_y60" ;;
        *vivo Y6*|*V2442A_Y6*)                              echo "vivo_y6" ;;
        *vivo Y500i*|*V2543A*)                              echo "vivo_y500i" ;;
        *vivo Y500 Pro*|*V2542A*)                           echo "vivo_y500_pro" ;;
        *vivo Y500*|*V2541A*)                               echo "vivo_y500" ;;
        *vivo Y50 5G*|*V2440A*)                             echo "vivo_y50_5g" ;;
        *vivo Y50m 5G*|*V2440B*)                            echo "vivo_y50m_5g" ;;
        *vivo Y50*|*V2440*)                                 echo "vivo_y50" ;;
        *vivo Y300 GT*|*V2455A*)                            echo "vivo_y300_gt" ;;
        *vivo Y300t*|*V2454A*)                              echo "vivo_y300t" ;;
        *vivo Y300 Pro+*|*V2420A*)                          echo "vivo_y300_pro_plus" ;;
        *vivo Y300i*|*V2438A*)                              echo "vivo_y300i" ;;
        *vivo Y300*|*V2435A*)                               echo "vivo_y300" ;;
        *vivo Y200 Pro*|*V2318A*)                           echo "vivo_y200_pro" ;;
        *vivo Y200 GT*|*V2345A*)                            echo "vivo_y200_gt" ;;
        *vivo Y200i*|*V2355A*)                              echo "vivo_y200i" ;;
        *vivo Y200*|*V2321A*)                               echo "vivo_y200" ;;
        *vivo Y100i*|*V2329A_Y100I*)                        echo "vivo_y100i" ;;
        *vivo Y100*|*V2320A*)                               echo "vivo_y100" ;;
        *vivo Y78t*|*V2288A*)                               echo "vivo_y78t" ;;
        *vivo Y78+*|*V2278A_Y78P*)                          echo "vivo_y78_plus" ;;
        *vivo Y78*|*V2280A_Y78*)                            echo "vivo_y78" ;;
        *vivo Y77t*|*V2256A*)                               echo "vivo_y77t" ;;
        *vivo Y77*|*V2219A_Y77*)                            echo "vivo_y77" ;;
        *vivo Y76s*|*V2138A*)                               echo "vivo_y76s" ;;
        *vivo Y75s*|*V2123A*)                               echo "vivo_y75s" ;;
        *vivo Y73t*|*V2180A*)                               echo "vivo_y73t" ;;
        *vivo Y55s*|*V2165A_Y55S*)                          echo "vivo_y55s" ;;
        *vivo Y53s*|*V2123A_Y53S*)                          echo "vivo_y53s" ;;
        *vivo Y37 Pro*|*V2430A*)                            echo "vivo_y37_pro" ;;
        *vivo Y36*|*V2247A*)                                echo "vivo_y36" ;;
        *vivo Y35*|*V2230A*)                                echo "vivo_y35" ;;
        *vivo Y33s*|*V2109A*)                               echo "vivo_y33s" ;;
        *vivo Y32*|*V2155A*)                                echo "vivo_y32" ;;
        *vivo Y31s*|*V2068A*)                               echo "vivo_y31s" ;;
        *vivo Y30*|*V2034A*)                                echo "vivo_y30" ;;
        *vivo Y22*|*V2207A*)                                echo "vivo_y22" ;;
        *vivo Y21*|*V2111A*)                                echo "vivo_y21" ;;
        *vivo Y20*|*V2029A*)                                echo "vivo_y20" ;;
        *vivo Y19*|*V1935A*)                                echo "vivo_y19" ;;
        *vivo Y17*|*V1901A*)                                echo "vivo_y17" ;;
        *vivo Y15*|*V1834A*)                                echo "vivo_y15" ;;

        # ==================== vivo NEX ====================
        *NEX 3S*|*V1950A_N3S*)                              echo "vivo_nex_3s" ;;
        *NEX 3*|*V1923A*)                                   echo "vivo_nex_3" ;;
        *NEX 双屏版*|*V1820A*)                              echo "vivo_nex_dual" ;;
        *NEX 旗舰版*|*V1801A*)                              echo "vivo_nex_flagship" ;;
        *NEX 屏幕指纹*|*V1801A_FP*)                         echo "vivo_nex_fp" ;;
        *vivo NEX*|*V1801*)                                 echo "vivo_nex" ;;

        # ==================== vivo Xplay ====================
        *Xplay 6*|*PD1612*)                                 echo "vivo_xplay_6" ;;
        *Xplay 5 Elite*|*PD1522A*)                          echo "vivo_xplay_5_elite" ;;
        *Xplay 5*|*PD1522*)                                 echo "vivo_xplay_5" ;;
        *Xplay 3S*|*PD1301*)                                echo "vivo_xplay_3s" ;;

        # ==================== vivo Z ====================
        *vivo Z6*|*V1963A*)                                 echo "vivo_z6" ;;
        *vivo Z5x*|*V1911A*)                                echo "vivo_z5x" ;;
        *vivo Z5*|*V1921A*)                                 echo "vivo_z5" ;;
        *vivo Z3x*|*V1730GA*)                               echo "vivo_z3x" ;;
        *vivo Z3*|*V1813A*)                                 echo "vivo_z3" ;;
        *vivo Z1 Pro*|*V1913A*)                             echo "vivo_z1_pro" ;;
        *vivo Z1*|*V1801A_Z1*)                              echo "vivo_z1" ;;

        # ==================== vivo U ====================
        *vivo U3x 标准版*|*V1928T*)                         echo "vivo_u3x_std" ;;
        *vivo U3x*|*V1928A*)                                echo "vivo_u3x" ;;
        *vivo U3*|*V1928*)                                  echo "vivo_u3" ;;
        *vivo U1*|*V1818A*)                                 echo "vivo_u1" ;;

        # ==================== vivo T ====================
        *vivo T3 Ultra*|*V2411*)                            echo "vivo_t3_ultra" ;;
        *vivo T3 Pro*|*V2404*)                              echo "vivo_t3_pro" ;;
        *vivo T3*|*V2334*)                                  echo "vivo_t3" ;;
        *vivo T2x*|*V2212*)                                 echo "vivo_t2x" ;;
        *vivo T2 Pro*|*V2302A_T2P*)                         echo "vivo_t2_pro" ;;
        *vivo T2*|*V2207*)                                  echo "vivo_t2" ;;
        *vivo T1x*|*V2147*)                                 echo "vivo_t1x" ;;
        *vivo T1*|*V2140*)                                  echo "vivo_t1" ;;

        # ==================== vivo Pad ====================
        *vivo Pad3 Pro*|*PA2473*)                           echo "vivo_pad_3_pro" ;;
        *vivo Pad3*|*PA2455*)                               echo "vivo_pad_3" ;;
        *vivo Pad2*|*PA2373*)                               echo "vivo_pad_2" ;;
        *vivo Pad*|*PA2170*)                                echo "vivo_pad" ;;

        # ==================== 默认兜底 ====================
        *)                                                  echo "generic" ;;
    esac
}

# ==================== 设备专属参数 ====================
apply_device_profile() {
    TEMP_LIMIT="45"
    ENABLE_BYPASS_CHARGE=0

    case "$1" in

        # ==================== iQOO 数字旗舰 ====================
        iqoo_16)              DEVICE_TIP="iQOO 16(骁龙8Elite Gen5)"; BIG_MIN="2200000"; BIG_MAX="4400000"; TEMP_LIMIT="48" ;;
        iqoo_15_ultra)        DEVICE_TIP="iQOO 15Ultra(骁龙8Elite Gen5)"; BIG_MIN="2200000"; BIG_MAX="4400000"; TEMP_LIMIT="48" ;;
        iqoo_15t)             DEVICE_TIP="iQOO 15T(骁龙8Elite Gen5)"; BIG_MIN="2200000"; TEMP_LIMIT="47" ;;
        iqoo_15_kpl)          DEVICE_TIP="iQOO 15王者典藏(骁龙8Elite Gen5)"; BIG_MIN="2200000"; TEMP_LIMIT="48" ;;
        iqoo_15)              DEVICE_TIP="iQOO 15(骁龙8Elite Gen5)"; BIG_MIN="2200000"; TEMP_LIMIT="48" ;;
        iqoo_13)              DEVICE_TIP="iQOO 13(骁龙8Elite)"; BIG_MIN="2000000"; BIG_MAX="4200000"; TEMP_LIMIT="48" ;;
        iqoo_12_pro)          DEVICE_TIP="iQOO 12Pro(骁龙8Gen3)"; BIG_MIN="1800000"; TEMP_LIMIT="47" ;;
        iqoo_12)              DEVICE_TIP="iQOO 12(骁龙8Gen3)"; BIG_MIN="1800000"; TEMP_LIMIT="47" ;;
        iqoo_11s)             DEVICE_TIP="iQOO 11S(骁龙8Gen2)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        iqoo_11_pro)          DEVICE_TIP="iQOO 11Pro(骁龙8Gen2)"; BIG_MIN="1800000"; TEMP_LIMIT="47" ;;
        iqoo_11)              DEVICE_TIP="iQOO 11(骁龙8Gen2)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        iqoo_10_pro)          DEVICE_TIP="iQOO 10Pro(骁龙8+Gen1)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        iqoo_10)              DEVICE_TIP="iQOO 10(骁龙8+Gen1)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        iqoo_9_pro)           DEVICE_TIP="iQOO 9Pro(骁龙8Gen1)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        iqoo_9)               DEVICE_TIP="iQOO 9(骁龙8Gen1)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        iqoo_8_pro)           DEVICE_TIP="iQOO 8Pro(骁龙888+)"; BIG_MIN="1800000"; TEMP_LIMIT="44" ;;
        iqoo_8)               DEVICE_TIP="iQOO 8(骁龙888)"; BIG_MIN="1800000"; TEMP_LIMIT="44" ;;
        iqoo_7)               DEVICE_TIP="iQOO 7(骁龙888)"; BIG_MIN="1800000"; TEMP_LIMIT="44" ;;
        iqoo_5_pro)           DEVICE_TIP="iQOO 5Pro(骁龙865)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        iqoo_5)               DEVICE_TIP="iQOO 5(骁龙865)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        iqoo_3_transformers)  DEVICE_TIP="iQOO 3变形金刚限量(骁龙865)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        iqoo_3)               DEVICE_TIP="iQOO 3(骁龙865)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        iqoo_pro_5g)          DEVICE_TIP="iQOO Pro 5G(骁龙855+)"; BIG_MIN="1785600"; TEMP_LIMIT="44" ;;
        iqoo_pro)             DEVICE_TIP="iQOO Pro(骁龙855+)"; BIG_MIN="1785600"; TEMP_LIMIT="44" ;;
        iqoo_1)               DEVICE_TIP="iQOO初代(骁龙855)"; BIG_MIN="1785600"; TEMP_LIMIT="44" ;;

        # ==================== iQOO Neo ====================
        iqoo_neo_11_ultimate) DEVICE_TIP="iQOO Neo11至尊版(骁龙8Elite)"; BIG_MIN="2000000"; TEMP_LIMIT="48" ;;
        iqoo_neo_11)          DEVICE_TIP="iQOO Neo11(骁龙8Gen4)"; BIG_MIN="1800000"; TEMP_LIMIT="47" ;;
        iqoo_neo_10_pro_plus) DEVICE_TIP="iQOO Neo10Pro+(天玑9400)"; BIG_MIN="1800000"; BIG_MAX="3620000"; TEMP_LIMIT="47" ;;
        iqoo_neo_10_pro)      DEVICE_TIP="iQOO Neo10Pro(天玑9400)"; BIG_MIN="1800000"; BIG_MAX="3620000"; TEMP_LIMIT="47" ;;
        iqoo_neo_10r)         DEVICE_TIP="iQOO Neo10R(骁龙8sGen4)"; BIG_MIN="1500000"; TEMP_LIMIT="46" ;;
        iqoo_neo_10)          DEVICE_TIP="iQOO Neo10(骁龙8Gen3)"; BIG_MIN="1800000"; TEMP_LIMIT="47" ;;
        iqoo_neo_9s_pro_plus) DEVICE_TIP="iQOO Neo9SPro+(天玑9300+)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        iqoo_neo_9s_pro)      DEVICE_TIP="iQOO Neo9SPro(天玑9300+)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        iqoo_neo_9_pro)       DEVICE_TIP="iQOO Neo9Pro(天玑9300)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        iqoo_neo_9)           DEVICE_TIP="iQOO Neo9(骁龙8Gen2)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        iqoo_neo_8_pro)       DEVICE_TIP="iQOO Neo8Pro(天玑9200+)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        iqoo_neo_8)           DEVICE_TIP="iQOO Neo8(骁龙8+Gen1)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        iqoo_neo_7_racing)    DEVICE_TIP="iQOO Neo7竞速版(骁龙8+Gen1)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        iqoo_neo_7_se)        DEVICE_TIP="iQOO Neo7SE(天玑8200)"; BIG_MIN="1500000"; TEMP_LIMIT="45" ;;
        iqoo_neo_7)           DEVICE_TIP="iQOO Neo7(天玑9000+)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        iqoo_neo_6_se)        DEVICE_TIP="iQOO Neo6SE(骁龙870)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        iqoo_neo_6)           DEVICE_TIP="iQOO Neo6(骁龙8Gen1)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        iqoo_neo_5_active)    DEVICE_TIP="iQOO Neo5活力版(骁龙870)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        iqoo_neo_5_se)        DEVICE_TIP="iQOO Neo5SE(骁龙870)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        iqoo_neo_5s)          DEVICE_TIP="iQOO Neo5S(骁龙888)"; BIG_MIN="1800000"; TEMP_LIMIT="44" ;;
        iqoo_neo_5)           DEVICE_TIP="iQOO Neo5(骁龙870)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        iqoo_neo_3)           DEVICE_TIP="iQOO Neo3(骁龙865)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        iqoo_neo_855_racing)  DEVICE_TIP="iQOO Neo855竞速版(骁龙855+)"; BIG_MIN="1785600"; TEMP_LIMIT="44" ;;
        iqoo_neo_855)         DEVICE_TIP="iQOO Neo855(骁龙855)"; BIG_MIN="1785600"; TEMP_LIMIT="44" ;;
        iqoo_neo_1)           DEVICE_TIP="iQOO Neo初代(骁龙845)"; BIG_MIN="1766400"; TEMP_LIMIT="44" ;;

        # ==================== iQOO Z ====================
        iqoo_z11_turbo)       DEVICE_TIP="iQOO Z11Turbo(骁龙8sGen4)"; BIG_MIN="1500000"; TEMP_LIMIT="46" ;;
        iqoo_z11s)            DEVICE_TIP="iQOO Z11S(天玑8400)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        iqoo_z11i)            DEVICE_TIP="iQOO Z11i(天玑7300)"; TEMP_LIMIT="45" ;;
        iqoo_z11x)            DEVICE_TIP="iQOO Z11x(骁龙6Gen4)"; TEMP_LIMIT="44" ;;
        iqoo_z11)             DEVICE_TIP="iQOO Z11(骁龙7Gen4)"; TEMP_LIMIT="45" ;;
        iqoo_z10_turbo_plus)  DEVICE_TIP="iQOO Z10Turbo+(天玑9400+)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        iqoo_z10_turbo_pro)   DEVICE_TIP="iQOO Z10TurboPro(骁龙8sGen4)"; BIG_MIN="1500000"; TEMP_LIMIT="46" ;;
        iqoo_z10_turbo)       DEVICE_TIP="iQOO Z10Turbo(天玑8400)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        iqoo_z10x)            DEVICE_TIP="iQOO Z10x(骁龙6Gen1)"; TEMP_LIMIT="44" ;;
        iqoo_z10)             DEVICE_TIP="iQOO Z10(骁龙7sGen3)"; TEMP_LIMIT="45" ;;
        iqoo_z9_turbo_plus)   DEVICE_TIP="iQOO Z9Turbo+(天玑9300+)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        iqoo_z9_turbo_lr)     DEVICE_TIP="iQOO Z9Turbo长续航(骁龙8sGen3)"; BIG_MIN="1500000"; TEMP_LIMIT="45" ;;
        iqoo_z9_turbo)        DEVICE_TIP="iQOO Z9Turbo(骁龙8sGen3)"; BIG_MIN="1500000"; TEMP_LIMIT="45" ;;
        iqoo_z9x)             DEVICE_TIP="iQOO Z9x(骁龙6Gen1)"; TEMP_LIMIT="44" ;;
        iqoo_z9)              DEVICE_TIP="iQOO Z9(骁龙7Gen3)"; TEMP_LIMIT="45" ;;
        iqoo_z8x)             DEVICE_TIP="iQOO Z8x(骁龙6Gen1)"; TEMP_LIMIT="44" ;;
        iqoo_z8)              DEVICE_TIP="iQOO Z8(天玑8200)"; BIG_MIN="1500000"; TEMP_LIMIT="45" ;;
        iqoo_z7i)             DEVICE_TIP="iQOO Z7i(天玑6020)"; TEMP_LIMIT="44" ;;
        iqoo_z7xm)            DEVICE_TIP="iQOO Z7x(m)(骁龙695)"; TEMP_LIMIT="44" ;;
        iqoo_z7x)             DEVICE_TIP="iQOO Z7x(骁龙695)"; TEMP_LIMIT="44" ;;
        iqoo_z7)              DEVICE_TIP="iQOO Z7(骁龙782G)"; TEMP_LIMIT="45" ;;
        iqoo_z6x)             DEVICE_TIP="iQOO Z6x(天玑810)"; TEMP_LIMIT="44" ;;
        iqoo_z6)              DEVICE_TIP="iQOO Z6(骁龙778G+)"; TEMP_LIMIT="45" ;;
        iqoo_z5x)             DEVICE_TIP="iQOO Z5x(天玑900)"; TEMP_LIMIT="44" ;;
        iqoo_z5)              DEVICE_TIP="iQOO Z5(骁龙778G)"; TEMP_LIMIT="45" ;;
        iqoo_z3)              DEVICE_TIP="iQOO Z3(骁龙768G)"; TEMP_LIMIT="44" ;;
        iqoo_z1x)             DEVICE_TIP="iQOO Z1x(骁龙765G)"; TEMP_LIMIT="44" ;;
        iqoo_z1)              DEVICE_TIP="iQOO Z1(天玑1000+)"; TEMP_LIMIT="44" ;;

        # ==================== iQOO U ====================
        iqoo_u5x)             DEVICE_TIP="iQOO U5x(骁龙680)"; TEMP_LIMIT="44" ;;
        iqoo_u5e)             DEVICE_TIP="iQOO U5e(天玑700)"; TEMP_LIMIT="44" ;;
        iqoo_u5)              DEVICE_TIP="iQOO U5(骁龙695)"; TEMP_LIMIT="44" ;;
        iqoo_u3x_std)         DEVICE_TIP="iQOO U3x标准版(骁龙680)"; TEMP_LIMIT="44" ;;
        iqoo_u3x)             DEVICE_TIP="iQOO U3x(骁龙680)"; TEMP_LIMIT="44" ;;
        iqoo_u3)              DEVICE_TIP="iQOO U3(天玑800U)"; TEMP_LIMIT="44" ;;
        iqoo_u1x)             DEVICE_TIP="iQOO U1x(骁龙662)"; TEMP_LIMIT="44" ;;
        iqoo_u1)              DEVICE_TIP="iQOO U1(骁龙720G)"; TEMP_LIMIT="44" ;;

        # ==================== iQOO Pad ====================
        iqoo_pad_2_pro)       DEVICE_TIP="iQOO Pad2Pro(天玑9300+)"; BIG_MIN="1800000"; TEMP_LIMIT="46"; ENABLE_BYPASS_CHARGE=1 ;;
        iqoo_pad_2)           DEVICE_TIP="iQOO Pad2(骁龙8sGen3)"; BIG_MIN="1500000"; TEMP_LIMIT="45" ;;
        iqoo_pad)             DEVICE_TIP="iQOO Pad(天玑9000+)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;

        # ==================== iQOO 海外版 ====================
        iqoo_z9_lite_5g)      DEVICE_TIP="iQOO Z9Lite 5G(天玑7200)"; TEMP_LIMIT="45" ;;
        iqoo_z9s_pro)         DEVICE_TIP="iQOO Z9sPro(骁龙7Gen3)"; TEMP_LIMIT="45" ;;
        iqoo_z10r)            DEVICE_TIP="iQOO Z10R(天玑7300)"; TEMP_LIMIT="45" ;;
        iqoo_z10_lite)        DEVICE_TIP="iQOO Z10Lite(骁龙6Gen1)"; TEMP_LIMIT="44" ;;
        iqoo_neo_10r_intl)    DEVICE_TIP="iQOO Neo10R国际版(骁龙8sGen3)"; BIG_MIN="1500000"; TEMP_LIMIT="46" ;;

        # ==================== vivo X 旗舰 ====================
        vivo_x500_pro_max)    DEVICE_TIP="vivo X500ProMax(天玑9500)"; BIG_MIN="1800000"; BIG_MAX="3800000"; TEMP_LIMIT="48" ;;
        vivo_x500_pro)        DEVICE_TIP="vivo X500Pro(天玑9500)"; BIG_MIN="1800000"; BIG_MAX="3800000"; TEMP_LIMIT="47" ;;
        vivo_x500)            DEVICE_TIP="vivo X500(天玑9500)"; BIG_MIN="1800000"; TEMP_LIMIT="47" ;;
        vivo_x300_ultra)      DEVICE_TIP="vivo X300Ultra(骁龙8Elite Gen5)"; BIG_MIN="2200000"; BIG_MAX="4400000"; TEMP_LIMIT="48" ;;
        vivo_x300_pro)        DEVICE_TIP="vivo X300Pro(天玑9500)"; BIG_MIN="1800000"; BIG_MAX="3800000"; TEMP_LIMIT="47" ;;
        vivo_x300s)           DEVICE_TIP="vivo X300s(天玑9500)"; BIG_MIN="1800000"; TEMP_LIMIT="47" ;;
        vivo_x300_e)          DEVICE_TIP="vivo X300E(天玑9400)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        vivo_x300)            DEVICE_TIP="vivo X300(天玑9500)"; BIG_MIN="1800000"; TEMP_LIMIT="47" ;;
        vivo_x200_ultra)      DEVICE_TIP="vivo X200Ultra(骁龙8Elite)"; BIG_MIN="2000000"; BIG_MAX="4200000"; TEMP_LIMIT="48" ;;
        vivo_x200_pro)        DEVICE_TIP="vivo X200Pro(天玑9400)"; BIG_MIN="1800000"; BIG_MAX="3620000"; TEMP_LIMIT="47" ;;
        vivo_x200s)           DEVICE_TIP="vivo X200s(天玑9400+)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        vivo_x200)            DEVICE_TIP="vivo X200(天玑9400)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        vivo_x100_ultra)      DEVICE_TIP="vivo X100Ultra(骁龙8Gen3)"; BIG_MIN="1800000"; TEMP_LIMIT="47" ;;
        vivo_x100_pro)        DEVICE_TIP="vivo X100Pro(天玑9300)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        vivo_x100s_pro)       DEVICE_TIP="vivo X100sPro(天玑9300+)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        vivo_x100s)           DEVICE_TIP="vivo X100s(天玑9300+)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        vivo_x100)            DEVICE_TIP="vivo X100(天玑9300)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        vivo_x90_pro_plus)    DEVICE_TIP="vivo X90Pro+(骁龙8Gen2)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        vivo_x90_pro)         DEVICE_TIP="vivo X90Pro(天玑9200)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        vivo_x90s)            DEVICE_TIP="vivo X90s(天玑9200+)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        vivo_x90)             DEVICE_TIP="vivo X90(天玑9200)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        vivo_x80_pro)         DEVICE_TIP="vivo X80Pro(骁龙8Gen1/天玑9000)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        vivo_x80)             DEVICE_TIP="vivo X80(天玑9000)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        vivo_x70_pro_plus)    DEVICE_TIP="vivo X70Pro+(骁龙888+)"; BIG_MIN="1800000"; TEMP_LIMIT="44" ;;
        vivo_x70_pro)         DEVICE_TIP="vivo X70Pro(Exynos1080/天玑1200)"; TEMP_LIMIT="44" ;;
        vivo_x70)             DEVICE_TIP="vivo X70(天玑1200)"; TEMP_LIMIT="44" ;;
        vivo_x60_pro_plus)    DEVICE_TIP="vivo X60Pro+(骁龙888)"; BIG_MIN="1800000"; TEMP_LIMIT="44" ;;
        vivo_x60_pro)         DEVICE_TIP="vivo X60Pro(Exynos1080)"; TEMP_LIMIT="44" ;;
        vivo_x60)             DEVICE_TIP="vivo X60(Exynos1080)"; TEMP_LIMIT="44" ;;
        vivo_x50_pro_plus)    DEVICE_TIP="vivo X50Pro+(骁龙865)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        vivo_x50_pro)         DEVICE_TIP="vivo X50Pro(骁龙765G)"; TEMP_LIMIT="44" ;;
        vivo_x50)             DEVICE_TIP="vivo X50(骁龙765G)"; TEMP_LIMIT="44" ;;
        vivo_x30_pro)         DEVICE_TIP="vivo X30Pro(Exynos980)"; TEMP_LIMIT="44" ;;
        vivo_x30)             DEVICE_TIP="vivo X30(Exynos980)"; TEMP_LIMIT="44" ;;
        vivo_x27_pro)         DEVICE_TIP="vivo X27Pro(骁龙710)"; TEMP_LIMIT="44" ;;
        vivo_x27)             DEVICE_TIP="vivo X27(骁龙675/710)"; TEMP_LIMIT="44" ;;
        vivo_x23)             DEVICE_TIP="vivo X23(骁龙670)"; TEMP_LIMIT="44" ;;
        vivo_x21)             DEVICE_TIP="vivo X21(骁龙660)"; TEMP_LIMIT="44" ;;
        vivo_x20_plus)        DEVICE_TIP="vivo X20Plus(骁龙660)"; TEMP_LIMIT="44" ;;
        vivo_x20)             DEVICE_TIP="vivo X20(骁龙660)"; TEMP_LIMIT="44" ;;
        vivo_x9s_plus)        DEVICE_TIP="vivo X9sPlus(骁龙653)"; TEMP_LIMIT="43" ;;
        vivo_x9)              DEVICE_TIP="vivo X9(骁龙625)"; TEMP_LIMIT="43" ;;

        # ==================== vivo X Fold / Flip ====================
        vivo_x_fold_6)        DEVICE_TIP="vivo XFold6(骁龙8Elite Gen5)"; BIG_MIN="2200000"; TEMP_LIMIT="48" ;;
        vivo_x_fold_5)        DEVICE_TIP="vivo XFold5(骁龙8Gen3)"; BIG_MIN="1800000"; TEMP_LIMIT="47" ;;
        vivo_x_fold_3_pro)    DEVICE_TIP="vivo XFold3Pro(骁龙8Gen3)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        vivo_x_fold_3)        DEVICE_TIP="vivo XFold3(骁龙8Gen2)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        vivo_x_fold_2)        DEVICE_TIP="vivo XFold2(骁龙8Gen2)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        vivo_x_fold_plus)     DEVICE_TIP="vivo XFold+(骁龙8+Gen1)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        vivo_x_fold)          DEVICE_TIP="vivo XFold(骁龙8Gen1)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        vivo_x_flip)          DEVICE_TIP="vivo XFlip(骁龙8+Gen1)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;

        # ==================== vivo S ====================
        vivo_s60_yuanqi)      DEVICE_TIP="vivo S60元气版(天玑8350)"; BIG_MIN="1500000"; TEMP_LIMIT="45" ;;
        vivo_s60)             DEVICE_TIP="vivo S60(天玑8400)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        vivo_s50_pro_mini)    DEVICE_TIP="vivo S50Pro mini(天玑9400e)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        vivo_s50)             DEVICE_TIP="vivo S50(天玑8400)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        vivo_s30_pro_mini)    DEVICE_TIP="vivo S30Pro mini(天玑9300+)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        vivo_s30)             DEVICE_TIP="vivo S30(骁龙7Gen4)"; TEMP_LIMIT="45" ;;
        vivo_s20_pro)         DEVICE_TIP="vivo S20Pro(天玑9300+)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        vivo_s20)             DEVICE_TIP="vivo S20(骁龙7Gen3)"; TEMP_LIMIT="45" ;;
        vivo_s19_pro)         DEVICE_TIP="vivo S19Pro(天玑9200+)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        vivo_s19)             DEVICE_TIP="vivo S19(骁龙7Gen3)"; TEMP_LIMIT="45" ;;
        vivo_s18_pro)         DEVICE_TIP="vivo S18Pro(天玑9200+)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        vivo_s18e)            DEVICE_TIP="vivo S18e(天玑7200)"; TEMP_LIMIT="45" ;;
        vivo_s18)             DEVICE_TIP="vivo S18(骁龙7Gen3)"; TEMP_LIMIT="45" ;;
        vivo_s17_pro)         DEVICE_TIP="vivo S17Pro(天玑8200)"; BIG_MIN="1500000"; TEMP_LIMIT="45" ;;
        vivo_s17e)            DEVICE_TIP="vivo S17e(天玑7200)"; TEMP_LIMIT="45" ;;
        vivo_s17)             DEVICE_TIP="vivo S17(骁龙778G+)"; TEMP_LIMIT="45" ;;
        vivo_s16_pro)         DEVICE_TIP="vivo S16Pro(天玑8200)"; BIG_MIN="1500000"; TEMP_LIMIT="45" ;;
        vivo_s16e)            DEVICE_TIP="vivo S16e(Exynos1080)"; TEMP_LIMIT="44" ;;
        vivo_s16)             DEVICE_TIP="vivo S16(骁龙870)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        vivo_s15_pro)         DEVICE_TIP="vivo S15Pro(天玑8100)"; BIG_MIN="1500000"; TEMP_LIMIT="45" ;;
        vivo_s15e)            DEVICE_TIP="vivo S15e(Exynos1080)"; TEMP_LIMIT="44" ;;
        vivo_s15)             DEVICE_TIP="vivo S15(骁龙870)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        vivo_s12_pro)         DEVICE_TIP="vivo S12Pro(天玑1200)"; BIG_MIN="1500000"; TEMP_LIMIT="44" ;;
        vivo_s12)             DEVICE_TIP="vivo S12(天玑1100)"; BIG_MIN="1500000"; TEMP_LIMIT="44" ;;
        vivo_s10_pro)         DEVICE_TIP="vivo S10Pro(天玑1100)"; BIG_MIN="1500000"; TEMP_LIMIT="44" ;;
        vivo_s10e)            DEVICE_TIP="vivo S10e(天玑700)"; TEMP_LIMIT="44" ;;
        vivo_s10)             DEVICE_TIP="vivo S10(天玑1100)"; BIG_MIN="1500000"; TEMP_LIMIT="44" ;;
        vivo_s9e)             DEVICE_TIP="vivo S9e(天玑820)"; TEMP_LIMIT="44" ;;
        vivo_s9)              DEVICE_TIP="vivo S9(天玑1100)"; BIG_MIN="1500000"; TEMP_LIMIT="44" ;;
        vivo_s7e)             DEVICE_TIP="vivo S7e(天玑720)"; TEMP_LIMIT="44" ;;
        vivo_s7)              DEVICE_TIP="vivo S7(骁龙765G)"; TEMP_LIMIT="44" ;;

        # ==================== vivo Y ====================
        vivo_y600i)           DEVICE_TIP="vivo Y600i(天玑7300)"; TEMP_LIMIT="45" ;;
        vivo_y600_turbo)      DEVICE_TIP="vivo Y600Turbo(骁龙7Gen4)"; TEMP_LIMIT="45" ;;
        vivo_y600_pro)        DEVICE_TIP="vivo Y600Pro(骁龙7sGen3)"; TEMP_LIMIT="45" ;;
        vivo_y600)            DEVICE_TIP="vivo Y600(骁龙6Gen4)"; TEMP_LIMIT="44" ;;
        vivo_y60)             DEVICE_TIP="vivo Y60(天玑6300)"; TEMP_LIMIT="44" ;;
        vivo_y6)              DEVICE_TIP="vivo Y6(骁龙4Gen2)"; TEMP_LIMIT="44" ;;
        vivo_y500i)           DEVICE_TIP="vivo Y500i(天玑7300)"; TEMP_LIMIT="45" ;;
        vivo_y500_pro)        DEVICE_TIP="vivo Y500Pro(骁龙6Gen4)"; TEMP_LIMIT="44" ;;
        vivo_y500)            DEVICE_TIP="vivo Y500(天玑6300)"; TEMP_LIMIT="44" ;;
        vivo_y50_5g)          DEVICE_TIP="vivo Y50 5G(天玑6300)"; TEMP_LIMIT="44" ;;
        vivo_y50m_5g)         DEVICE_TIP="vivo Y50m 5G(天玑6300)"; TEMP_LIMIT="44" ;;
        vivo_y50)             DEVICE_TIP="vivo Y50(骁龙665)"; TEMP_LIMIT="44" ;;
        vivo_y300_gt)         DEVICE_TIP="vivo Y300GT(天玑8400)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        vivo_y300t)           DEVICE_TIP="vivo Y300t(天玑7300)"; TEMP_LIMIT="45" ;;
        vivo_y300_pro_plus)   DEVICE_TIP="vivo Y300Pro+(骁龙7sGen3)"; TEMP_LIMIT="45" ;;
        vivo_y300i)           DEVICE_TIP="vivo Y300i(天玑6300)"; TEMP_LIMIT="44" ;;
        vivo_y300)            DEVICE_TIP="vivo Y300(天玑6300)"; TEMP_LIMIT="44" ;;
        vivo_y200_pro)        DEVICE_TIP="vivo Y200Pro(骁龙6Gen1)"; TEMP_LIMIT="44" ;;
        vivo_y200_gt)         DEVICE_TIP="vivo Y200GT(骁龙7Gen3)"; TEMP_LIMIT="45" ;;
        vivo_y200i)           DEVICE_TIP="vivo Y200i(骁龙6Gen1)"; TEMP_LIMIT="44" ;;
        vivo_y200)            DEVICE_TIP="vivo Y200(骁龙6Gen1)"; TEMP_LIMIT="44" ;;
        vivo_y100i)           DEVICE_TIP="vivo Y100i(天玑6020)"; TEMP_LIMIT="44" ;;
        vivo_y100)            DEVICE_TIP="vivo Y100(骁龙695)"; TEMP_LIMIT="44" ;;
        vivo_y78t)            DEVICE_TIP="vivo Y78t(天玑6020)"; TEMP_LIMIT="44" ;;
        vivo_y78_plus)        DEVICE_TIP="vivo Y78+(骁龙695)"; TEMP_LIMIT="44" ;;
        vivo_y78)             DEVICE_TIP="vivo Y78(天玑7020)"; TEMP_LIMIT="44" ;;
        vivo_y77t)            DEVICE_TIP="vivo Y77t(天玑7020)"; TEMP_LIMIT="44" ;;
        vivo_y77)             DEVICE_TIP="vivo Y77(天玑930)"; TEMP_LIMIT="44" ;;
        vivo_y76s)            DEVICE_TIP="vivo Y76s(天玑810)"; TEMP_LIMIT="44" ;;
        vivo_y75s)            DEVICE_TIP="vivo Y75s(天玑700)"; TEMP_LIMIT="44" ;;
        vivo_y73t)            DEVICE_TIP="vivo Y73t(天玑700)"; TEMP_LIMIT="44" ;;
        vivo_y55s)            DEVICE_TIP="vivo Y55s(天玑700)"; TEMP_LIMIT="44" ;;
        vivo_y53s)            DEVICE_TIP="vivo Y53s(天玑700)"; TEMP_LIMIT="44" ;;
        vivo_y37_pro)         DEVICE_TIP="vivo Y37Pro(骁龙4Gen2)"; TEMP_LIMIT="44" ;;
        vivo_y36)             DEVICE_TIP="vivo Y36(骁龙680)"; TEMP_LIMIT="44" ;;
        vivo_y35)             DEVICE_TIP="vivo Y35(天玑700)"; TEMP_LIMIT="44" ;;
        vivo_y33s)            DEVICE_TIP="vivo Y33s(天玑700)"; TEMP_LIMIT="44" ;;
        vivo_y32)             DEVICE_TIP="vivo Y32(骁龙680)"; TEMP_LIMIT="44" ;;
        vivo_y31s)            DEVICE_TIP="vivo Y31s(骁龙480)"; TEMP_LIMIT="44" ;;
        vivo_y30)             DEVICE_TIP="vivo Y30(骁龙460)"; TEMP_LIMIT="43" ;;
        vivo_y22)             DEVICE_TIP="vivo Y22(联发科G70)"; TEMP_LIMIT="43" ;;
        vivo_y21)             DEVICE_TIP="vivo Y21(联发科P35)"; TEMP_LIMIT="43" ;;
        vivo_y20)             DEVICE_TIP="vivo Y20(骁龙460)"; TEMP_LIMIT="43" ;;
        vivo_y19)             DEVICE_TIP="vivo Y19(联发科P65)"; TEMP_LIMIT="43" ;;
        vivo_y17)             DEVICE_TIP="vivo Y17(联发科P35)"; TEMP_LIMIT="43" ;;
        vivo_y15)             DEVICE_TIP="vivo Y15(联发科P22)"; TEMP_LIMIT="43" ;;

        # ==================== vivo NEX ====================
        vivo_nex_3s)          DEVICE_TIP="vivo NEX 3S(骁龙865)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        vivo_nex_3)           DEVICE_TIP="vivo NEX 3(骁龙855+)"; BIG_MIN="1785600"; TEMP_LIMIT="44" ;;
        vivo_nex_dual)        DEVICE_TIP="vivo NEX 双屏版(骁龙845)"; BIG_MIN="1766400"; TEMP_LIMIT="44" ;;
        vivo_nex_flagship)    DEVICE_TIP="vivo NEX 旗舰版(骁龙845)"; BIG_MIN="1766400"; TEMP_LIMIT="44" ;;
        vivo_nex_fp)          DEVICE_TIP="vivo NEX 屏幕指纹版(骁龙845)"; BIG_MIN="1766400"; TEMP_LIMIT="44" ;;
        vivo_nex)             DEVICE_TIP="vivo NEX(骁龙710)"; TEMP_LIMIT="44" ;;

        # ==================== vivo Xplay ====================
        vivo_xplay_6)         DEVICE_TIP="vivo Xplay6(骁龙820)"; TEMP_LIMIT="43" ;;
        vivo_xplay_5_elite)   DEVICE_TIP="vivo Xplay5 Elite(骁龙820)"; TEMP_LIMIT="43" ;;
        vivo_xplay_5)         DEVICE_TIP="vivo Xplay5(骁龙652)"; TEMP_LIMIT="43" ;;
        vivo_xplay_3s)        DEVICE_TIP="vivo Xplay3S(骁龙801)"; TEMP_LIMIT="43" ;;

        # ==================== vivo Z ====================
        vivo_z6)              DEVICE_TIP="vivo Z6(骁龙765G)"; TEMP_LIMIT="44" ;;
        vivo_z5x)             DEVICE_TIP="vivo Z5x(骁龙710)"; TEMP_LIMIT="44" ;;
        vivo_z5)              DEVICE_TIP="vivo Z5(骁龙712)"; TEMP_LIMIT="44" ;;
        vivo_z3x)             DEVICE_TIP="vivo Z3x(骁龙660)"; TEMP_LIMIT="43" ;;
        vivo_z3)              DEVICE_TIP="vivo Z3(骁龙670/710)"; TEMP_LIMIT="43" ;;
        vivo_z1_pro)          DEVICE_TIP="vivo Z1Pro(骁龙712)"; TEMP_LIMIT="44" ;;
        vivo_z1)              DEVICE_TIP="vivo Z1(骁龙660)"; TEMP_LIMIT="43" ;;

        # ==================== vivo U ====================
        vivo_u3x_std)         DEVICE_TIP="vivo U3x标准版(骁龙665)"; TEMP_LIMIT="44" ;;
        vivo_u3x)             DEVICE_TIP="vivo U3x(骁龙665)"; TEMP_LIMIT="44" ;;
        vivo_u3)              DEVICE_TIP="vivo U3(骁龙675)"; TEMP_LIMIT="44" ;;
        vivo_u1)              DEVICE_TIP="vivo U1(骁龙439)"; TEMP_LIMIT="43" ;;

        # ==================== vivo T（海外） ====================
        vivo_t3_ultra)        DEVICE_TIP="vivo T3Ultra(天玑9200+)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        vivo_t3_pro)          DEVICE_TIP="vivo T3Pro(骁龙7Gen3)"; TEMP_LIMIT="45" ;;
        vivo_t3)              DEVICE_TIP="vivo T3(天玑7200)"; TEMP_LIMIT="45" ;;
        vivo_t2x)             DEVICE_TIP="vivo T2x(天玑6020)"; TEMP_LIMIT="44" ;;
        vivo_t2_pro)          DEVICE_TIP="vivo T2Pro(天玑7200)"; TEMP_LIMIT="45" ;;
        vivo_t2)              DEVICE_TIP="vivo T2(骁龙695)"; TEMP_LIMIT="44" ;;
        vivo_t1x)             DEVICE_TIP="vivo T1x(天玑900)"; TEMP_LIMIT="44" ;;
        vivo_t1)              DEVICE_TIP="vivo T1(骁龙778G)"; TEMP_LIMIT="45" ;;

        # ==================== vivo Pad ====================
        vivo_pad_3_pro)       DEVICE_TIP="vivo Pad3Pro(天玑9300)"; BIG_MIN="1800000"; TEMP_LIMIT="46"; ENABLE_BYPASS_CHARGE=1 ;;
        vivo_pad_3)           DEVICE_TIP="vivo Pad3(骁龙8sGen3)"; BIG_MIN="1500000"; TEMP_LIMIT="45" ;;
        vivo_pad_2)           DEVICE_TIP="vivo Pad2(天玑9000)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        vivo_pad)             DEVICE_TIP="vivo Pad(骁龙870)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;

        *)                    DEVICE_TIP="通用设备"; TEMP_LIMIT="45" ;;
    esac
}