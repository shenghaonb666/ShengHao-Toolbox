function execShell(cmd, cb) {
    if (window.ksu && ksu.exec) ksu.exec(cmd, () => cb && cb());
    else if (typeof shell !== 'undefined' && shell.exec) shell.exec(cmd, () => cb && cb());
    else cb && cb();
}
function readShell(cmd) {
    try { if (window.ksu && ksu.exec) return ksu.exec(cmd) || ""; } catch(e){}
    return "";
}

function toast(text) {
    let t = document.getElementById('toast');
    t.innerText = text;
    t.classList.add('show');
    setTimeout(() => t.classList.remove('show'), 1500);
}

function setMode(gov) {
    let label = { performance: '性能模式', schedutil: '均衡模式', powersave: '省电模式' }[gov] || gov;
    execShell(`for cpu in /sys/devices/system/cpu/cpu[0-9]*; do echo ${gov} > $cpu/cpufreq/scaling_governor 2>/dev/null; done`, () => {
        execShell("for i in 4 5 6 7; do echo 300000 > /sys/devices/system/cpu/cpu$i/cpufreq/scaling_min_freq 2>/dev/null; done");
        toast('✅ 已切换到 ' + label);
        setTimeout(refresh, 500);
    });
}

function setGameMode() {
    let cmd = "for cpu in /sys/devices/system/cpu/cpu[0-9]*; do echo performance > $cpu/cpufreq/scaling_governor 2>/dev/null; done; " +
              "for i in 4 5 6 7; do echo 1804800 > /sys/devices/system/cpu/cpu$i/cpufreq/scaling_min_freq 2>/dev/null; done";
    execShell(cmd, () => {
        toast('🎮 游戏模式已启动');
        setTimeout(refresh, 500);
    });
}

function refresh() {
    let soc = readShell("cat /data/adb/modules/shenghao_lenovo_scheduler/webroot/soc_name.txt").trim();
    let dev = readShell("cat /data/adb/modules/shenghao_lenovo_scheduler/webroot/device_name.txt").trim();
    document.getElementById('soc').innerText = soc || "识别中...";
    document.getElementById('dev').innerText = dev || "识别中...";

    let gov = readShell("cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor").trim();
    let modeEmoji = { performance: '🚀 性能模式', schedutil: '☁️ 均衡模式', powersave: '🔋 省电模式' }[gov];
    document.getElementById('mode').innerText = modeEmoji || gov || "未知";

    let freq = readShell("cat /sys/devices/system/cpu/cpu7/cpufreq/scaling_cur_freq").trim();
    if (!freq) freq = readShell("cat /sys/devices/system/cpu/cpu4/cpufreq/scaling_cur_freq").trim();
    document.getElementById('freq').innerText = freq ? Math.round(parseInt(freq) / 1000) + " MHz" : "N/A";

    let temp = readShell("cat /sys/class/thermal/thermal_zone0/temp").trim();
    if (temp && !isNaN(temp)) {
        let t = Math.round(parseInt(temp) / 1000);
        let emoji = t < 35 ? '❄️' : t < 45 ? '🌤️' : '🔥';
        document.getElementById('temp').innerText = emoji + ' ' + t + ' °C';
    } else {
        document.getElementById('temp').innerText = "N/A";
    }
}

setInterval(refresh, 3000);
window.onload = refresh;