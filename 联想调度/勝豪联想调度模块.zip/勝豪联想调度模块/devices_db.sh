#!/system/bin/sh
# =====================================================
#         勝豪 联想/moto 全系列设备数据库 v2.0
#         作者：勝豪  Q群：1022873156
# =====================================================

detect_device_profile() {
    case "$1" in

        # ====================================================
        #                moto razr 折叠屏
        # ====================================================
        *razr 70 Ultra*|*XT2551*)                           echo "moto_razr_70_ultra" ;;
        *razr 70 Plus*|*XT2553*)                            echo "moto_razr_70_plus" ;;
        *razr 70*|*XT2555*)                                 echo "moto_razr_70" ;;
        *razr 60 Ultra*|*XT2451*)                           echo "moto_razr_60_ultra" ;;
        *razr 60*|*XT2453*)                                 echo "moto_razr_60" ;;
        *razr 50 Ultra*|*XT2451_50*)                        echo "moto_razr_50_ultra" ;;
        *razr 50*|*XT2453_50*)                              echo "moto_razr_50" ;;
        *razr 40 Ultra*|*XT2321*)                           echo "moto_razr_40_ultra" ;;
        *razr 40*|*XT2323*)                                 echo "moto_razr_40" ;;
        *razr 2022*|*XT2251*)                               echo "moto_razr_2022" ;;
        *razr 5G*|*XT2071*)                                 echo "moto_razr_5g" ;;
        *razr*)                                             echo "moto_razr" ;;

        # ====================================================
        #                moto edge 旗舰系列
        # ====================================================
        *edge 70 Pro*|*XT2507*)                             echo "moto_edge_70_pro" ;;
        *edge 70*|*XT2505*)                                 echo "moto_edge_70" ;;
        *edge 60 Pro*|*XT2407*)                             echo "moto_edge_60_pro" ;;
        *edge 60*|*XT2405*)                                 echo "moto_edge_60" ;;
        *edge 50 Ultra*|*XT2401*)                           echo "moto_edge_50_ultra" ;;
        *edge 50 Pro*|*XT2403*)                             echo "moto_edge_50_pro" ;;
        *edge 50 Fusion*|*XT2423*)                          echo "moto_edge_50_fusion" ;;
        *edge 50 Neo*|*XT2409*)                             echo "moto_edge_50_neo" ;;
        *edge 50*|*XT2405_50*)                              echo "moto_edge_50" ;;
        *edge 40 Pro*|*XT2301*)                             echo "moto_edge_40_pro" ;;
        *edge 40 Neo*|*XT2307*)                             echo "moto_edge_40_neo" ;;
        *edge 40*|*XT2303*)                                 echo "moto_edge_40" ;;
        *edge 30 Ultra*|*XT2241*)                           echo "moto_edge_30_ultra" ;;
        *edge 30 Pro*|*XT2201*)                             echo "moto_edge_30_pro" ;;
        *edge 30 Neo*|*XT2245*)                             echo "moto_edge_30_neo" ;;
        *edge 30 Fusion*|*XT2243*)                          echo "moto_edge_30_fusion" ;;
        *edge 30*|*XT2203*)                                 echo "moto_edge_30" ;;
        *edge 20 Pro*|*XT2153*)                             echo "moto_edge_20_pro" ;;
        *edge 20 Lite*|*XT2139*)                            echo "moto_edge_20_lite" ;;
        *edge 20*|*XT2141*)                                 echo "moto_edge_20" ;;
        *edge+*|*XT2061*)                                   echo "moto_edge_plus" ;;
        *edge s*|*XT2125*)                                  echo "moto_edge_s" ;;
        *edge*)                                             echo "moto_edge" ;;

        # ====================================================
        #                moto g 中端系列
        # ====================================================
        *moto g87*|*XT2527*)                                echo "moto_g87" ;;
        *moto g85*|*XT2427*)                                echo "moto_g85" ;;
        *moto g84*|*XT2347*)                                echo "moto_g84" ;;
        *moto g77*|*XT2523*)                                echo "moto_g77" ;;
        *moto g75*|*XT2437*)                                echo "moto_g75" ;;
        *moto g73*|*XT2337*)                                echo "moto_g73" ;;
        *moto g67*|*XT2521*)                                echo "moto_g67" ;;
        *moto g64*|*XT2435*)                                echo "moto_g64" ;;
        *moto g62*|*XT2223*)                                echo "moto_g62" ;;
        *moto g57 power*|*XT2525*)                          echo "moto_g57_power" ;;
        *moto g54*|*XT2343*)                                echo "moto_g54" ;;
        *moto g53*|*XT2335*)                                echo "moto_g53" ;;
        *moto g52*|*XT2221*)                                echo "moto_g52" ;;
        *moto g51*|*XT2171*)                                echo "moto_g51" ;;
        *moto g50*|*XT2137*)                                echo "moto_g50" ;;
        *moto g42*|*XT2233*)                                echo "moto_g42" ;;
        *moto g41*|*XT2169*)                                echo "moto_g41" ;;
        *moto g34*|*XT2369*)                                echo "moto_g34" ;;
        *moto g32*|*XT2239*)                                echo "moto_g32" ;;
        *moto g31*|*XT2163*)                                echo "moto_g31" ;;
        *moto g30*|*XT2129*)                                echo "moto_g30" ;;
        *moto g24*|*XT2421*)                                echo "moto_g24" ;;
        *moto g23*|*XT2333*)                                echo "moto_g23" ;;
        *moto g22*|*XT2231*)                                echo "moto_g22" ;;
        *moto g14*|*XT2341*)                                echo "moto_g14" ;;
        *moto g13*|*XT2331*)                                echo "moto_g13" ;;
        *moto g9*|*XT2083*)                                 echo "moto_g9" ;;
        *moto g8*|*XT2045*)                                 echo "moto_g8" ;;
        *moto g7*|*XT1962*)                                 echo "moto_g7" ;;
        *moto g6*|*XT1925*)                                 echo "moto_g6" ;;
        *moto g5*|*XT1675*)                                 echo "moto_g5" ;;
        *moto g*)                                           echo "moto_g" ;;

        # ====================================================
        #                moto e 入门系列
        # ====================================================
        *moto e15*|*XT2547*)                                echo "moto_e15" ;;
        *moto e14*|*XT2423_E14*)                            echo "moto_e14" ;;
        *moto e13*|*XT2345*)                                echo "moto_e13" ;;
        *moto e22*|*XT2231_E22*)                            echo "moto_e22" ;;
        *moto e20*|*XT2159*)                                echo "moto_e20" ;;
        *moto e*)                                           echo "moto_e" ;;

        # ====================================================
        #                ThinkPhone 商务系列
        # ====================================================
        *ThinkPhone 25*|*XT2503*)                           echo "thinkphone_25" ;;
        *ThinkPhone*|*XT2309*)                              echo "thinkphone" ;;

        # ====================================================
        #                拯救者电竞手机
        # ====================================================
        *LegionY90*|*L71061*)                               echo "legion_y90" ;;
        *LegionY70*|*L71091*)                               echo "legion_y70" ;;
        *LegionPhoneDuel2*|*L70081*)                        echo "legion_phone_2_pro" ;;
        *LegionPhoneDuel*|*L79031*)                         echo "legion_phone_pro" ;;
        *拯救者电竞手机2 Pro*)                              echo "legion_phone_2_pro" ;;
        *拯救者电竞手机 Pro*)                               echo "legion_phone_pro" ;;

        # ====================================================
        #                ZUK 系列（已停产）
        # ====================================================
        *ZUK Z2 Pro*|*Z2121*)                               echo "zuk_z2_pro" ;;
        *ZUK Z2*|*Z2131*)                                   echo "zuk_z2" ;;
        *ZUK Z1*|*Z1221*)                                   echo "zuk_z1" ;;
        *ZUK Edge*|*Z2151*)                                 echo "zuk_edge" ;;

        # ====================================================
        #                乐檬系列（已停产）
        # ====================================================
        *乐檬K3*|*K30-T*)                                   echo "lenovo_k3" ;;
        *乐檬K5 Note*|*K52*)                                echo "lenovo_k5_note" ;;
        *乐檬X3*|*X3c50*)                                   echo "lenovo_x3" ;;
        *乐檬3S*|*K32c36*)                                  echo "lenovo_3s" ;;
        *乐檬K12 Pro*|*XT2091*)                             echo "lenovo_k12_pro" ;;
        *乐檬K12*)                                          echo "lenovo_k12" ;;

        # ====================================================
        #                联想手机历史系列
        # ====================================================
        *Lenovo Z6Pro*|*L78051*)                           echo "lenovo_z6_pro" ;;
        *Lenovo Z6*|*L78121*)                               echo "lenovo_z6" ;;
        *Lenovo Z5ProGT*|*L78032*)                          echo "lenovo_z5_pro_gt" ;;
        *Lenovo Z5Pro*|*L78031*)                            echo "lenovo_z5_pro" ;;
        *Lenovo Z5s*|*L78071*)                              echo "lenovo_z5s" ;;
        *Lenovo Z5*|*L78011*)                               echo "lenovo_z5" ;;
        *Lenovo S5Pro*|*L58091*)                            echo "lenovo_s5_pro" ;;
        *Lenovo S5*|*K520*)                                 echo "lenovo_s5" ;;
        *Lenovo K10Note*|*P910*)                            echo "lenovo_k10_note" ;;
        *Lenovo K10Plus*|*K10*)                             echo "lenovo_k10_plus" ;;
        *Lenovo A5*|*A5*)                                   echo "lenovo_a5" ;;
        *Lenovo A6 Note*|*A6*)                              echo "lenovo_a6_note" ;;
        *Lenovo P2*|*P2a42*)                                echo "lenovo_p2" ;;
        *Lenovo Vibe X3*|*X3*)                              echo "lenovo_vibe_x3" ;;
        *Lenovo Vibe Shot*)                                 echo "lenovo_vibe_shot" ;;
        *Lenovo 黄金斗士*)                                   echo "lenovo_gold_warrior" ;;

        # ====================================================
        #                拯救者平板系列
        # ====================================================
        *TB321FU*|*拯救者Y700三代*)                         echo "legion_y700_3" ;;
        *TB320FC*|*拯救者Y700二代*)                         echo "legion_y700_2" ;;
        *TB-9707F*|*9707F*|*拯救者Y700*)                    echo "legion_y700" ;;
        *ZAH20136PE*|*LegionTab*)                           echo "legion_tab_gen3" ;;

        # ====================================================
        #                小新 Pad 系列
        # ====================================================
        *TB-J716F*|*J716F*|*小新PadPro2021*)                echo "xiaoxin_pad_pro_2021" ;;
        *TB-J606F*|*J606F*|*小新PadPro2020*|*TabP11*)       echo "xiaoxin_pad_pro_2020" ;;
        *TB-J607F*|*J607F*|*小新Pad2023*)                   echo "xiaoxin_pad_2023" ;;
        *TB-J616F*|*J616F*|*小新PadPlus*)                   echo "xiaoxin_pad_plus" ;;
        *TB-J618F*|*小新PadPro2022*)                        echo "xiaoxin_pad_pro_2022" ;;
        *TB710FU*|*小新PadProGT*)                           echo "xiaoxin_pad_pro_gt" ;;
        *TB128FU*|*小新Pad2022*|*TabM10Plus*)               echo "xiaoxin_pad_2022" ;;
        *TB330FU*|*小新Pad2024*)                            echo "xiaoxin_pad_2024" ;;
        *TB371FC*|*小新Pad2025*)                            echo "xiaoxin_pad_2025" ;;
        *ZACH0170MY*)                                       echo "tab_p11_gen2" ;;

        # ====================================================
        #                YOGA 系列平板
        # ====================================================
        *YT-K606F*|*YogaPadPro*)                            echo "yoga_pad_pro" ;;
        *YT3-X90L*|*YOGATab3Pro*)                           echo "yoga_tab_3_pro" ;;
        *YT-X705F*|*YOGATab5*)                              echo "yoga_tab_5" ;;
        *YT-J706F*|*YOGATab11*)                             echo "yoga_tab_11" ;;
        *YT-J706X*)                                         echo "yoga_tab_11_5g" ;;
        *YOGA*)                                             echo "yoga_tab" ;;

        # ====================================================
        #                天骄系列（教育）
        # ====================================================
        *天骄Pad*|*TB-J608F*)                               echo "tianjiao_pad" ;;
        *天骄Pad Pro*|*TB-J617F*)                           echo "tianjiao_pad_pro" ;;
        *天骄Pad SE*)                                       echo "tianjiao_pad_se" ;;
        *天骄16*)                                           echo "tianjiao_16" ;;

        # ====================================================
        #                Lenovo Tab 全球系列
        # ====================================================
        # Tab P 系列
        *Tab P12 Pro*|*TB-Q706F*)                           echo "tab_p12_pro" ;;
        *Tab P12*|*TB370FU*)                                echo "tab_p12" ;;
        *Tab P11 Pro Gen2*|*TB132FU*)                       echo "tab_p11_pro_gen2" ;;
        *Tab P11 Gen2*|*TB350FU*)                           echo "tab_p11_gen2_g" ;;
        *Tab P11 Pro*|*TB-J706F*)                           echo "tab_p11_pro" ;;
        *Tab P11*|*TB-J606X*)                               echo "tab_p11" ;;

        # Tab M 系列
        *Tab M11*|*TB330XU*)                                echo "tab_m11" ;;
        *Tab M10 Plus Gen3*|*TB125FU*)                      echo "tab_m10_plus_gen3" ;;
        *Tab M10 Plus*|*TB-X606X*)                          echo "tab_m10_plus" ;;
        *Tab M10 5G*|*TB-X607Z*)                            echo "tab_m10_5g" ;;
        *Tab M10 FHD Plus*|*TB-X606F*)                      echo "tab_m10_fhd" ;;
        *Tab M10 HD Gen2*|*TB-X306X*)                       echo "tab_m10_hd_gen2" ;;
        *Tab M10 HD*|*TB-X306F*)                            echo "tab_m10_hd" ;;
        *Tab M10*|*TB-X605F*)                               echo "tab_m10" ;;
        *Tab M9*|*TB310XU*)                                 echo "tab_m9" ;;
        *Tab M8 Gen4*|*TB300XU*)                            echo "tab_m8_gen4" ;;
        *Tab M8 Gen3*|*TB-8506F*)                           echo "tab_m8_gen3" ;;
        *Tab M8*|*TB-8505F*)                                echo "tab_m8" ;;
        *Tab M7*|*TB-7305F*)                                echo "tab_m7" ;;

        # Tab K 系列
        *Tab K12*|*TB370XU*)                                echo "tab_k12" ;;
        *Tab K11 Plus*|*TB352XU*)                           echo "tab_k11_plus" ;;
        *Tab K11*|*TB330XU_K11*)                            echo "tab_k11" ;;
        *Tab K10*|*TB223FC*)                                echo "tab_k10" ;;

        # Idea Tab 系列
        *Idea Tab Pro Gen2*|*TB336FU*)                      echo "idea_tab_pro_gen2" ;;
        *Idea Tab Pro*|*TB373FU*)                           echo "idea_tab_pro" ;;
        *Idea Tab Plus*|*TB361FU*)                          echo "idea_tab_plus" ;;
        *Idea Tab*|*TB336XU*)                               echo "idea_tab" ;;

        # ====================================================
        #                默认兜底
        # ====================================================
        *)                                                  echo "generic" ;;
    esac
}

# ==================== 设备专属参数 ====================
apply_device_profile() {
    TEMP_LIMIT="45"
    ENABLE_BYPASS_CHARGE=0

    case "$1" in

        # ==================== moto razr ====================
        moto_razr_70_ultra)   DEVICE_TIP="moto razr70Ultra(骁龙8Elite)"; BIG_MIN="2000000"; BIG_MAX="4200000"; TEMP_LIMIT="47" ;;
        moto_razr_70_plus)    DEVICE_TIP="moto razr70Plus(骁龙8Gen3)"; BIG_MIN="1800000"; TEMP_LIMIT="47" ;;
        moto_razr_70)         DEVICE_TIP="moto razr70(骁龙8sGen3)"; BIG_MIN="1500000"; TEMP_LIMIT="46" ;;
        moto_razr_60_ultra)   DEVICE_TIP="moto razr60Ultra(骁龙8Elite)"; BIG_MIN="2000000"; TEMP_LIMIT="47" ;;
        moto_razr_60)         DEVICE_TIP="moto razr60(骁龙8sGen3)"; BIG_MIN="1500000"; TEMP_LIMIT="46" ;;
        moto_razr_50_ultra)   DEVICE_TIP="moto razr50Ultra(骁龙8sGen3)"; BIG_MIN="1500000"; TEMP_LIMIT="46" ;;
        moto_razr_50)         DEVICE_TIP="moto razr50(天玑7300X)"; TEMP_LIMIT="45" ;;
        moto_razr_40_ultra)   DEVICE_TIP="moto razr40Ultra(骁龙8+Gen1)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        moto_razr_40)         DEVICE_TIP="moto razr40(骁龙7Gen1)"; TEMP_LIMIT="45" ;;
        moto_razr_2022)       DEVICE_TIP="moto razr2022(骁龙8+Gen1)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        moto_razr_5g)         DEVICE_TIP="moto razr 5G(骁龙765G)"; TEMP_LIMIT="44" ;;
        moto_razr)            DEVICE_TIP="moto razr系列"; TEMP_LIMIT="45" ;;

        # ==================== moto edge ====================
        moto_edge_70_pro)     DEVICE_TIP="moto edge70Pro(骁龙8Elite)"; BIG_MIN="2000000"; BIG_MAX="4200000"; TEMP_LIMIT="47" ;;
        moto_edge_70)         DEVICE_TIP="moto edge70(骁龙8sGen4)"; BIG_MIN="1500000"; TEMP_LIMIT="46" ;;
        moto_edge_60_pro)     DEVICE_TIP="moto edge60Pro(骁龙8sGen3)"; BIG_MIN="1500000"; TEMP_LIMIT="46" ;;
        moto_edge_60)         DEVICE_TIP="moto edge60(天玑8350)"; BIG_MIN="1500000"; TEMP_LIMIT="45" ;;
        moto_edge_50_ultra)   DEVICE_TIP="moto edge50Ultra(骁龙8sGen3)"; BIG_MIN="1500000"; TEMP_LIMIT="46" ;;
        moto_edge_50_pro)     DEVICE_TIP="moto edge50Pro(骁龙8sGen3)"; BIG_MIN="1500000"; TEMP_LIMIT="46" ;;
        moto_edge_50_fusion)  DEVICE_TIP="moto edge50Fusion(骁龙6Gen1)"; TEMP_LIMIT="44" ;;
        moto_edge_50_neo)     DEVICE_TIP="moto edge50Neo(天玑7300)"; TEMP_LIMIT="45" ;;
        moto_edge_50)         DEVICE_TIP="moto edge50(骁龙7Gen3)"; TEMP_LIMIT="45" ;;
        moto_edge_40_pro)     DEVICE_TIP="moto edge40Pro(骁龙8Gen2)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        moto_edge_40_neo)     DEVICE_TIP="moto edge40Neo(天玑7020)"; TEMP_LIMIT="44" ;;
        moto_edge_40)         DEVICE_TIP="moto edge40(天玑8020)"; TEMP_LIMIT="45" ;;
        moto_edge_30_ultra)   DEVICE_TIP="moto edge30Ultra(骁龙8+Gen1)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        moto_edge_30_pro)     DEVICE_TIP="moto edge30Pro(骁龙8Gen1)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        moto_edge_30_neo)     DEVICE_TIP="moto edge30Neo(骁龙695)"; TEMP_LIMIT="44" ;;
        moto_edge_30_fusion)  DEVICE_TIP="moto edge30Fusion(骁龙888+)"; BIG_MIN="1800000"; TEMP_LIMIT="44" ;;
        moto_edge_30)         DEVICE_TIP="moto edge30(骁龙8Gen1)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        moto_edge_20_pro)     DEVICE_TIP="moto edge20Pro(骁龙870)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        moto_edge_20_lite)    DEVICE_TIP="moto edge20Lite(骁龙778G)"; TEMP_LIMIT="45" ;;
        moto_edge_20)         DEVICE_TIP="moto edge20(骁龙778G)"; TEMP_LIMIT="45" ;;
        moto_edge_plus)       DEVICE_TIP="moto edge+(骁龙865)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        moto_edge_s)          DEVICE_TIP="moto edge s(骁龙870)"; BIG_MIN="1800000"; TEMP_LIMIT="45" ;;
        moto_edge)            DEVICE_TIP="moto edge系列"; TEMP_LIMIT="45" ;;

        # ==================== moto g ====================
        moto_g87)             DEVICE_TIP="moto g87(骁龙6sGen3)"; TEMP_LIMIT="44" ;;
        moto_g85)             DEVICE_TIP="moto g85(骁龙6sGen3)"; TEMP_LIMIT="44" ;;
        moto_g84)             DEVICE_TIP="moto g84(骁龙695)"; TEMP_LIMIT="44" ;;
        moto_g77)             DEVICE_TIP="moto g77(天玑6300)"; TEMP_LIMIT="44" ;;
        moto_g75)             DEVICE_TIP="moto g75(骁龙6Gen3)"; TEMP_LIMIT="44" ;;
        moto_g73)             DEVICE_TIP="moto g73(天玑930)"; TEMP_LIMIT="44" ;;
        moto_g67)             DEVICE_TIP="moto g67(天玑6300)"; TEMP_LIMIT="44" ;;
        moto_g64)             DEVICE_TIP="moto g64(天玑7025)"; TEMP_LIMIT="44" ;;
        moto_g62)             DEVICE_TIP="moto g62(骁龙480+)"; TEMP_LIMIT="44" ;;
        moto_g57_power)       DEVICE_TIP="moto g57 Power(骁龙6sGen3)"; TEMP_LIMIT="44" ;;
        moto_g54)             DEVICE_TIP="moto g54(天玑7020)"; TEMP_LIMIT="44" ;;
        moto_g53)             DEVICE_TIP="moto g53(骁龙480+)"; TEMP_LIMIT="44" ;;
        moto_g52)             DEVICE_TIP="moto g52(骁龙680)"; TEMP_LIMIT="44" ;;
        moto_g51)             DEVICE_TIP="moto g51(骁龙480+)"; TEMP_LIMIT="44" ;;
        moto_g50)             DEVICE_TIP="moto g50(骁龙480)"; TEMP_LIMIT="44" ;;
        moto_g42)             DEVICE_TIP="moto g42(骁龙680)"; TEMP_LIMIT="44" ;;
        moto_g41)             DEVICE_TIP="moto g41(联发科G85)"; TEMP_LIMIT="43" ;;
        moto_g34)             DEVICE_TIP="moto g34(骁龙695)"; TEMP_LIMIT="44" ;;
        moto_g32)             DEVICE_TIP="moto g32(骁龙680)"; TEMP_LIMIT="44" ;;
        moto_g31)             DEVICE_TIP="moto g31(联发科G85)"; TEMP_LIMIT="43" ;;
        moto_g30)             DEVICE_TIP="moto g30(骁龙662)"; TEMP_LIMIT="43" ;;
        moto_g24)             DEVICE_TIP="moto g24(联发科G85)"; TEMP_LIMIT="43" ;;
        moto_g23)             DEVICE_TIP="moto g23(联发科G85)"; TEMP_LIMIT="43" ;;
        moto_g22)             DEVICE_TIP="moto g22(联发科G37)"; TEMP_LIMIT="43" ;;
        moto_g14)             DEVICE_TIP="moto g14(紫光展锐T616)"; TEMP_LIMIT="43" ;;
        moto_g13)             DEVICE_TIP="moto g13(联发科G85)"; TEMP_LIMIT="43" ;;
        moto_g9)              DEVICE_TIP="moto g9(骁龙662)"; TEMP_LIMIT="43" ;;
        moto_g8)              DEVICE_TIP="moto g8(骁龙665)"; TEMP_LIMIT="43" ;;
        moto_g7)              DEVICE_TIP="moto g7(骁龙632)"; TEMP_LIMIT="43" ;;
        moto_g6)              DEVICE_TIP="moto g6(骁龙450)"; TEMP_LIMIT="43" ;;
        moto_g5)              DEVICE_TIP="moto g5(骁龙430)"; TEMP_LIMIT="43" ;;
        moto_g)               DEVICE_TIP="moto g系列"; TEMP_LIMIT="44" ;;

        # ==================== moto e ====================
        moto_e15)             DEVICE_TIP="moto e15(紫光展锐T606)"; TEMP_LIMIT="43" ;;
        moto_e14)             DEVICE_TIP="moto e14(紫光展锐T606)"; TEMP_LIMIT="43" ;;
        moto_e13)             DEVICE_TIP="moto e13(紫光展锐T606)"; TEMP_LIMIT="43" ;;
        moto_e22)             DEVICE_TIP="moto e22(联发科G37)"; TEMP_LIMIT="43" ;;
        moto_e20)             DEVICE_TIP="moto e20(紫光展锐T606)"; TEMP_LIMIT="43" ;;
        moto_e)               DEVICE_TIP="moto e系列"; TEMP_LIMIT="43" ;;

        # ==================== ThinkPhone ====================
        thinkphone_25)        DEVICE_TIP="ThinkPhone25(天玑7300)"; TEMP_LIMIT="45" ;;
        thinkphone)           DEVICE_TIP="ThinkPhone(骁龙8+Gen1)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;

        # ==================== 拯救者手机 ====================
        legion_y90)           DEVICE_TIP="拯救者Y90(骁龙8Gen1)"; BIG_MIN="1800000"; TEMP_LIMIT="50"; ENABLE_BYPASS_CHARGE=1 ;;
        legion_y70)           DEVICE_TIP="拯救者Y70(骁龙8+Gen1)"; BIG_MIN="1800000"; TEMP_LIMIT="48" ;;
        legion_phone_2_pro)   DEVICE_TIP="拯救者电竞手机2Pro(骁龙888)"; BIG_MIN="1800000"; TEMP_LIMIT="50"; ENABLE_BYPASS_CHARGE=1 ;;
        legion_phone_pro)     DEVICE_TIP="拯救者电竞手机Pro(骁龙865+)"; BIG_MIN="1800000"; TEMP_LIMIT="50"; ENABLE_BYPASS_CHARGE=1 ;;

        # ==================== ZUK ====================
        zuk_z2_pro)           DEVICE_TIP="ZUK Z2Pro(骁龙820)"; TEMP_LIMIT="44" ;;
        zuk_z2)               DEVICE_TIP="ZUK Z2(骁龙820)"; TEMP_LIMIT="44" ;;
        zuk_z1)               DEVICE_TIP="ZUK Z1(骁龙801)"; TEMP_LIMIT="43" ;;
        zuk_edge)             DEVICE_TIP="ZUK Edge(骁龙821)"; TEMP_LIMIT="44" ;;

        # ==================== 乐檬 ====================
        lenovo_k3)            DEVICE_TIP="乐檬K3(骁龙410)"; TEMP_LIMIT="43" ;;
        lenovo_k5_note)       DEVICE_TIP="乐檬K5Note(联发科P10)"; TEMP_LIMIT="43" ;;
        lenovo_x3)            DEVICE_TIP="乐檬X3(骁龙808)"; TEMP_LIMIT="44" ;;
        lenovo_3s)            DEVICE_TIP="乐檬3S(联发科)"; TEMP_LIMIT="43" ;;
        lenovo_k12_pro)       DEVICE_TIP="乐檬K12Pro(骁龙662)"; TEMP_LIMIT="44" ;;
        lenovo_k12)           DEVICE_TIP="乐檬K12(骁龙460)"; TEMP_LIMIT="43" ;;

        # ==================== 联想手机 ====================
        lenovo_z6_pro)        DEVICE_TIP="联想Z6Pro(骁龙855)"; BIG_MIN="1785600"; TEMP_LIMIT="44" ;;
        lenovo_z6)            DEVICE_TIP="联想Z6(骁龙730)"; TEMP_LIMIT="44" ;;
        lenovo_z5_pro_gt)     DEVICE_TIP="联想Z5ProGT(骁龙855)"; BIG_MIN="1785600"; TEMP_LIMIT="44" ;;
        lenovo_z5_pro)        DEVICE_TIP="联想Z5Pro(骁龙710)"; TEMP_LIMIT="44" ;;
        lenovo_z5s)           DEVICE_TIP="联想Z5s(骁龙710)"; TEMP_LIMIT="44" ;;
        lenovo_z5)            DEVICE_TIP="联想Z5(骁龙636)"; TEMP_LIMIT="43" ;;
        lenovo_s5_pro)        DEVICE_TIP="联想S5Pro(骁龙636)"; TEMP_LIMIT="43" ;;
        lenovo_s5)            DEVICE_TIP="联想S5(骁龙625)"; TEMP_LIMIT="43" ;;
        lenovo_k10_note)      DEVICE_TIP="联想K10Note(骁龙710)"; TEMP_LIMIT="44" ;;
        lenovo_k10_plus)      DEVICE_TIP="联想K10Plus(骁龙710)"; TEMP_LIMIT="44" ;;
        lenovo_a5)            DEVICE_TIP="联想A5(骁龙425)"; TEMP_LIMIT="43" ;;
        lenovo_a6_note)       DEVICE_TIP="联想A6Note(骁龙439)"; TEMP_LIMIT="43" ;;
        lenovo_p2)            DEVICE_TIP="联想P2(骁龙625)"; TEMP_LIMIT="43" ;;
        lenovo_vibe_x3)       DEVICE_TIP="联想VibeX3(骁龙808)"; TEMP_LIMIT="44" ;;
        lenovo_vibe_shot)     DEVICE_TIP="联想VibeShot(骁龙615)"; TEMP_LIMIT="43" ;;
        lenovo_gold_warrior)  DEVICE_TIP="联想黄金斗士"; TEMP_LIMIT="43" ;;

        # ==================== 拯救者平板 ====================
        legion_y700_3)        DEVICE_TIP="拯救者Y700三代(骁龙8Gen3)"; BIG_MIN="1804800"; BIG_MAX="3300000"; TEMP_LIMIT="48"; ENABLE_BYPASS_CHARGE=1 ;;
        legion_y700_2)        DEVICE_TIP="拯救者Y700二代(骁龙8+)"; BIG_MIN="1804800"; BIG_MAX="3187200"; TEMP_LIMIT="48"; ENABLE_BYPASS_CHARGE=1 ;;
        legion_y700)          DEVICE_TIP="拯救者Y700一代(骁龙870)"; BIG_MIN="1804800"; BIG_MAX="2841600"; TEMP_LIMIT="48"; ENABLE_BYPASS_CHARGE=1 ;;
        legion_tab_gen3)      DEVICE_TIP="LegionTabGen3(骁龙8Gen3)"; BIG_MIN="1804800"; BIG_MAX="3300000"; TEMP_LIMIT="48"; ENABLE_BYPASS_CHARGE=1 ;;

        # ==================== 小新 Pad ====================
        xiaoxin_pad_pro_2021) DEVICE_TIP="小新PadPro2021(骁龙870)"; BIG_MIN="1804800"; BIG_MAX="2841600"; TEMP_LIMIT="43" ;;
        xiaoxin_pad_pro_2020) DEVICE_TIP="小新PadPro2020(骁龙730G)"; TEMP_LIMIT="42" ;;
        xiaoxin_pad_2023)     DEVICE_TIP="小新Pad2023(骁龙685)"; TEMP_LIMIT="44" ;;
        xiaoxin_pad_plus)     DEVICE_TIP="小新PadPlus(骁龙750G)"; TEMP_LIMIT="44" ;;
        xiaoxin_pad_pro_2022) DEVICE_TIP="小新PadPro2022(骁龙870)"; BIG_MIN="1804800"; BIG_MAX="2841600"; TEMP_LIMIT="43" ;;
        xiaoxin_pad_pro_gt)   DEVICE_TIP="小新PadProGT(骁龙8Gen3)"; BIG_MIN="1804800"; BIG_MAX="3300000"; TEMP_LIMIT="47"; ENABLE_BYPASS_CHARGE=1 ;;
        xiaoxin_pad_2022)     DEVICE_TIP="小新Pad2022(骁龙680)"; TEMP_LIMIT="44" ;;
        xiaoxin_pad_2024)     DEVICE_TIP="小新Pad2024(骁龙685)"; TEMP_LIMIT="44" ;;
        xiaoxin_pad_2025)     DEVICE_TIP="小新Pad2025(骁龙6Gen1)"; TEMP_LIMIT="44" ;;
        tab_p11_gen2)         DEVICE_TIP="联想TabP11二代(天玑7050)"; BIG_MIN="1200000"; BIG_MAX="2600000"; TEMP_LIMIT="44" ;;

        # ==================== YOGA ====================
        yoga_pad_pro)         DEVICE_TIP="YogaPadPro(骁龙870)"; BIG_MIN="1804800"; BIG_MAX="2841600"; TEMP_LIMIT="45" ;;
        yoga_tab_3_pro)       DEVICE_TIP="YOGA Tab3Pro(骁龙652)"; TEMP_LIMIT="43" ;;
        yoga_tab_5)           DEVICE_TIP="YOGA Tab5(骁龙855)"; BIG_MIN="1785600"; TEMP_LIMIT="44" ;;
        yoga_tab_11)          DEVICE_TIP="YOGA Tab11(骁龙855)"; BIG_MIN="1785600"; TEMP_LIMIT="44" ;;
        yoga_tab_11_5g)       DEVICE_TIP="YOGA Tab11 5G(骁龙855)"; BIG_MIN="1785600"; TEMP_LIMIT="44" ;;
        yoga_tab)             DEVICE_TIP="YOGA Tab系列"; TEMP_LIMIT="44" ;;

        # ==================== 天骄 ====================
        tianjiao_pad)         DEVICE_TIP="天骄Pad(骁龙680)"; TEMP_LIMIT="43" ;;
        tianjiao_pad_pro)     DEVICE_TIP="天骄PadPro(骁龙870)"; BIG_MIN="1804800"; TEMP_LIMIT="44" ;;
        tianjiao_pad_se)      DEVICE_TIP="天骄PadSE(HelioG88)"; TEMP_LIMIT="43" ;;
        tianjiao_16)          DEVICE_TIP="天骄16(骁龙680)"; TEMP_LIMIT="43" ;;

        # ==================== Lenovo Tab P ====================
        tab_p12_pro)          DEVICE_TIP="TabP12Pro(骁龙870)"; BIG_MIN="1804800"; BIG_MAX="2841600"; TEMP_LIMIT="45" ;;
        tab_p12)              DEVICE_TIP="TabP12(天玑7050)"; BIG_MIN="1200000"; TEMP_LIMIT="45" ;;
        tab_p11_pro_gen2)     DEVICE_TIP="TabP11Pro二代(天玑1300T)"; BIG_MIN="1500000"; TEMP_LIMIT="45" ;;
        tab_p11_gen2_g)       DEVICE_TIP="TabP11二代(HelioG99)"; TEMP_LIMIT="44" ;;
        tab_p11_pro)          DEVICE_TIP="TabP11Pro(骁龙730G)"; TEMP_LIMIT="44" ;;
        tab_p11)              DEVICE_TIP="TabP11(骁龙662)"; TEMP_LIMIT="44" ;;

        # ==================== Lenovo Tab M ====================
        tab_m11)              DEVICE_TIP="TabM11(HelioG88)"; TEMP_LIMIT="44" ;;
        tab_m10_plus_gen3)    DEVICE_TIP="TabM10Plus三代(HelioG99)"; TEMP_LIMIT="44" ;;
        tab_m10_plus)         DEVICE_TIP="TabM10Plus(HelioP22T)"; TEMP_LIMIT="43" ;;
        tab_m10_5g)           DEVICE_TIP="TabM10 5G(骁龙695)"; TEMP_LIMIT="44" ;;
        tab_m10_fhd)          DEVICE_TIP="TabM10 FHD Plus(HelioP22T)"; TEMP_LIMIT="43" ;;
        tab_m10_hd_gen2)      DEVICE_TIP="TabM10 HD二代(HelioP22T)"; TEMP_LIMIT="43" ;;
        tab_m10_hd)           DEVICE_TIP="TabM10 HD(HelioP22T)"; TEMP_LIMIT="43" ;;
        tab_m10)              DEVICE_TIP="TabM10(骁龙450)"; TEMP_LIMIT="43" ;;
        tab_m9)               DEVICE_TIP="TabM9(HelioG80)"; TEMP_LIMIT="43" ;;
        tab_m8_gen4)          DEVICE_TIP="TabM8四代(HelioG80)"; TEMP_LIMIT="43" ;;
        tab_m8_gen3)          DEVICE_TIP="TabM8三代(HelioP22T)"; TEMP_LIMIT="43" ;;
        tab_m8)               DEVICE_TIP="TabM8(HelioP22T)"; TEMP_LIMIT="43" ;;
        tab_m7)               DEVICE_TIP="TabM7(联发科MT8166)"; TEMP_LIMIT="43" ;;

        # ==================== Lenovo Tab K ====================
        tab_k12)              DEVICE_TIP="TabK12(天玑7300)"; TEMP_LIMIT="44" ;;
        tab_k11_plus)         DEVICE_TIP="TabK11Plus(骁龙8sGen3)"; BIG_MIN="1500000"; TEMP_LIMIT="45" ;;
        tab_k11)              DEVICE_TIP="TabK11(HelioG99)"; TEMP_LIMIT="44" ;;
        tab_k10)              DEVICE_TIP="TabK10(HelioP22T)"; TEMP_LIMIT="43" ;;

        # ==================== Idea Tab ====================
        idea_tab_pro_gen2)    DEVICE_TIP="IdeaTabPro二代(天玑8300)"; BIG_MIN="1500000"; TEMP_LIMIT="45" ;;
        idea_tab_pro)         DEVICE_TIP="IdeaTabPro(骁龙8Gen3)"; BIG_MIN="1800000"; TEMP_LIMIT="46" ;;
        idea_tab_plus)        DEVICE_TIP="IdeaTabPlus(天玑8300)"; BIG_MIN="1500000"; TEMP_LIMIT="45" ;;
        idea_tab)             DEVICE_TIP="IdeaTab(骁龙685)"; TEMP_LIMIT="44" ;;

        *)                    DEVICE_TIP="通用设备"; TEMP_LIMIT="45" ;;
    esac
}