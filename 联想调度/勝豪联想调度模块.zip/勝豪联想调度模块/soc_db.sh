#!/system/bin/sh
# =====================================================
#         勝豪 SoC 数据库 - 联想专版
#         作者：勝豪  Q群：1022873156
# =====================================================

# ==================== 高通骁龙 8系 ====================
soc_sd8elite_gen5() {
    SOC_NAME="高通 骁龙8 Elite Gen 5"
    BIG_CORES="6 7"; LITTLE_CORES="0 1 2 3 4 5"
    BIG_MIN="2200000"; BIG_MAX="4600000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd8elite() {
    SOC_NAME="高通 骁龙8 Elite"
    BIG_CORES="6 7"; LITTLE_CORES="0 1 2 3 4 5"
    BIG_MIN="2200000"; BIG_MAX="4320000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd8gen3() {
    SOC_NAME="高通 骁龙8 Gen 3"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1804800"; BIG_MAX="3300000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd8gen2() {
    SOC_NAME="高通 骁龙8 Gen 2"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1804800"; BIG_MAX="3200000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd8gen1p() {
    SOC_NAME="高通 骁龙8+ Gen 1"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1804800"; BIG_MAX="3187200"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd8gen1() {
    SOC_NAME="高通 骁龙8 Gen 1"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1804800"; BIG_MAX="2995200"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd888() {
    SOC_NAME="高通 骁龙888/888+"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1804800"; BIG_MAX="2419200"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd870_865() {
    SOC_NAME="高通 骁龙870/865"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1804800"; BIG_MAX="2841600"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd855() {
    SOC_NAME="高通 骁龙855/855+"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1785600"; BIG_MAX="2841600"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}

# ==================== 高通骁龙 8s / 7系 ====================
soc_sd8sgen4() {
    SOC_NAME="高通 骁龙8s Gen 4"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1500000"; BIG_MAX="3200000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd8sgen3() {
    SOC_NAME="高通 骁龙8s Gen 3"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1500000"; BIG_MAX="3000000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd7pgen3() {
    SOC_NAME="高通 骁龙7+ Gen 3"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1800000"; BIG_MAX="2800000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd7gen3() {
    SOC_NAME="高通 骁龙7 Gen 3"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1200000"; BIG_MAX="2630000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd7gen1() {
    SOC_NAME="高通 骁龙7 Gen 1"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1200000"; BIG_MAX="2400000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd782g() {
    SOC_NAME="高通 骁龙782G"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1200000"; BIG_MAX="2400000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd778g() {
    SOC_NAME="高通 骁龙778G/778G+"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1200000"; BIG_MAX="2400000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd768g_765g() {
    SOC_NAME="高通 骁龙768G/765G"
    BIG_CORES="6 7"; LITTLE_CORES="0 1 2 3 4 5"
    BIG_MIN="1200000"; BIG_MAX="2800000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd750g() {
    SOC_NAME="高通 骁龙750G"
    BIG_CORES="6 7"; LITTLE_CORES="0 1 2 3 4 5"
    BIG_MIN="1200000"; BIG_MAX="2200000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd732g_730g() {
    SOC_NAME="高通 骁龙732G/730G"
    BIG_CORES="6 7"; LITTLE_CORES="0 1 2 3 4 5"
    BIG_MIN="1200000"; BIG_MAX="2200000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}

# ==================== 高通骁龙 6系/4系 ====================
soc_sd6sgen3() {
    SOC_NAME="高通 骁龙6s Gen 3"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1200000"; BIG_MAX="2400000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd6gen3() {
    SOC_NAME="高通 骁龙6 Gen 3"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1200000"; BIG_MAX="2400000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd6gen1() {
    SOC_NAME="高通 骁龙6 Gen 1"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1200000"; BIG_MAX="2200000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd695() {
    SOC_NAME="高通 骁龙695"
    BIG_CORES="6 7"; LITTLE_CORES="0 1 2 3 4 5"
    BIG_MIN="1200000"; BIG_MAX="2200000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd680() {
    SOC_NAME="高通 骁龙680"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1200000"; BIG_MAX="2400000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd685() {
    SOC_NAME="高通 骁龙685"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1200000"; BIG_MAX="2400000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd662() {
    SOC_NAME="高通 骁龙662"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1100000"; BIG_MAX="2000000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd665() {
    SOC_NAME="高通 骁龙665"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1100000"; BIG_MAX="2000000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd636() {
    SOC_NAME="高通 骁龙636"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1100000"; BIG_MAX="1800000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd632() {
    SOC_NAME="高通 骁龙632"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1100000"; BIG_MAX="1800000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd625() {
    SOC_NAME="高通 骁龙625"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="960000"; BIG_MAX="2000000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd615() {
    SOC_NAME="高通 骁龙615"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="800000"; BIG_MAX="1700000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd480() {
    SOC_NAME="高通 骁龙480/480+"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1100000"; BIG_MAX="2000000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd460() {
    SOC_NAME="高通 骁龙460"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1100000"; BIG_MAX="1800000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd450() {
    SOC_NAME="高通 骁龙450"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="960000"; BIG_MAX="1800000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd439() {
    SOC_NAME="高通 骁龙439"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="960000"; BIG_MAX="1401000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd430() {
    SOC_NAME="高通 骁龙430"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="800000"; BIG_MAX="1400000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd425() {
    SOC_NAME="高通 骁龙425"
    BIG_CORES="2 3"; LITTLE_CORES="0 1"
    BIG_MIN="800000"; BIG_MAX="1400000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd808() {
    SOC_NAME="高通 骁龙808"
    BIG_CORES="4 5"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1200000"; BIG_MAX="1824000"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}
soc_sd801_800() {
    SOC_NAME="高通 骁龙801/800"
    BIG_CORES="0 1 2 3"; LITTLE_CORES="0"
    BIG_MIN="1190400"; BIG_MAX="2457600"
    GPU_GOV="msm-adreno-tz"; GOVERNOR="schedutil"
}

# ==================== 联发科天玑 ====================
soc_d8350() {
    SOC_NAME="联发科 天玑8350"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1500000"; BIG_MAX="3200000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}
soc_d8300() {
    SOC_NAME="联发科 天玑8300"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1500000"; BIG_MAX="3350000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}
soc_d8020() {
    SOC_NAME="联发科 天玑8020"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1500000"; BIG_MAX="2600000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}
soc_d7300x() {
    SOC_NAME="联发科 天玑7300X"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1200000"; BIG_MAX="2500000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}
soc_d7300() {
    SOC_NAME="联发科 天玑7300"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1200000"; BIG_MAX="2500000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}
soc_d7200() {
    SOC_NAME="联发科 天玑7200"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1200000"; BIG_MAX="2800000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}
soc_d7050() {
    SOC_NAME="联发科 天玑7050"
    BIG_CORES="6 7"; LITTLE_CORES="0 1 2 3 4 5"
    BIG_MIN="1200000"; BIG_MAX="2600000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}
soc_d7025() {
    SOC_NAME="联发科 天玑7025"
    BIG_CORES="6 7"; LITTLE_CORES="0 1 2 3 4 5"
    BIG_MIN="1200000"; BIG_MAX="2200000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}
soc_d7020() {
    SOC_NAME="联发科 天玑7020"
    BIG_CORES="6 7"; LITTLE_CORES="0 1 2 3 4 5"
    BIG_MIN="1200000"; BIG_MAX="2200000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}
soc_d1300t() {
    SOC_NAME="联发科 天玑1300T"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1500000"; BIG_MAX="3000000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}
soc_d930() {
    SOC_NAME="联发科 天玑930"
    BIG_CORES="6 7"; LITTLE_CORES="0 1 2 3 4 5"
    BIG_MIN="1200000"; BIG_MAX="2200000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}
soc_d900() {
    SOC_NAME="联发科 天玑900"
    BIG_CORES="6 7"; LITTLE_CORES="0 1 2 3 4 5"
    BIG_MIN="1200000"; BIG_MAX="2400000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}
soc_d6300() {
    SOC_NAME="联发科 天玑6300"
    BIG_CORES="6 7"; LITTLE_CORES="0 1 2 3 4 5"
    BIG_MIN="1200000"; BIG_MAX="2400000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}

# ==================== 联发科 Helio ====================
soc_helio_g99() {
    SOC_NAME="联发科 Helio G99"
    BIG_CORES="6 7"; LITTLE_CORES="0 1 2 3 4 5"
    BIG_MIN="1200000"; BIG_MAX="2200000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}
soc_helio_g88() {
    SOC_NAME="联发科 Helio G88"
    BIG_CORES="6 7"; LITTLE_CORES="0 1 2 3 4 5"
    BIG_MIN="1200000"; BIG_MAX="2000000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}
soc_helio_g85() {
    SOC_NAME="联发科 Helio G85"
    BIG_CORES="6 7"; LITTLE_CORES="0 1 2 3 4 5"
    BIG_MIN="1200000"; BIG_MAX="2000000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}
soc_helio_g80() {
    SOC_NAME="联发科 Helio G80"
    BIG_CORES="6 7"; LITTLE_CORES="0 1 2 3 4 5"
    BIG_MIN="1200000"; BIG_MAX="2000000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}
soc_helio_g37() {
    SOC_NAME="联发科 Helio G37"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1100000"; BIG_MAX="2300000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}
soc_helio_p22t() {
    SOC_NAME="联发科 Helio P22T"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1100000"; BIG_MAX="2300000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}
soc_helio_p10() {
    SOC_NAME="联发科 Helio P10"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1100000"; BIG_MAX="2000000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}
soc_mt8166() {
    SOC_NAME="联发科 MT8166"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1200000"; BIG_MAX="2000000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}

# ==================== 紫光展锐 ====================
soc_t616() {
    SOC_NAME="紫光展锐 T616"
    BIG_CORES="6 7"; LITTLE_CORES="0 1 2 3 4 5"
    BIG_MIN="1200000"; BIG_MAX="2000000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}
soc_t606() {
    SOC_NAME="紫光展锐 T606"
    BIG_CORES="6 7"; LITTLE_CORES="0 1 2 3 4 5"
    BIG_MIN="1200000"; BIG_MAX="1600000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}

# ==================== 通用兜底 ====================
soc_generic() {
    SOC_NAME="未知芯片（通用方案）"
    BIG_CORES="4 5 6 7"; LITTLE_CORES="0 1 2 3"
    BIG_MIN="1200000"; BIG_MAX="2000000"
    GPU_GOV="simple_ondemand"; GOVERNOR="schedutil"
}